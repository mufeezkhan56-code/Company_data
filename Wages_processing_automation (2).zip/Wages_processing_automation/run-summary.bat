@echo off
cd /d "%~dp0"
echo.
echo === Sale Summary Generator ===
echo.
if "%~1"=="" (
  echo A file window will open — pick Excel/CSV from This PC or any folder.
  echo Or drag one sales file onto this BAT.
  echo.
  python run.py
) else (
  python run.py "%~1"
)
echo.
pause
