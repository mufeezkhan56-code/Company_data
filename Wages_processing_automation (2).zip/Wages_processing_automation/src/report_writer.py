"""Aggregate classified sales into summary rows + write Excel."""
from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from .mapping import is_zero_vat


HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF")
YELLOW = PatternFill("solid", fgColor="FFFF00")
RED = PatternFill("solid", fgColor="FF2F2F")
GRID = Border(
    left=Side(style="thin", color="B0B0B0"),
    right=Side(style="thin", color="B0B0B0"),
    top=Side(style="thin", color="B0B0B0"),
    bottom=Side(style="thin", color="B0B0B0"),
)
THIN = GRID


def _apply_grid(ws, min_row: int, max_row: int, min_col: int, max_col: int) -> None:
    if max_row < min_row or max_col < min_col:
        return
    for r in range(min_row, max_row + 1):
        for c in range(min_col, max_col + 1):
            ws.cell(r, c).border = GRID


def _add_excel_table(ws, name: str, ref: str) -> None:
    """Excel Format-as-Table look (borders + row stripes)."""
    safe = "".join(ch if ch.isalnum() else "_" for ch in name)[:40] or "Table1"
    # displayName must be unique in workbook
    existing = {t.name for t in ws.tables.values()}
    base = safe
    i = 1
    while safe in existing:
        safe = f"{base}_{i}"
        i += 1
    tab = Table(displayName=safe, ref=ref)
    tab.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    ws.add_table(tab)



def _unmatched_group(row) -> str:
    kw = str(row.get("keyword") or "").strip()
    if kw:
        return kw
    s = str(row.get("custom_label") or "").strip()
    if not s or s.lower() in {"nan", "none"}:
        return "UNKNOWN"
    if s.replace(".", "").isdigit():
        return "PLAIN-NUMBER"
    if s.upper().startswith("SET"):
        return "SET"
    return "UNKNOWN"


def build_summary_table(classified: pd.DataFrame, cfg: dict[str, str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    ok = classified[classified["summary_sku"].notna() & (classified["summary_sku"] != "")].copy()
    unmatched = classified[classified["summary_sku"].isna() | (classified["summary_sku"] == "")].copy()

    all_sale = float(classified["total_price"].sum()) if len(classified) else 0.0
    unmatched_sale = float(unmatched["total_price"].sum()) if len(unmatched) else 0.0
    ebay_fee = float(cfg.get("ebay_fee", 0) or 0)
    refunds = float(cfg.get("refunds", 0) or 0)
    # Net / sale-after include unmatched (full sale)
    net_sale = all_sale - ebay_fee
    sale_after = net_sale - refunds

    if ok.empty:
        empty = pd.DataFrame(
            columns=[
                "Sku",
                "Family",
                "Size",
                "Qty",
                "Sale Price",
                "20%",
                "Sale Percentage",
                "Net Sale",
                "Net Sale Per Unit",
                "Ex Vat Per Unit",
                "5%",
                "Purchase Inc Vat",
                "Purchase Ex Vat",
                "Total Purchase",
                "Purchase 20%",
            ]
        )
        empty.attrs["total_sale"] = all_sale
        empty.attrs["matched_sale"] = 0.0
        empty.attrs["unmatched_sale"] = unmatched_sale
        empty.attrs["ebay_fee"] = ebay_fee
        empty.attrs["refunds"] = refunds
        empty.attrs["net_sale"] = net_sale
        empty.attrs["sale_after"] = sale_after
        return empty, unmatched

    grouped = (
        ok.groupby(["summary_sku", "family", "size"], dropna=False)
        .agg(Qty=("quantity", "sum"), Sale_Price=("total_price", "sum"))
        .reset_index()
        .rename(columns={"summary_sku": "Sku", "family": "Family", "size": "Size", "Sale_Price": "Sale Price"})
    )
    grouped = grouped.sort_values(["Family", "Size", "Sku"]).reset_index(drop=True)

    matched_sale = float(grouped["Sale Price"].sum())
    # Percent of FULL sale (incl unmatched) so Net Sale rows + unmatched = total net
    base_for_pct = all_sale if all_sale else matched_sale

    rows = []
    for _, r in grouped.iterrows():
        qty = float(r["Qty"])
        sale = float(r["Sale Price"])
        family = str(r["Family"] or "")
        sku = str(r["Sku"] or "")
        # Kids / baby: no sales VAT (matches yellow VAT box 0% rule)
        zero_vat = is_zero_vat(sku, family)
        vat20 = 0.0 if zero_vat else (sale / 120 * 20 if sale else 0.0)
        pct = (sale / base_for_pct) if base_for_pct else 0.0
        net = pct * sale_after
        net_unit = (net / qty) if qty else 0.0
        # Kids sample: Ex Vat / Purchase Ex = 0; adults strip 20%
        ex_vat_unit = 0.0 if zero_vat else (net_unit * 100 / 120)
        five = net_unit * 0.05
        # Teams sample: Purchase Inc Vat = Net Sale Per Unit − 5%
        purch_inc = net_unit - five
        purch_ex = 0.0 if zero_vat else (purch_inc * 100 / 120 if purch_inc else 0.0)
        total_purch = purch_inc * qty
        purch_vat = 0.0 if zero_vat else (total_purch / 120 * 20 if total_purch else 0.0)
        rows.append(
            {
                "Sku": r["Sku"],
                "Family": family,
                "Size": r["Size"],
                "Qty": qty,
                "Sale Price": round(sale, 2),
                "20%": round(vat20, 4),
                "Sale Percentage": pct,
                "Net Sale": round(net, 4),
                "Net Sale Per Unit": round(net_unit, 4),
                "Ex Vat Per Unit": round(ex_vat_unit, 4),
                "5%": round(five, 4),
                "Purchase Inc Vat": round(purch_inc, 4),
                "Purchase Ex Vat": round(purch_ex, 4),
                "Total Purchase": round(total_purch, 4),
                "Purchase 20%": round(purch_vat, 4),
            }
        )

    summary = pd.DataFrame(rows)
    summary.attrs["total_sale"] = all_sale
    summary.attrs["matched_sale"] = matched_sale
    summary.attrs["unmatched_sale"] = unmatched_sale
    summary.attrs["ebay_fee"] = ebay_fee
    summary.attrs["refunds"] = refunds
    summary.attrs["net_sale"] = net_sale
    summary.attrs["sale_after"] = sale_after
    return summary, unmatched


def _style_header(ws, row: int, start: int, end: int, fill=HEADER_FILL):
    for col in range(start, end + 1):
        cell = ws.cell(row, col)
        cell.fill = fill
        cell.font = HEADER_FONT if fill == HEADER_FILL else Font(bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")


def write_report(
    classified: pd.DataFrame,
    summary: pd.DataFrame,
    unmatched: pd.DataFrame,
    out_path: Path,
    source_name: str,
    fee_label: str = "Marketplace fee",
) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = (source_name[:28] or "Orders")[:31]

    # --- Left: order lines (no Family / Size / Summary SKU) ---
    left_headers = [
        "Sale date",
        "Order number",
        "Custom label",
        "Item title",
        "Quantity",
        "Sold for",
        "Total price",
        "Vat %",
    ]
    for c, h in enumerate(left_headers, 1):
        ws.cell(1, c, h)
    _style_header(ws, 1, 1, 7)
    _style_header(ws, 1, 8, 8, YELLOW)

    for i, r in classified.iterrows():
        row = i + 2
        ws.cell(row, 1, r["sale_date"])
        ws.cell(row, 2, r["order_number"])
        ws.cell(row, 3, r["custom_label"])
        ws.cell(row, 4, r["item_title"])
        ws.cell(row, 5, r["quantity"])
        ws.cell(row, 6, r["sold_for"])
        ws.cell(row, 7, r["total_price"])
        ws.cell(row, 8, r["vat_pct"])

    left_last = max(len(classified) + 1, 2)
    _apply_grid(ws, 1, left_last, 1, 8)
    _add_excel_table(ws, f"Orders_{source_name}", f"A1:H{left_last}")

    # VAT totals block — live Excel formulas (cols M-N)
    total_sale = float(classified["total_price"].sum()) if len(classified) else 0.0
    matched_sale = float(summary.attrs.get("matched_sale", 0) or 0)
    if not matched_sale and len(summary):
        matched_sale = float(summary["Sale Price"].sum())
    unmatched_sale = float(summary.attrs.get("unmatched_sale", 0) or 0)
    if not unmatched_sale and len(unmatched):
        unmatched_sale = float(unmatched["total_price"].sum())
    ebay_fee = float(summary.attrs.get("ebay_fee", 0) or 0)
    refunds = float(summary.attrs.get("refunds", 0) or 0)
    sale_after = float(summary.attrs.get("sale_after", total_sale - ebay_fee - refunds) or 0)

    g_end = max(left_last, 2)
    ws.cell(1, 13, "VAT box (ALL lines)")
    ws.cell(1, 13).font = Font(bold=True)
    ws.cell(2, 13, "Total Sale")
    ws.cell(2, 14, f"=SUM(G2:G{g_end})")
    ws.cell(3, 13, "20% Sale")
    ws.cell(3, 14, f'=SUMIF(H2:H{g_end},"20%",G2:G{g_end})')
    ws.cell(4, 13, "0% Sale")
    ws.cell(4, 14, f'=SUMIF(H2:H{g_end},"0%",G2:G{g_end})')
    ws.cell(5, 13, "VAT")
    ws.cell(5, 14, "=N3/120*20")
    ws.cell(6, 13, "Ex VAT (20% part)")
    ws.cell(6, 14, "=N3-N5")
    ws.cell(7, 13, "Matched (detail)")
    ws.cell(7, 14, round(matched_sale, 2))
    ws.cell(8, 13, "Unmatched (detail)")
    ws.cell(8, 14, round(unmatched_sale, 2))
    # Absolute refs for summary row formulas (like sample $P$14 / $P$18)
    ws.cell(9, 13, fee_label)
    ws.cell(9, 14, round(ebay_fee, 2))
    ws.cell(10, 13, "Refunds")
    ws.cell(10, 14, round(refunds, 2))
    ws.cell(11, 13, "Sale After")
    ws.cell(11, 14, "=N2-N9-N10")
    for r in range(2, 12):
        ws.cell(r, 13).fill = YELLOW
        ws.cell(r, 14).fill = YELLOW
        ws.cell(r, 14).number_format = "0.00"
    _apply_grid(ws, 1, 11, 13, 14)

    # --- Right summary starting at column P (no Family/Size — sample style) ---
    start_col = 16
    sum_headers = [
        "Sku",
        "Qty",
        "Sale Price",
        "20%",
        "Sale Percentage",
        "Net Sale",
        "Net Sale Per Unit",
        "Ex Vat Per Unit",
        "5%",
        "Purchase Inc Vat",
        "Purchase Ex Vat",
        "Total Purchase",
        "Purchase 20%",
    ]
    for c, h in enumerate(sum_headers, start_col):
        ws.cell(1, c, h)
    _style_header(ws, 1, start_col, start_col + len(sum_headers) - 1)

    # P Sku, Q Qty, R Sale, S 20%, T %, U Net, V Net/u, W ExVat/u,
    # X 5%, Y PurchInc, Z PurchEx, AA TotalPurch, AB Purch20%
    col_sku = get_column_letter(start_col)       # P
    col_qty = get_column_letter(start_col + 1)   # Q
    col_sale = get_column_letter(start_col + 2)  # R
    col_pct = get_column_letter(start_col + 4)   # T
    col_net = get_column_letter(start_col + 5)   # U
    col_netu = get_column_letter(start_col + 6)  # V
    col_five = get_column_letter(start_col + 8)  # X
    col_pinc = get_column_letter(start_col + 9)  # Y
    col_tp = get_column_letter(start_col + 11)   # AA

    def _kids_zero(row: int) -> str:
        """Kids/baby 0% VAT from Sku only (Family/Size columns removed)."""
        return (
            f'OR(ISNUMBER(SEARCH("-K-",{col_sku}{row})),'
            f'ISNUMBER(SEARCH("BABY",{col_sku}{row})),'
            f'LEFT({col_sku}{row},2)="K-")'
        )

    for i, r in summary.iterrows():
        row = i + 2
        kids = _kids_zero(row)
        # Inputs: Sku, Qty, Sale Price
        ws.cell(row, start_col, r["Sku"])
        ws.cell(row, start_col + 1, r["Qty"])
        sale_cell = ws.cell(row, start_col + 2, r["Sale Price"])
        sale_cell.number_format = "0.00"

        # Live formulas (Purchase Inc = Net/unit − 5%)
        u = ws.cell(row, start_col + 3, f'=IF({kids},0,{col_sale}{row}/120*20)')
        u.number_format = "0.00"
        v = ws.cell(row, start_col + 4, f"=IFERROR({col_sale}{row}/$N$2,0)")
        v.number_format = "0.00%"
        w = ws.cell(row, start_col + 5, f"={col_pct}{row}*$N$11")
        w.number_format = "0.00"
        x = ws.cell(row, start_col + 6, f"=IFERROR({col_net}{row}/{col_qty}{row},0)")
        x.number_format = "0.00"
        # W Ex Vat / Z Purchase Ex: kids → 0 (sample style)
        y = ws.cell(row, start_col + 7, f"=IF({kids},0,{col_netu}{row}*100/120)")
        y.number_format = "0.00"
        z = ws.cell(row, start_col + 8, f"={col_netu}{row}*0.05")
        z.number_format = "0.00"
        aa = ws.cell(row, start_col + 9, f"={col_netu}{row}-{col_five}{row}")
        aa.number_format = "0.00"
        ab = ws.cell(row, start_col + 10, f"=IF({kids},0,{col_pinc}{row}*100/120)")
        ab.number_format = "0.00"
        ac = ws.cell(row, start_col + 11, f"={col_pinc}{row}*{col_qty}{row}")
        ac.number_format = "0.00"
        ad = ws.cell(row, start_col + 12, f"=IF({kids},0,{col_tp}{row}/120*20)")
        ad.number_format = "0.00"

        if is_zero_vat(str(r.get("Sku") or ""), str(r.get("Family") or "")):
            for c in (start_col + 3, start_col + 7, start_col + 10, start_col + 12):
                ws.cell(row, c).fill = RED

    sum_last = max(len(summary) + 1, 2)
    sum_end_col = start_col + len(sum_headers) - 1
    _apply_grid(ws, 1, sum_last, start_col, sum_end_col)
    _add_excel_table(
        ws,
        f"Summary_{source_name}",
        f"{get_column_letter(start_col)}1:{get_column_letter(sum_end_col)}{sum_last}",
    )

    # Footer totals — SUM formulas over data rows
    footer_row = len(summary) + 3
    data_end = max(len(summary) + 1, 2)

    ws.cell(footer_row, start_col, "TOTALS").font = Font(bold=True)
    for offset, fmt in (
        (1, "0"),      # Qty
        (2, "0.00"),   # Sale Price
        (3, "0.00"),   # 20%
        (4, "0.00%"),  # Sale %
        (5, "0.00"),   # Net Sale
        (11, "0.00"),  # Total Purchase
        (12, "0.00"),  # Purchase 20%
    ):
        letter = get_column_letter(start_col + offset)
        c = ws.cell(footer_row, start_col + offset, f"=SUM({letter}2:{letter}{data_end})")
        c.font = Font(bold=True)
        c.number_format = fmt

    # Side summary labels (mirror VAT-box / footer SUMs)
    extras = [
        (fee_label, f"=$N$9"),
        ("Net Sale (incl Unmatched)", f"=$N$2-$N$9"),
        ("Refunds", f"=$N$10"),
        ("Sale After", f"=$N$11"),
        ("Total Sale (all lines)", f"=$N$2"),
        ("Matched Sale (table)", f"={col_sale}{footer_row}"),
        ("Unmatched Sale", round(unmatched_sale, 2)),
        ("Purchase", f"={col_tp}{footer_row}"),
        ("Purchase / Net %", f"=IFERROR({col_tp}{footer_row}/$N$11,0)"),
    ]
    for idx, (label, val) in enumerate(extras):
        r = footer_row + 2 + idx
        ws.cell(r, start_col + 1, label).font = Font(bold=True)
        cell = ws.cell(r, start_col + 2, val)
        if label.endswith("%"):
            cell.number_format = "0.00%"
        else:
            cell.number_format = "0.00"

    # Unmatched mini-summary by keyword
    um_start = footer_row + 2 + len(extras) + 2
    ws.cell(um_start, start_col, "UNMATCHED SUMMARY (by keyword)").font = Font(bold=True)
    ws.cell(um_start + 1, start_col, "Keyword")
    ws.cell(um_start + 1, start_col + 1, "Lines")
    ws.cell(um_start + 1, start_col + 2, "Qty")
    ws.cell(um_start + 1, start_col + 3, "Sale")
    _style_header(ws, um_start + 1, start_col, start_col + 3)
    if len(unmatched):
        tmp = unmatched.copy()
        if "keyword" not in tmp.columns:
            tmp["keyword"] = ""
        tmp["_group"] = tmp.apply(_unmatched_group, axis=1)
        um_g = (
            tmp.groupby("_group", dropna=False)
            .agg(Lines=("custom_label", "count"), Qty=("quantity", "sum"), Sale=("total_price", "sum"))
            .reset_index()
            .sort_values("Sale", ascending=False)
        )
        for i, (_, r) in enumerate(um_g.iterrows()):
            rr = um_start + 2 + i
            ws.cell(rr, start_col, r["_group"])
            ws.cell(rr, start_col + 1, int(r["Lines"]))
            ws.cell(rr, start_col + 2, float(r["Qty"]))
            cell = ws.cell(rr, start_col + 3, round(float(r["Sale"]), 2))
            cell.number_format = "0.00"
        tot_r = um_start + 2 + len(um_g)
        ws.cell(tot_r, start_col, "UNMATCHED TOTAL").font = Font(bold=True)
        ws.cell(tot_r, start_col + 1, len(unmatched))
        ws.cell(tot_r, start_col + 2, float(unmatched["quantity"].sum()))
        cell = ws.cell(tot_r, start_col + 3, round(unmatched_sale, 2))
        cell.number_format = "0.00"
    else:
        ws.cell(um_start + 2, start_col, "(none)")


    # widths
    widths = {
        "A": 12,
        "B": 16,
        "C": 42,
        "D": 50,
        "E": 10,
        "F": 10,
        "G": 12,
        "H": 8,
        "M": 12,
        "N": 12,
        "P": 18,
        "Q": 8,
        "R": 12,
        "S": 10,
        "T": 12,
        "U": 12,
        "V": 14,
        "W": 14,
        "X": 8,
        "Y": 14,
        "Z": 14,
        "AA": 14,
        "AB": 12,
    }
    for col, w in widths.items():
        ws.column_dimensions[col].width = w

    # No freeze panes — frozen header looked like a duplicate header when scrolling.
    # Filters come from Excel Tables (Orders_* / Summary_*), not worksheet auto_filter.

    # Unmatched sheet
    ws2 = wb.create_sheet("Unmatched")
    um_cols = [
        "sale_date",
        "order_number",
        "custom_label",
        "item_title",
        "quantity",
        "sold_for",
        "total_price",
        "keyword",
        "lookup_key",
    ]
    ws2.append(
        [
            "Sale date",
            "Order number",
            "Custom label",
            "Item title",
            "Quantity",
            "Sold for",
            "Total price",
            "Keyword",
            "Lookup key",
        ]
    )
    _style_header(ws2, 1, 1, 9)
    for _, r in unmatched.iterrows():
        ws2.append([r.get(c, "") for c in um_cols])
    um_last = max(len(unmatched) + 1, 2)
    _apply_grid(ws2, 1, um_last, 1, 9)
    if len(unmatched):
        _add_excel_table(ws2, f"Unmatched_{source_name}", f"A1:I{um_last}")

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    return out_path
