"""Load Custom Label Database and look up labels."""
from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path

import pandas as pd

from .mapping import (
    family_from_gender,
    family_from_label,
    is_valid_summary_size,
    prefer_label_family,
    prefer_label_size,
    short_size,
    size_from_label,
    summary_sku,
)


def normalize_lookup_key(label: str) -> str:
    s = str(label or "").strip().rstrip(".")
    if not s or s.lower() in {"nan", "none"}:
        return ""
    if "LG-" in s:
        s = s.split("LG-", 1)[1].strip().rstrip(".")
    else:
        s = re.sub(r"^\d+", "", s).lstrip("-").strip().rstrip(".")
    return s


class SkuDatabase:
    def __init__(self, csv_path: Path):
        self.path = Path(csv_path)
        usecols = [
            "Custom_Label",
            "Gender_Apparel",
            "Colour",
            "Size",
            "Category",
            "Sub_Category",
        ]
        df = pd.read_csv(self.path, usecols=usecols, low_memory=False)
        df["Custom_Label"] = df["Custom_Label"].astype(str).str.strip()
        df["_key"] = df["Custom_Label"].str.lower()
        # keep first row per label
        self.df = df.drop_duplicates(subset=["_key"], keep="first")
        self._by_key = {
            row["_key"]: row
            for _, row in self.df.iterrows()
        }

    def lookup(self, custom_label: str) -> dict:
        raw = str(custom_label or "").strip()
        keys = []
        rest = normalize_lookup_key(raw)
        if rest:
            keys.append(rest.lower())
        if raw:
            keys.append(raw.lower())

        row = None
        for k in keys:
            row = self._by_key.get(k)
            if row is not None:
                break

        gender = str(row["Gender_Apparel"]) if row is not None and pd.notna(row["Gender_Apparel"]) else ""
        size_full = str(row["Size"]) if row is not None and pd.notna(row["Size"]) else ""
        category = str(row["Category"]) if row is not None and pd.notna(row["Category"]) else ""
        colour = str(row["Colour"]) if row is not None and pd.notna(row["Colour"]) else ""
        sub = str(row["Sub_Category"]) if row is not None and pd.notna(row["Sub_Category"]) else ""

        family = family_from_gender(gender, category) if row is not None else None
        if not family:
            family = family_from_label(raw)
        # Explicit …K-T… / …M-T… in the label beats wrong CSV Gender (e.g. Mens on a kids SKU)
        family = prefer_label_family(family, raw)

        size = short_size(size_full) if size_full else ""
        if not size:
            size = size_from_label(raw)
        size = prefer_label_size(size, raw, family)
        if size and not is_valid_summary_size(size):
            size = ""

        matched = row is not None
        if not family:
            return {
                "matched": matched,
                "family": None,
                "size": size,
                "size_full": size_full,
                "gender": gender,
                "category": category,
                "colour": colour,
                "sub_category": sub,
                "summary_sku": None,
                "lookup_key": rest,
            }

        return {
            "matched": matched,
            "family": family,
            "size": size,
            "size_full": size_full,
            "gender": gender,
            "category": category,
            "colour": colour,
            "sub_category": sub,
            "summary_sku": summary_sku(family, size),
            "lookup_key": rest,
        }


@lru_cache(maxsize=2)
def load_sku_db(csv_path: str) -> SkuDatabase:
    return SkuDatabase(Path(csv_path))
