"""Load simple key=value config.txt."""
from __future__ import annotations

from pathlib import Path


def load_config(path: Path | None = None) -> dict[str, str]:
    root = Path(__file__).resolve().parents[1]
    cfg_path = path or (root / "config.txt")
    data: dict[str, str] = {}
    if not cfg_path.exists():
        return data
    for raw in cfg_path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip()
    data["_root"] = str(root)
    return data


def project_root(cfg: dict[str, str] | None = None) -> Path:
    if cfg and cfg.get("_root"):
        return Path(cfg["_root"])
    return Path(__file__).resolve().parents[1]


def resolve_path(cfg: dict[str, str], key: str, default: str) -> Path:
    root = project_root(cfg)
    raw = cfg.get(key, default)
    p = Path(raw)
    return p if p.is_absolute() else (root / p)
