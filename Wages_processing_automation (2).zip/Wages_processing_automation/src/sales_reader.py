"""Read sales Excel / CSV and classify each order line."""
from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from .mapping import (
    is_zero_vat,
    is_adult_apparel_family,
    is_kids_family,
    is_valid_summary_size,
    family_from_label,
    family_from_title,
    prefer_label_family,
    prefer_label_size,
    size_from_title,
    summary_sku,
    keyword_hint,
)
from .sku_db import SkuDatabase


SALE_COL_ALIASES = {
    "sale_date": [
        "sale date",
        "date/time",
        "date",
        "order date",
        "purchase date",
    ],
    "order_number": ["order number", "order id", "order"],
    "custom_label": [
        "custom label",
        "custom_label",
        "contribution sku",
        "item sku",
        "sku",
    ],
    "item_title": [
        "item title",
        "product name",
        "product name by customer order",
        "title",
        "item name",
        "description",
    ],
    "quantity": [
        "quantity purchased",
        "quantity",
        "qty",
        "quantity shipped",
    ],
    "sold_for": [
        "sold for",
        "sold_for",
        "retail price total",
        "goods base price",
        "price",
        "item price",
        "product sales",
    ],
    "total_price": [
        "total price",
        "total_price",
        "line total",
        "retail price total",
        "item total",
    ],
    "sales_tax": ["product sales tax", "sales tax", "product tax total"],
    "row_type": ["type", "transaction type"],
    "variation": ["variation"],
    "discount_amount": ["discount amount"],
}


def _is_etsy_sold_orders(path: Path, columns: list[str]) -> bool:
    """Etsy Sold Order Items export (coupons / Discount Amount)."""
    name = path.name.lower()
    if "etsy" in name:
        return True
    lower = {c.lower().strip() for c in columns}
    return "discount amount" in lower and (
        "coupon code" in lower or "coupon details" in lower
    )


def _apply_etsy_order_discounts(
    df: pd.DataFrame, out: pd.DataFrame, mapping: dict[str, str]
) -> None:
    """
    Etsy list Price/Item Total is pre-coupon. Discount Amount is order-level
    (same value on every line). Net line = share of (order gross − order discount).
    """
    cols = [str(c) for c in df.columns]
    disc_col = mapping.get("discount_amount") or _pick(cols, ["discount amount"])
    order_col = mapping.get("order_number")
    if not disc_col or not order_col:
        return

    item_col = _pick(cols, ["item total"])
    if item_col:
        line_gross = _money(df[item_col])
    elif "sold_for" in mapping:
        # Price is usually unit — multiply by qty
        line_gross = _money(df[mapping["sold_for"]]) * out["quantity"].astype(float)
    else:
        line_gross = out["total_price"].astype(float)

    disc = _money(df[disc_col])
    orders = df[order_col].astype(str)
    work = pd.DataFrame(
        {"order": orders, "gross": line_gross.astype(float), "disc": disc.astype(float)},
        index=df.index,
    )
    order_gross = work.groupby("order")["gross"].transform("sum")
    order_disc = work.groupby("order")["disc"].transform("max")
    order_net = (order_gross - order_disc).clip(lower=0.0)

    line_net = line_gross.astype(float).copy()
    ok = order_gross > 0
    line_net = line_net.where(~ok, line_gross.astype(float) / order_gross * order_net)
    line_net = line_net.clip(lower=0.0)

    qty = out["quantity"].astype(float).replace(0, 1.0)
    out["total_price"] = line_net.to_numpy()
    out["sold_for"] = (line_net / qty).to_numpy()


def _pick(columns: list[str], aliases: list[str]) -> str | None:
    lower = {c.lower().strip(): c for c in columns}
    for a in aliases:
        if a in lower:
            return lower[a]
    return None


def _row_looks_like_header(values: list[object]) -> bool:
    low = " | ".join(str(v).lower() for v in values if pd.notna(v))
    has_sku = any(
        k in low
        for k in (
            "contribution sku",
            "custom label",
            " sku",
            "sku ",
            '"sku"',
        )
    ) or re.search(r"(^|\W)sku(\W|$)", low)
    has_order = "order id" in low or "order number" in low or "order" in low
    has_qty = "quantity" in low or "qty" in low
    return bool(has_sku and (has_order or has_qty))


def _find_excel_header_row(path: Path, sheet: str | int = 0) -> tuple[str | int, int]:
    xl = pd.ExcelFile(path)
    sheet_name = xl.sheet_names[sheet] if isinstance(sheet, int) else sheet
    # Prefer Temu "Order report"
    for name in xl.sheet_names:
        if "order" in name.lower() and "courier" not in name.lower():
            sheet_name = name
            break
    preview = pd.read_excel(path, sheet_name=sheet_name, header=None, nrows=40)
    for i in range(len(preview)):
        if _row_looks_like_header(preview.iloc[i].tolist()):
            return sheet_name, i
    return sheet_name, 0


def _find_csv_header_row(path: Path) -> int:
    """Amazon reports have note lines before the real header."""
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            with path.open("r", encoding=enc, errors="strict") as f:
                for i, line in enumerate(f):
                    low = line.lower()
                    if ("sku" in low or "custom label" in low) and (
                        "order id" in low or "order number" in low or "quantity" in low
                    ):
                        return i
            return 0
        except UnicodeDecodeError:
            continue
    with path.open("r", encoding="utf-8-sig", errors="replace") as f:
        for i, line in enumerate(f):
            low = line.lower()
            if ("sku" in low or "custom label" in low) and (
                "order id" in low or "order number" in low or "quantity" in low
            ):
                return i
    return 0


def _read_csv_robust(path: Path, header_row: int) -> pd.DataFrame:
    """Amazon/Windows CSVs are often cp1252, not UTF-8."""
    last_err: Exception | None = None
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        for engine, extra in (
            ("c", {}),
            ("python", {"on_bad_lines": "skip"}),
        ):
            try:
                return pd.read_csv(
                    path,
                    skiprows=header_row,
                    encoding=enc,
                    engine=engine,
                    **extra,
                )
            except Exception as exc:  # noqa: BLE001 — try next encoding/engine
                last_err = exc
                continue
    assert last_err is not None
    raise last_err


def _read_table(path: Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        sheet_name, header_row = _find_excel_header_row(path)
        return pd.read_excel(path, sheet_name=sheet_name, header=header_row)

    header_row = _find_csv_header_row(path)
    return _read_csv_robust(path, header_row)


def _clean_sku(value: object) -> str:
    s = str(value or "").strip()
    if s.lower() in {"nan", "none"}:
        return ""
    return s.rstrip(".")


def _money(series: pd.Series) -> pd.Series:
    """Strip currency symbols like £/$ and parse numbers."""
    cleaned = (
        series.astype(str)
        .str.replace(r"[^\d.\-]", "", regex=True)
        .replace({"": None, "nan": None, "None": None})
    )
    return pd.to_numeric(cleaned, errors="coerce").fillna(0)


def read_sales_file(path: Path) -> pd.DataFrame:
    path = Path(path)
    df = _read_table(path)

    # drop fully empty columns leftover from Temu notes
    df = df.dropna(axis=1, how="all")
    cols = [str(c) for c in df.columns]
    df.columns = cols

    mapping = {}
    for key, aliases in SALE_COL_ALIASES.items():
        found = _pick(cols, aliases)
        if found:
            mapping[key] = found

    if "custom_label" not in mapping:
        raise ValueError(
            "Could not find Custom label / SKU column in sales file. "
            f"Columns: {list(df.columns)[:20]}"
        )

    # Amazon Custom Transaction: keep product Order lines only
    if "row_type" in mapping:
        types = df[mapping["row_type"]].astype(str).str.strip().str.lower()
        df = df[types == "order"].copy()

    out = pd.DataFrame()
    out["sale_date"] = df[mapping["sale_date"]] if "sale_date" in mapping else ""
    out["order_number"] = df[mapping["order_number"]] if "order_number" in mapping else ""
    out["custom_label"] = df[mapping["custom_label"]].map(_clean_sku)
    title_col = mapping.get("item_title")
    out["item_title"] = df[title_col] if title_col else ""
    # Temu: append variation into title for size hints (5-6Y/Pink)
    if "variation" in mapping:
        var = df[mapping["variation"]].astype(str).replace({"nan": ""})
        out["item_title"] = (
            out["item_title"].astype(str) + " " + var
        ).str.strip()

    qty_col = mapping.get("quantity")
    out["quantity"] = (
        pd.to_numeric(df[qty_col], errors="coerce").fillna(0) if qty_col else 1
    )

    if "sold_for" in mapping:
        sold = _money(df[mapping["sold_for"]])
    else:
        sold = pd.Series([0.0] * len(df))
    if "sales_tax" in mapping and mapping.get("sold_for", "").lower() == "product sales":
        sold = sold + _money(df[mapping["sales_tax"]])
    out["sold_for"] = sold

    if "total_price" in mapping:
        # Prefer retail/total style columns; avoid Amazon fee-deducted "total"
        col_name = mapping["total_price"].lower()
        if col_name in {
            "total price",
            "retail price total",
            "line total",
            "item total",
        }:
            out["total_price"] = _money(df[mapping["total_price"]])
            out["total_price"] = out["total_price"].where(
                out["total_price"] != 0, out["sold_for"]
            )
        else:
            out["total_price"] = out["sold_for"]
    else:
        out["total_price"] = out["sold_for"]

    # Etsy: convert pre-coupon Price/Item Total → post-coupon net (order-level share)
    if _is_etsy_sold_orders(path, cols):
        _apply_etsy_order_discounts(df, out, mapping)

    out = out[out["custom_label"].astype(str).str.len() > 0]
    out = out[out["custom_label"].str.lower().isin(["nan", "none"]) == False]
    out = out.reset_index(drop=True)
    return out


def classify_sales(sales: pd.DataFrame, db: SkuDatabase) -> pd.DataFrame:
    rows = []
    for _, r in sales.iterrows():
        label = str(r["custom_label"])
        title = str(r["item_title"] or "")
        info = db.lookup(label)
        family = info.get("family")
        size = info.get("size") or ""
        matched = bool(info.get("matched"))
        source = "csv" if matched and family else ""

        # Plain / custom SKUs: read product name
        if not family:
            if not matched:
                size = ""
            fam2 = family_from_title(title)
            if fam2:
                family = fam2
                size = size_from_title(title) or (
                    "OS"
                    if fam2 in {"CAP", "BOTTLE", "SCARF", "GLOVE", "SOCK", "PENCIL"}
                    else ""
                )
                source = "title"
        # CSV sometimes maps to OTHER (e.g. gender "5000") — prefer clear title
        elif family == "OTHER":
            fam2 = family_from_title(title)
            if fam2 and fam2 != "OTHER":
                family = fam2
                size = size or size_from_title(title) or size
                if not size and fam2 in {"CAP", "BOTTLE", "SCARF", "GLOVE", "SOCK", "PENCIL"}:
                    size = "OS"
                source = "title-override"

        # Label …K-T… beats bad CSV adult gender (Mens on kids SKU)
        family = prefer_label_family(family, label)
        size = prefer_label_size(size, label, family)

        # Label-first (EXE style): clear M-T / W-T in label wins — do NOT override from title.
        # Title kids only when label has no clear adult apparel code.
        label_fam = family_from_label(label)
        if (
            family
            and is_adult_apparel_family(family)
            and not is_kids_family(family)
            and not (label_fam and (label_fam.startswith("M-") or label_fam.startswith("W-")))
        ):
            fam2 = family_from_title(title)
            if fam2 and is_kids_family(fam2):
                family = fam2
                title_sz = size_from_title(title) or ""
                size = prefer_label_size(size or title_sz, label, family)
                source = "title-kids-override"

        if size and not is_valid_summary_size(size):
            size = ""

        sku = summary_sku(family, size) if family else None
        zero = is_zero_vat(label, family)
        qty = float(r["quantity"] or 0)
        total = float(r["total_price"] or 0)
        kw = family if family else keyword_hint(label, title)
        rows.append(
            {
                "sale_date": r["sale_date"],
                "order_number": r["order_number"],
                "custom_label": label,
                "item_title": title,
                "quantity": qty,
                "sold_for": float(r["sold_for"] or 0),
                "total_price": total,
                "vat_pct": "0%" if zero else "20%",
                "matched": matched,
                "match_source": source or ("csv" if family else ""),
                "family": family,
                "size": size,
                "size_full": info.get("size_full") or "",
                "gender": info.get("gender") or "",
                "summary_sku": sku,
                "keyword": kw,
                "lookup_key": info.get("lookup_key") or "",
            }
        )
    return pd.DataFrame(rows)


def purchase_unit(cfg: dict[str, str], family: str | None) -> float:
    if not family:
        return float(cfg.get("purchase_OTHER", 0) or 0)
    key = f"purchase_{family}"
    if key in cfg:
        try:
            return float(cfg[key])
        except ValueError:
            return 0.0

    def _get(cfg_key: str) -> float:
        try:
            return float(cfg.get(cfg_key, 0) or 0)
        except ValueError:
            return 0.0

    # Exact / specific first — never let W-T match W-TT
    if family.startswith("W-TT"):
        return _get("purchase_W-T")
    if family.startswith("U-TT"):
        return _get("purchase_U-T")
    if family.startswith("U-T"):
        return _get("purchase_U-T")
    if family.startswith("U-H"):
        return _get("purchase_U-H")
    if family.startswith("U-SS"):
        return _get("purchase_U-SS")
    if family.startswith("M-TT") or family == "TANK":
        return _get("purchase_M-T")
    if family.startswith("M-T"):
        return _get("purchase_M-T")
    if family.startswith("W-T"):
        return _get("purchase_W-T")
    if family.startswith("K-T"):
        return _get("purchase_K-T")
    if family.startswith("M-H"):
        return _get("purchase_M-H")
    if family.startswith("W-H"):
        return _get("purchase_W-H")
    if family.startswith("K-H"):
        return _get("purchase_K-H")
    if family.startswith("M-SS"):
        return _get("purchase_M-SS")
    if family.startswith("W-SS"):
        return _get("purchase_W-SS")
    if family.startswith("K-SS"):
        return _get("purchase_K-SS")
    return _get("purchase_OTHER")
