"""Size short codes + product family mapping for summary rows."""
from __future__ import annotations

import re

SIZE_MAP = {
    "extra extra small": "XXS",
    "extra small": "XS",
    "small": "S",
    "medium": "M",
    "large": "L",
    "extra large": "XL",
    "2xl": "2XL",
    "3xl": "3XL",
    "4xl": "4XL",
    "5xl": "5XL",
    "2xl ": "2XL",
    "standard size": "OS",
    "o/s": "OS",
    "one size": "OS",
    "3-4 years": "YXS",
    "4-5 years": "Y4-5",
    "5-6 years": "YS",
    "7-8 years": "YM",
    "9-11 years": "YL",
    "12-13 years": "Y12-13",
    "12-14 years": "YXL",
    "14-15 years": "Y14-15",
    "0-3 months": "0-3M",
    "3-6 months": "3-6M",
    "6-12 months": "6-12M",
    "12-18 months": "12-18M",
    "18-24 months": "18-24M",
    "1-2 years": "1-2Y",
    "2-3 years": "2-3Y",
    "11oz": "11OZ",
    "11 oz": "11OZ",
    "a4": "A4",
    "a3": "A3",
    "a5": "A5",
    "a6": "A6",
}


def short_size(size: str | None) -> str:
    if size is None:
        return ""
    raw = str(size).strip()
    if not raw or raw.lower() in {"nan", "none"}:
        return ""
    key = re.sub(r"\s+", " ", raw.lower()).strip()
    if key in SIZE_MAP:
        return SIZE_MAP[key]
    # already short like XL / 2XL / YS
    compact = raw.replace(" ", "")
    if re.fullmatch(r"(?i)(XXS|XS|S|M|L|XL|2XL|3XL|4XL|5XL|YS|YM|YL|YXL|YXS|Y2XL|Y3XL|OS|O/S)", compact):
        return compact.upper().replace("O/S", "OS")
    if re.fullmatch(r"(?i)\d+OZ", compact):
        return compact.upper()
    if re.fullmatch(r"(?i)Y?\d+(-\d+)?[MY]?", compact) and is_valid_summary_size(compact.upper()):
        return compact.upper()
    # do NOT keep random short tokens (SET…, numeric ids, "2Years")
    return ""


def family_from_gender(gender: str | None, category: str | None = None) -> str | None:
    g = (gender or "").strip().lower()
    cat = (category or "").strip().lower()

    if not g and not cat:
        return None

    if "mug" in g:
        return "MUG"
    if "sticker" in g:
        return "STICKER"
    if g.startswith("dtf") or "ironon" in g.replace("-", "").replace(" ", ""):
        return "DTF"
    if "c800t" in g or "c8030" in g or "baby" in g or "body suit" in g:
        return "BABY"
    if g.startswith("cap") or "beanie" in g or "headwear" in cat:
        return "CAP"
    if g.startswith("bg-") or "bag" in g or cat == "bags":
        return "BAG"
    if "water" in g or "bottle" in g:
        return "BOTTLE"
    if "coat" in g or "hi-vis" in g or "waistcoat" in g:
        return "COAT"
    if "polo" in g or "polo" in cat:
        return "POLO"

    # Hoodie / sweatshirt
    if "hoodie" in g:
        if "kid" in g or "youth" in g or "child" in g:
            return "K-H"
        if "women" in g or "ladies" in g:
            return "W-H"
        return "M-H"
    if "sweat" in g:
        if "kid" in g or "youth" in g or "child" in g:
            return "K-SS"
        if "women" in g or "ladies" in g:
            return "W-SS"
        return "M-SS"

    # T-shirts / vests
    if any(x in g for x in ("t-shirt", "t shirt", " tee", "valueweight", "iconic", "softstyle", "heavy cotton", "original t", "vest", "tank")):
        if "kid" in g or "youth" in g or "child" in g:
            return "K-T"
        if "women" in g or "ladies" in g:
            return "W-T"
        return "M-T"

    if "t-shirts" in cat:
        if "children" in (category or "").lower() or "ladies" in (category or "").lower():
            pass
        return "M-T"

    return "OTHER"


LABEL_FAMILY_PATTERNS = [
    # Kids before adult so …K-T… never matches as mens
    (re.compile(r"(?i)(^|[-/])K-T($|[-/])"), "K-T"),
    (re.compile(r"(?i)(^|[-/])K-H($|[-/])"), "K-H"),
    (re.compile(r"(?i)(^|[-/])K-SS($|[-/])"), "K-SS"),
    (re.compile(r"(?i)(^|[-/])U-T($|[-/])"), "U-T"),
    (re.compile(r"(?i)(^|[-/])U-H($|[-/])"), "U-H"),
    # U-SS (e.g. U-SS-4XL) → treat as Men sweatshirt
    (re.compile(r"(?i)(^|[-/])U-SS($|[-/])"), "M-SS"),
    (re.compile(r"(?i)(^|[-/])W-T($|[-/])"), "W-T"),
    (re.compile(r"(?i)(^|[-/])W-H($|[-/])"), "W-H"),
    (re.compile(r"(?i)(^|[-/])W-SS($|[-/])"), "W-SS"),
    (re.compile(r"(?i)(^|[-/])M-T($|[-/])"), "M-T"),
    (re.compile(r"(?i)(^|[-/])M-H($|[-/])"), "M-H"),
    (re.compile(r"(?i)(^|[-/])M-SS($|[-/])"), "M-SS"),
    (re.compile(r"(?i)M61"), "MUG"),
    (re.compile(r"(?i)(^|[-/])MUG($|[-/])"), "MUG"),
    (re.compile(r"(?i)C800T"), "BABY"),
    (re.compile(r"(?i)(^|[-/])BG-"), "BAG"),
    (re.compile(r"(?i)IronOn|Iron-On|DTF"), "DTF"),
    (re.compile(r"(?i)STICKER"), "STICKER"),
    (re.compile(r"(?i)CUST-W-TT|W-TT"), "W-TT"),
    (re.compile(r"(?i)CUST-M-TT|M-TT"), "TANK"),
]


def family_from_label(label: str) -> str | None:
    s = str(label or "")
    for pat, fam in LABEL_FAMILY_PATTERNS:
        if pat.search(s):
            return fam
    return None


def is_kids_family(family: str | None) -> bool:
    f = (family or "").strip().upper()
    return f == "BABY" or f.startswith("K-")


def is_adult_apparel_family(family: str | None) -> bool:
    f = (family or "").strip().upper()
    if f.startswith("U-"):
        return True
    return f in {"M-T", "W-T", "M-H", "W-H", "M-SS", "W-SS", "W-TT", "TANK", "M-TT"} or (
        f.startswith("M-") or f.startswith("W-")
    )


def _title_has_unisex(title: str) -> bool:
    t = (title or "").lower()
    if "unisex" in t:
        return True
    if re.search(r"\bhim\s*(?:&|and)\s*her\b", t):
        return True
    if re.search(r"\bfor\s+him\s+(?:and|&)\s+her\b", t):
        return True
    if re.search(r"\b(?:men|mens)\s*(?:and|&)\s*(?:women|womens)\b", t):
        return True
    # Common listing style: "Mens Womens Graphic Tee" / "Mens … Ladies" size
    if re.search(
        r"\bmens?\b.*\b(womens?|woman|ladies)\b|\b(womens?|woman|ladies)\b.*\bmens?\b",
        t,
    ):
        return True
    return False


def _title_has_women(title: str) -> bool:
    t = (title or "").lower()
    return bool(
        re.search(r"\b(women|womens|woman|ladies|lady)\b", t)
    )


def _title_has_men(title: str) -> bool:
    """Men signal — must not match inside 'women'."""
    t = (title or "").lower()
    return bool(re.search(r"\b(mens|men|man's|for him)\b", t))


def _title_has_kids(title: str) -> bool:
    t = (title or "").lower()
    return bool(re.search(r"\b(kid|kids|child|children|youth|boys|girls|baby|toddler)\b", t))


def _apparel_base(family: str) -> str:
    """M-T / W-H / U-SS → T / H / SS."""
    f = family.upper()
    if f.endswith("-TT") or f == "TANK":
        return "TT"
    for suf in ("-SS", "-H", "-T", "-COAT"):
        if f.endswith(suf):
            return suf[1:]
    if "-" in f:
        return f.split("-", 1)[1]
    return "T"


def to_unisex_family(family: str | None) -> str:
    base = _apparel_base(family or "M-T")
    if base == "TT":
        return "U-TT"
    if base == "H":
        return "U-H"
    if base == "SS":
        return "M-SS"  # unisex SS → Men SS (same as U-SS-… labels)
    if base == "COAT":
        return "U-COAT"
    return "U-T"


def to_women_family(family: str | None) -> str:
    base = _apparel_base(family or "M-T")
    if base == "TT":
        return "W-TT"
    if base == "H":
        return "W-H"
    if base == "SS":
        return "W-SS"
    if base == "COAT":
        return "W-COAT"
    return "W-T"


def to_men_family(family: str | None) -> str:
    base = _apparel_base(family or "M-T")
    if base == "TT":
        return "TANK"
    if base == "H":
        return "M-H"
    if base == "SS":
        return "M-SS"
    if base == "COAT":
        return "COAT"
    return "M-T"


def resolve_gender_apparel(
    label: str, title: str, family: str | None
) -> tuple[str | None, str]:
    """
    Men / Women / Unisex for adult apparel.
    Clear unisex → U-*.
    Clear women title → W-* (even if label is M-T).
    Only title has BOTH men + women (no unisex) → Unmatched.
    Kids / non-apparel untouched.
    """
    if not family:
        return family, ""
    if is_kids_family(family) or family == "BABY":
        return family, ""
    if not is_adult_apparel_family(family):
        return family, ""

    tu = _title_has_unisex(title)
    tw = _title_has_women(title)
    tm = _title_has_men(title)
    tk = _title_has_kids(title)

    if tk:
        return family, ""  # kids override already applied upstream

    if tu:
        return to_unisex_family(family), "unisex"

    # Truly unclear only — both gender words, no unisex
    if tw and tm:
        return None, "unmatched-unclear"

    if tw and not tm:
        return to_women_family(family), "women-title"

    if tm and not tw:
        return to_men_family(family), "men-title"

    # No gender words → keep CSV/label
    return family, ""


def is_youth_or_baby_size(size: str | None) -> bool:
    """Youth / baby size tokens that must not stay as adult S/M/L."""
    s = str(size or "").strip().upper().replace(" ", "")
    if not s:
        return False
    if re.fullmatch(r"Y\d*XL|YXS|YS|YM|YL|Y\d+(-\d+)?", s):
        return True
    if re.fullmatch(r"\d+-\d+[MY]|0-3M|3-6M|6-12M|12-18M|18-24M|\d+-\d+Y", s):
        return True
    return False


def is_valid_summary_size(size: str | None) -> bool:
    """True only for real garment sizes — not SKU ids / SET codes / random tails."""
    s = str(size or "").strip().upper().replace(" ", "")
    if not s:
        return False
    # reject product ids, SET packs, long numeric tails
    if re.fullmatch(r"\d{4,}", s):
        return False
    if s.startswith("SET") or re.fullmatch(r"SET\d+", s):
        return False
    if re.fullmatch(
        r"(XXS|XS|S|M|L|XL|2XL|3XL|4XL|5XL|OS|O/S|"
        r"YXS|YS|YM|YL|YXL|Y2XL|Y3XL|Y4XL|"
        r"Y\d+(-\d+)?|"
        r"\d+-\d+Y|\d+-\d+M|"
        r"0-3M|3-6M|6-12M|12-18M|18-24M|"
        r"\d+OZ|A[3-6])",
        s,
    ):
        return True
    if is_youth_or_baby_size(s):
        return True
    return False


def _uss_as_men(family: str | None) -> str | None:
    """U-SS labels/titles always roll up as Men sweatshirt (M-SS)."""
    return "M-SS" if family == "U-SS" else family


def prefer_label_family(csv_family: str | None, label: str) -> str | None:
    """
    Clear codes in the custom label win (EXE / label-first).
    Example: …LG-M-T-… stays M-T even if title says Womens.
    …LG-K-T-… stays K-T even if CSV Gender is Mens.
    U-SS-… → M-SS.
    """
    from_label = family_from_label(label)
    if not from_label:
        return _uss_as_men(csv_family)
    if not csv_family:
        return _uss_as_men(from_label)
    # Any explicit apparel/product token in label beats CSV gender guess
    if from_label in {
        "M-T", "W-T", "K-T", "U-T",
        "M-H", "W-H", "K-H", "U-H",
        "M-SS", "W-SS", "K-SS", "U-SS",
        "BABY", "MUG", "BAG", "DTF", "STICKER", "W-TT", "TANK",
    }:
        return _uss_as_men(from_label)
    return _uss_as_men(csv_family)


def prefer_label_size(csv_size: str | None, label: str, family: str | None) -> str:
    """
    Use label size only when it is a real size token (e.g. Y2XL).
    Never replace CSV Small/M with SET10473 / 120852 / 2Years junk.
    """
    from_label = size_from_label(label)
    csv = (csv_size or "").strip()
    label_ok = is_valid_summary_size(from_label)
    csv_ok = is_valid_summary_size(csv)

    # Kids label with youth/baby size must win over wrong adult CSV size
    if label_ok and is_youth_or_baby_size(from_label):
        return from_label
    if label_ok and is_kids_family(family) and (not csv_ok or is_youth_or_baby_size(from_label)):
        # only if CSV missing/invalid — keep good CSV YS/YM/etc.
        if not csv_ok:
            return from_label
    if csv_ok:
        return csv
    if label_ok:
        return from_label
    return csv  # may be empty; better empty than SET/id


def size_from_label(label: str) -> str:
    """Best-effort size token from end of classic custom labels."""
    s = str(label or "")
    if "LG-" in s:
        s = s.split("LG-", 1)[1]
    parts = [p for p in s.split("-") if p]
    if not parts:
        return ""
    # drop trailing Yes/YES
    if parts[-1].lower() == "yes":
        parts = parts[:-1]
    if not parts:
        return ""
    token = parts[-1]
    # normalize common junk
    tok_u = token.upper().replace(" ", "")
    if tok_u in {"2YEARS", "2YEAR", "2YRS"}:
        return "2-3Y"
    if tok_u in {"3YEARS", "3YEAR", "3YRS"}:
        return "3-4Y"
    sized = short_size(token) or tok_u
    if not is_valid_summary_size(sized):
        return ""
    return sized


def summary_sku(family: str, size: str) -> str:
    fam = family.strip()
    sz = (size or "").strip()
    if not sz:
        return fam
    return f"{fam}-{sz}"


def family_from_title(title: str | None) -> str | None:
    """When SKU is plain/number, guess family from item title (Amazon caps etc.)."""
    t = (title or "").strip().lower()
    if not t:
        return None
    # print transfers / DTF
    if "iron on" in t or "iron-on" in t or "transfer" in t:
        return "DTF"
    if any(w in t for w in ("cap", "snapback", "beanie", "hat", "visor", "trucker")):
        return "CAP"
    # Beechfield + one size often = cap even if word 'cap' missing
    if "beechfield" in t and ("one size" in t or "fits all" in t):
        return "CAP"
    if "scarf" in t:
        return "SCARF"
    if "glove" in t:
        return "GLOVE"
    if "sock" in t:
        return "SOCK"
    if "slate" in t:
        return "SLATE"
    if "plaque" in t:
        return "PLAQUE"
    if "acrylic" in t:
        return "ACRYLIC"
    if "mug" in t or "cup" in t:
        return "MUG"
    # Pencil case before bag — "case" is not a tote/bag family
    if "pencil case" in t or "pencilcase" in t:
        return "PENCIL"
    if any(w in t for w in ("bag", "backpack", "tote", "gymsac", "rucksack")):
        return "BAG"
    if any(w in t for w in ("bottle", "flask")):
        return "BOTTLE"
    if any(w in t for w in ("tank top", "tanktop", "camisole", "vest top")):
        if any(w in t for w in ("kid", "child", "youth", "boys", "girls")):
            return "K-TT"
        if any(w in t for w in ("women", "ladies", "womens", "lady")):
            return "W-TT"
        return "TANK"
    if any(w in t for w in ("softshell", "jacket", "coat", "base layer")):
        if any(w in t for w in ("women", "ladies", "womens", "lady")):
            return "W-COAT"
        return "COAT"
    if "hoodie" in t:
        if any(w in t for w in ("kid", "child", "youth", "boys", "girls")):
            return "K-H"
        if _title_has_unisex(t):
            return "U-H"
        if any(w in t for w in ("women", "ladies", "womens", "lady")):
            return "W-H"
        return "M-H"
    if any(w in t for w in ("sweatshirt", "sweat shirt", "sweater", "crewneck", "fleece crew", "raglan")):
        if any(w in t for w in ("kid", "child", "youth", "boys", "girls")):
            return "K-SS"
        if _title_has_unisex(t):
            return "M-SS"  # unisex SS → Men SS
        if any(w in t for w in ("women", "ladies", "womens", "lady")):
            return "W-SS"
        return "M-SS"
    if any(
        w in t
        for w in (
            "t-shirt",
            "t shirt",
            "tshirt",
            " tee",
            "tee,",
            "tee ",
            "g500",
            "softstyle",
            "valueweight",
            "heavy cotton",
            "polo",
            "scrubs",
            "uneek",
        )
    ):
        if any(w in t for w in ("kid", "child", "youth", "boys", "girls", "baby")):
            return "K-T"
        if _title_has_unisex(t):
            return "U-T"
        if any(w in t for w in ("women", "ladies", "womens", "lady")):
            return "W-T"
        return "M-T"
    if "baby" in t or "bodysuit" in t or "body suit" in t:
        return "BABY"
    return None


def keyword_hint(label: str | None, title: str | None) -> str:
    """Keyword for Unmatched rows so team can see what the item looks like."""
    if _title_has_unisex(title or ""):
        return "UNISEX"
    if _title_has_women(title or "") and family_from_label(label or ""):
        lab = family_from_label(label or "")
        if lab and lab.startswith("M-"):
            return "UNCLEAR-MW"
    fam = family_from_title(title)
    if fam:
        return fam
    lab = str(label or "").upper()
    t = str(title or "").lower()
    if "CUST-W-TT" in lab or "W-TT" in lab or "tank" in t:
        return "W-TT"
    if "CUST" in lab:
        return "CUST"
    if "UNEKK" in lab or "uneek" in t:
        return "UNEKK"
    if "SET" in lab:
        return "SET"
    if re.fullmatch(r"\d+(\.\d+)?", str(label or "").strip()):
        return "PLAIN-NUMBER"
    if any(w in t for w in ("women", "ladies", "womens")):
        return "WOMENS"
    if any(w in t for w in ("men", "mens", "unisex")):
        return "MENS"
    if t.strip():
        # first meaningful word from title
        word = re.sub(r"[^a-z0-9]+", " ", t).strip().split()
        return (word[0].upper()[:12] if word else "UNKNOWN")
    return "UNKNOWN"


def size_from_title(title: str | None) -> str:
    t = (title or "").lower()
    if not t:
        return ""
    if "one size" in t or "o/s" in t or "fits all" in t:
        return "OS"
    # kids ages
    for phrase, code in (
        ("14-15", "Y14-15"),
        ("14/15", "Y14-15"),
        ("12-13", "Y12-13"),
        ("9-11", "YL"),
        ("7-8", "YM"),
        ("5-6", "YS"),
        ("3-4", "YXS"),
        ("a6", "A6"),
        ("a5", "A5"),
        ("a4", "A4"),
        ("a3", "A3"),
    ):
        if phrase in t:
            return code
    for phrase, code in (
        ("xxx-large", "3XL"),
        ("xx-large", "2XL"),
        ("x-large", "XL"),
        ("extra large", "XL"),
        ("2xl", "2XL"),
        ("3xl", "3XL"),
        ("4xl", "4XL"),
        ("5xl", "5XL"),
        ("large", "L"),
        ("medium", "M"),
        ("small", "S"),
    ):
        if phrase in t:
            return code
    m = re.search(r"\((XXS|XS|S|M|L|XL|2XL|3XL|4XL|5XL)\)", title or "", re.I)
    if m:
        return m.group(1).upper()
    # trailing size tokens like "- 1415" kids
    m2 = re.search(r"\b(1415|1213|911|78|56)\b", t)
    if m2:
        return {
            "1415": "Y14-15",
            "1213": "Y12-13",
            "911": "YL",
            "78": "YM",
            "56": "YS",
        }[m2.group(1)]
    return "OS" if "cap" in t or "beanie" in t or "hat" in t or "beechfield" in t else ""


def is_zero_vat(label: str, family: str | None = None) -> bool:
    """Kids / baby clothing — 0% sales VAT (UK children's clothing)."""
    s = str(label or "")
    if re.search(r"(?i)(^|[-/])K-", s) or "-K-" in s:
        return True
    if re.search(r"(?i)\bBABY\b", s) or s.upper().startswith("BABY"):
        return True
    if family and family.startswith("K-"):
        return True
    if family == "BABY":
        return True
    return False
