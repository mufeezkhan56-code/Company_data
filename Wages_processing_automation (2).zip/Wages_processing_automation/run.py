"""
Sale category summary generator.
Reads Ebay/Amazon sales file + Custom Label CSV → summary Excel (with sizes).
"""
from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.config_loader import load_config, resolve_path
from src.report_writer import build_summary_table, write_report
from src.sales_reader import classify_sales, read_sales_file
from src.sku_db import load_sku_db


def _fee_label_for(filename: str) -> str:
    name = filename.lower()
    if "amazon" in name or "customtransaction" in name:
        return "Amazon fee"
    if "temu" in name or "order_export" in name or "order-export" in name:
        return "Temu fee"
    if "etsy" in name:
        return "Etsy fee"
    if "ebay" in name:
        return "Ebay fee"
    return "Marketplace fee"


def _channel_name_for(filename: str) -> str:
    """Short channel tag for output file names."""
    name = filename.lower()
    if "amazon" in name or "customtransaction" in name:
        return "Amazon"
    if "temu" in name or "order_export" in name or "order-export" in name:
        return "Temu"
    if "etsy" in name:
        return "Etsy"
    if "ebay" in name:
        return "eBay"
    return "Sales"


def _downloads_dir() -> Path:
    return Path.home() / "Downloads"


def _this_pc_dir() -> str:
    """Windows 'This PC' shell folder; otherwise user home."""
    if sys.platform == "win32":
        # Same place as File Explorer → This PC
        return r"::{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
    return str(Path.home())


def _list_sales_candidates(folder: Path) -> list[Path]:
    files = [
        *folder.glob("*.xlsx"),
        *folder.glob("*.xls"),
        *folder.glob("*.csv"),
    ]
    files = [p for p in files if not p.name.startswith("~$")]
    return sorted(files, key=lambda p: p.stat().st_mtime, reverse=True)


def _pick_sales_file_dialog() -> Path | None:
    """
    Open Windows-style file Open dialog (This PC / drives / folders).
    Returns selected path, or None if cancelled.
    Raises RuntimeError if tkinter is unavailable.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception as exc:
        raise RuntimeError(f"tkinter unavailable: {exc}") from exc

    root = tk.Tk()
    root.withdraw()
    try:
        root.attributes("-topmost", True)
    except tk.TclError:
        pass

    try:
        chosen = filedialog.askopenfilename(
            parent=root,
            title="Select sales Excel or CSV",
            initialdir=_this_pc_dir(),
            filetypes=[
                ("Sales files", "*.xlsx *.xls *.csv"),
                ("Excel", "*.xlsx *.xls"),
                ("CSV", "*.csv"),
                ("All files", "*.*"),
            ],
        )
    finally:
        root.destroy()

    if not chosen:
        return None
    return Path(chosen)


def _pick_from_downloads_list() -> Path | None:
    """Fallback: numbered list from Downloads (old behaviour)."""
    downloads = _downloads_dir()
    if not downloads.exists():
        print(f"Downloads folder not found: {downloads}")
        print("Or drag a sales file onto run-summary.bat")
        return None
    candidates = _list_sales_candidates(downloads)
    if not candidates:
        print("No Excel/CSV files found in your Downloads.")
        print(f"Folder: {downloads}")
        print("Or drag a sales file onto run-summary.bat")
        return None
    print(f"Your Downloads: {downloads}")
    print()
    for i, p in enumerate(candidates, start=1):
        print(f"  {i}. {p.name}")
    print()
    print("Type the number of the file to use (or Enter to cancel):")
    choice = input("> ").strip()
    if not choice:
        print("Cancelled. No summary created.")
        return None
    if not choice.isdigit() or not (1 <= int(choice) <= len(candidates)):
        print(f"Invalid choice: {choice}")
        return None
    return candidates[int(choice) - 1]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Build sale category summary (with size) from sales file + SKU CSV."
    )
    parser.add_argument(
        "sales_file",
        nargs="?",
        help="Path to sales Excel/CSV. If omitted, opens a file window (This PC)",
    )
    parser.add_argument(
        "--sku-csv",
        default=None,
        help="Custom Label Database CSV path",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Output Excel path (optional)",
    )
    args = parser.parse_args(argv)

    cfg = load_config()
    root = Path(cfg.get("_root", ROOT))

    if args.sales_file:
        sales_path = Path(args.sales_file)
        if not sales_path.is_absolute():
            sales_path = (root / sales_path).resolve()
    else:
        print("Opening file window — pick a sales Excel/CSV (This PC / any folder)...")
        try:
            sales_path = _pick_sales_file_dialog()
        except RuntimeError as exc:
            print(f"File window not available ({exc}). Using Downloads list instead.")
            sales_path = _pick_from_downloads_list()
            if sales_path is None:
                return 1
        else:
            if sales_path is None:
                print("Cancelled. No summary created.")
                print("(Tip: you can also drag a file onto run-summary.bat)")
                return 0
        print(f"Selected: {sales_path}")

    if not sales_path.exists():
        print(f"Sales file not found: {sales_path}")
        return 1

    # Default: <sales-folder>/output/summary-<Channel>-<timestamp>.xlsx
    output_dir = sales_path.parent / "output"
    fallback_out = resolve_path(cfg, "output_folder", "data/output")
    fallback_out.mkdir(parents=True, exist_ok=True)
    channel = _channel_name_for(sales_path.name)

    sku_csv = Path(args.sku_csv) if args.sku_csv else resolve_path(
        cfg, "sku_csv", "Custom_Label_Database 2 (1).csv"
    )
    if not sku_csv.is_absolute():
        sku_csv = (root / sku_csv).resolve()
    if not sku_csv.exists():
        print(f"SKU CSV not found: {sku_csv}")
        return 1

    print("=== Sale Summary Generator ===")
    print(f"Sales file : {sales_path}")
    print(f"SKU CSV    : {sku_csv}")

    print("Loading SKU database...")
    db = load_sku_db(str(sku_csv))
    print(f"SKU rows loaded: {len(db.df)}")

    print("Reading sales...")
    sales = read_sales_file(sales_path)
    print(f"Order lines: {len(sales)}")

    print("Matching custom labels...")
    classified = classify_sales(sales, db)
    matched = int(classified["summary_sku"].notna().sum())
    print(f"Classified : {matched} / {len(classified)}")

    summary, unmatched = build_summary_table(classified, cfg)
    print(f"Summary SKUs (with size): {len(summary)}")
    print(f"Unmatched lines         : {len(unmatched)}")

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_name = f"summary-{channel}-{stamp}.xlsx"
    if args.out:
        out_path = Path(args.out)
        if not out_path.is_absolute():
            out_path = (root / out_path).resolve()
    else:
        out_path = output_dir / out_name
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            test = out_path.parent / ".write_test"
            test.write_text("ok", encoding="utf-8")
            test.unlink(missing_ok=True)
        except OSError:
            print(f"Cannot write to {output_dir} — using project data/output instead.")
            out_path = fallback_out / out_name

    write_report(
        classified,
        summary,
        unmatched,
        out_path,
        channel,
        fee_label=_fee_label_for(sales_path.name),
    )
    print()
    print(f"DONE. Output: {out_path}")
    if len(summary):
        print("Top summary rows:")
        print(summary[["Sku", "Qty", "Sale Price"]].head(15).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
