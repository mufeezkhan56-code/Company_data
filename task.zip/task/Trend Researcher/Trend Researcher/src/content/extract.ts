export function getPlatform(): string | null {
  const h = window.location.hostname;
  if (h.includes('amazon')) return 'amazon';
  if (h.includes('ebay')) return 'ebay';
  if (h.includes('etsy')) return 'etsy';
  return null;
}

export const platform = getPlatform();

export function getCards(): HTMLElement[] {
  if (platform === 'amazon') {
    return Array.from(document.querySelectorAll<HTMLElement>(
      "[data-asin]:not([data-asin='']), " +
      ".s-result-item[data-asin], " +
      ".rush-component[data-component-type='s-search-result'], " +
      "#gridItemRoot, " +
      ".zg-grid-general-faceout, " +
      ".p13n-sc-uncoverable-faceout, " +
      "div[id^='p13n-asin-index-'], " +
      ".a-cardui._cDEzb_grid-cell_1uMOS"
    ));
  }
  if (platform === 'ebay') {
    const items = Array.from(document.querySelectorAll<HTMLElement>('.s-item')).filter(
      c => !c.classList.contains('s-item--summary')
    );
    if (items.length > 0) return items;
    const seen = new Set<HTMLElement>();
    const cards: HTMLElement[] = [];
    document.querySelectorAll<HTMLAnchorElement>('a[href*="/itm/"]').forEach(a => {
      const container = a.closest('li') || a.closest('article') || a.parentElement;
      if (container && !seen.has(container)) { seen.add(container); cards.push(container); }
    });
    return cards;
  }
  if (platform === 'etsy') {
    return Array.from(document.querySelectorAll<HTMLElement>(
      'li[data-palette-listing-id], [data-listing-id], .v2-listing-card, .listing-card'
    ));
  }
  return [];
}

export interface ExtractedProduct {
  title: string;
  imageUrl: string;
  productUrl: string;
  platform: string;
  platformId: string;
  price: string;
}

function extractAmazon(card: HTMLElement): ExtractedProduct {
  let asin = card.getAttribute('data-asin');
  if (!asin) { const p = card.closest('[data-asin]'); if (p) asin = p.getAttribute('data-asin'); }
  if (!asin) { const l = card.querySelector<HTMLAnchorElement>("a[href*='/dp/']"); if (l) { const m = l.href.match(/\/dp\/([A-Z0-9]{10})/); if (m) asin = m[1]; } }
  asin = asin || '';

  const titleSelectors = [
    "a.a-text-normal", "[data-cy='title-recipe'] a", "h2 a span.a-text-normal", "h2 a", "h2",
    "._cDEzb_p13n-sc-css-line-clamp-3_g3dy1", ".p13n-sc-line-clamp-1", ".p13n-sc-line-clamp-2",
    "[data-cy='title-recipe'] span", "div.a-truncate-full", "a[title]",
  ];
  let title = '';
  for (const sel of titleSelectors) {
    const el = card.querySelector(sel);
    if (el) {
      const text = (el.getAttribute('title') || el.textContent || '').trim();
      if (text.length > 3 && !/^[\£\$\€\¥]/.test(text) && !/^\d+[\.,]\d{2}$/.test(text)) { title = text; break; }
    }
  }

  const imgEl = card.querySelector<HTMLImageElement>('img.s-image, img');
  const imageUrl = imgEl?.src || imgEl?.getAttribute('data-src') || '';
  const linkEl = card.querySelector<HTMLAnchorElement>("a.a-link-normal.s-no-outline, a.a-link-normal[href*='/dp/'], a[href*='/sspa/click'], h2 a, a.a-link-normal");
  let productUrl = '';
  if (linkEl) {
    let href = linkEl.getAttribute('href') || '';
    if (href.includes('/sspa/click')) {
      try {
        const sspaUrl = new URL(href.startsWith('http') ? href : `https://www.amazon.co.uk${href}`);
        const realPath = sspaUrl.searchParams.get('url');
        if (realPath) {
          const decoded = decodeURIComponent(realPath);
          const m = decoded.match(/\/dp\/([A-Z0-9]{10})/);
          if (m) productUrl = `https://www.amazon.co.uk/dp/${m[1]}`;
        }
      } catch (e) {}
    } else if (href) {
      if (!href.startsWith('http')) href = `https://www.amazon.co.uk${href}`;
      try { productUrl = new URL(href).origin + new URL(href).pathname; } catch (e) {}
    }
  }
  if (!productUrl && asin) productUrl = `https://www.amazon.co.uk/dp/${asin}`;
  const priceEl = card.querySelector('.a-price .a-offscreen');
  const price = priceEl?.textContent?.trim() || '';
  return { title, imageUrl, productUrl, platform: 'amazon', platformId: asin, price };
}

function extractEbay(card: HTMLElement): ExtractedProduct {
  const linkEl = card.querySelector<HTMLAnchorElement>('a.s-item__link, a[href*="/itm/"]');
  const href = linkEl?.href || '';
  const m = href.match(/\/itm\/(?:[^?]*\/)?(\d{8,})/);
  const id = m ? m[1] : '';
  const productUrl = href.split('?')[0];
  const titleSelectors = [
    '.s-item__title span[role="heading"]',
    '.s-item__title span:not(.SECONDARY_INFO)',
    '.s-item__title', 'h3.s-item__title',
    '.str-item-card__property--title span', '.str-item-card__property--title',
    '.b-tile__title', '.b-tile__title a', '.brwrvr__item-title',
    'h3 a', 'h3',
    'a[href*="/itm/"] span', 'a[href*="/itm/"]',
    '.bsig__title',
  ];
  let title = '';
  for (const sel of titleSelectors) {
    const el = card.querySelector(sel);
    if (el) {
      const text = (el.getAttribute('title') || el.textContent || '').trim();
      if (text.length > 3 && !/^(New Listing|Shop on eBay|Results|Sponsored)$/i.test(text)) {
        title = text.replace(/^New Listing\s*/i, '').replace(/^Sponsored\s*/i, '');
        break;
      }
    }
  }
  const imgEl = card.querySelector<HTMLImageElement>('.s-item__image-img, img[src*="ebayimg"], img');
  const imageUrl = imgEl?.src || imgEl?.getAttribute('data-src') || '';
  const priceEl = card.querySelector('.s-item__price');
  const price = priceEl?.textContent?.trim() || '';
  return { title, imageUrl, productUrl, platform: 'ebay', platformId: id, price };
}

function extractEtsy(card: HTMLElement): ExtractedProduct {
  const id = card.getAttribute('data-palette-listing-id') || card.getAttribute('data-listing-id') || '';
  const linkEl = card.querySelector<HTMLAnchorElement>('a[href*="/listing/"]');
  const href = linkEl?.href || '';
  const productUrl = href.split('?')[0];
  const titleEl = card.querySelector<HTMLElement>('.v2-listing-card__title, [data-listing-id] h3, img');
  const title = titleEl?.getAttribute('alt') || titleEl?.textContent?.trim() || '';
  const imgEl = card.querySelector<HTMLImageElement>('img');
  const imageUrl = imgEl?.src || imgEl?.getAttribute('data-src') || '';
  const priceEl = card.querySelector('.currency-value, .v2-listing-card__price');
  const price = priceEl?.textContent?.trim() || '';
  return { title, imageUrl, productUrl, platform: 'etsy', platformId: id, price };
}

export function extractProduct(card: HTMLElement): ExtractedProduct | null {
  if (platform === 'amazon') return extractAmazon(card);
  if (platform === 'ebay') return extractEbay(card);
  if (platform === 'etsy') return extractEtsy(card);
  return null;
}
