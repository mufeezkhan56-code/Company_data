import { platform, getCards, extractProduct } from './extract';
import { closeActiveDropdown, addSaveButton, markButtonSaved } from './ui';
import TrendResearcherDB from '../db';

const ATTR = 'data-tr-processed';

if (platform) {
  document.addEventListener('click', e => {
    const target = e.target as HTMLElement;
    if (!target.closest('.tr-dropdown') && !target.closest('.tr-save-btn')) {
      closeActiveDropdown();
    }
  });

  // ─── Saved-state cache ────────────────────────────────────────────────────────
  // One batch fetch instead of N per-card isProductSaved() calls.
  // Map: platformId → { id, categoryName }
  let _savedMap: Map<string, { id: string; categoryName: string }> | null = null;
  let _savedMapPromise: Promise<Map<string, { id: string; categoryName: string }>> | null = null;

  function invalidateSavedMap(): void { _savedMap = null; _savedMapPromise = null; }

  async function getSavedMap(): Promise<Map<string, { id: string; categoryName: string }>> {
    if (_savedMap) return _savedMap;
    if (_savedMapPromise) return _savedMapPromise;
    _savedMapPromise = TrendResearcherDB.getSavedMap().then((raw: Record<string, any> | null) => {
      _savedMap = new Map(Object.entries(raw || {}));
      _savedMapPromise = null;
      return _savedMap!;
    });
    return _savedMapPromise;
  }

  // Invalidate when background signals a DB change
  chrome.runtime.onMessage.addListener((msg: any) => {
    if (msg.type === 'db_changed') invalidateSavedMap();
  });

  // ─── Card processing ─────────────────────────────────────────────────────────
  async function processCards(): Promise<void> {
    type Entry = { btn: HTMLButtonElement; platformId: string };
    const newEntries: Entry[] = [];

    getCards().forEach(card => {
      if (card.hasAttribute(ATTR)) return;
      card.setAttribute(ATTR, '1');
      const product = extractProduct(card);
      if (!product?.productUrl) return;
      const btn = addSaveButton(card, product);  // sync, no await
      if (product.platformId) newEntries.push({ btn, platformId: product.platformId });
    });

    if (!newEntries.length) return;

    // One batch lookup for all new cards
    const map = await getSavedMap();
    for (const { btn, platformId } of newEntries) {
      const info = map.get(platformId);
      if (info) markButtonSaved(btn, info.categoryName);
    }
  }

  // ─── MutationObserver — narrowed scope ───────────────────────────────────────
  function getObserveRoot(): Element {
    if (platform === 'amazon') {
      return (
        document.querySelector('[data-component-type="s-search-results"]') ||
        document.querySelector('#search') ||
        document.querySelector('.s-result-list-with-asins') ||
        document.body
      )!;
    }
    if (platform === 'ebay') {
      return (
        document.querySelector('#srp-river-results') ||
        document.querySelector('.srp-results') ||
        document.body
      )!;
    }
    if (platform === 'etsy') {
      return (
        document.querySelector('[data-search-pagination-label]') ||
        document.querySelector('.search-listings-group') ||
        document.body
      )!;
    }
    return document.body;
  }

  processCards();

  let debounce: number;
  const observer = new MutationObserver(() => {
    clearTimeout(debounce);
    debounce = window.setTimeout(processCards, 300);
  });

  observer.observe(getObserveRoot(), { childList: true, subtree: true });

  // Retry for late-rendered content
  [1000, 2500].forEach(d => window.setTimeout(processCards, d));

  // Disconnect on unload to prevent leaks
  window.addEventListener('pagehide', () => observer.disconnect(), { once: true });
}
