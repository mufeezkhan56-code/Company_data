import TrendResearcherDB from '../db';
import type { ExtractedProduct } from './extract';

let activeDropdown: HTMLElement | null = null;

// ─── XSS-safe HTML escaping ────────────────────────────────────────────────────
function esc(str: any): string {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

// ─── Categories cache — invalidated on db_changed ──────────────────────────────
let _categoriesCache: any[] | null = null;
try {
  chrome.runtime.onMessage.addListener((msg: any) => {
    if (msg.type === 'db_changed') _categoriesCache = null;
  });
} catch (_) {}

async function getCachedCategories(): Promise<any[]> {
  if (!_categoriesCache) _categoriesCache = await TrendResearcherDB.getCategories();
  return _categoriesCache!;
}

// ─── Dropdown ──────────────────────────────────────────────────────────────────
export function closeActiveDropdown(): void {
  if (activeDropdown) {
    activeDropdown.remove();
    activeDropdown = null;
  }
}

/**
 * Position the dropdown so it never bleeds off the right/bottom edge of the
 * viewport. Falls back to left-anchoring if the button is near the right edge.
 */
function positionDropdown(dropdown: HTMLElement, btn: HTMLButtonElement): void {
  const rect   = btn.getBoundingClientRect();
  const DDW    = 220; // approximate dropdown width (matches CSS)
  const scrollX = window.scrollX;
  const scrollY = window.scrollY;

  let left = rect.left + scrollX;
  let top  = rect.bottom + scrollY + 4;

  // Clamp right edge
  const rightEdge = left + DDW;
  if (rightEdge > document.documentElement.clientWidth) {
    left = Math.max(0, rect.right + scrollX - DDW);
  }

  dropdown.style.top  = `${top}px`;
  dropdown.style.left = `${left}px`;
}

export async function showDropdown(btn: HTMLButtonElement, product: ExtractedProduct): Promise<void> {
  closeActiveDropdown();

  // Parallel fetch — was sequential (2 round trips → 2 parallel)
  const [categories, saved] = await Promise.all([
    getCachedCategories(),
    TrendResearcherDB.isProductSaved(product.productUrl, product.platformId),
  ]);

  const dropdown = document.createElement('div');
  dropdown.className   = 'tr-dropdown';
  dropdown.setAttribute('role', 'menu');
  dropdown.setAttribute('aria-label', 'Save product options');

  if (saved) {
    dropdown.innerHTML = `
      <div class="tr-dropdown-header" role="presentation">Already saved</div>
      <div class="tr-dropdown-saved-info" role="presentation">
        <span class="tr-type-badge tr-type-${esc(saved.categoryType)}">${esc(saved.categoryType)}</span>
        <span>${esc(saved.categoryName)}</span>
      </div>
      <button class="tr-dropdown-remove" data-id="${esc(saved.id)}"
              role="menuitem" aria-label="Remove this product from ${esc(saved.categoryName)}">
        ✕ Remove from saved
      </button>
    `;

    const removeBtn = dropdown.querySelector('.tr-dropdown-remove') as HTMLButtonElement;
    removeBtn.addEventListener('click', async () => {
      await TrendResearcherDB.deleteProduct(saved.id);
      btn.classList.remove('tr-saved');
      btn.textContent = '+';
      btn.setAttribute('aria-label', 'Save to Trend Researcher');
      btn.title = 'Save to Trend Researcher';
      closeActiveDropdown();
    });

  } else {
    const types = ['event', 'trend', 'asset'];
    const byType: Record<string, any[]> = {};
    types.forEach(t => { byType[t] = categories.filter((c: any) => c.type === t); });

    dropdown.innerHTML = `
      <div class="tr-dropdown-header" role="presentation">Save to…</div>
      <div class="tr-type-tabs" role="tablist" aria-label="Category type">
        ${types.map(t => `
          <button class="tr-type-tab" data-type="${esc(t)}"
                  role="tab" aria-selected="false"
                  aria-controls="tr-cat-list"
                  id="tr-tab-${esc(t)}">
            ${esc(t.charAt(0).toUpperCase() + t.slice(1))}
          </button>`).join('')}
      </div>
      <div class="tr-cat-list" id="tr-cat-list" role="tabpanel" aria-live="polite"></div>
    `;

    const catList = dropdown.querySelector('#tr-cat-list') as HTMLElement;

    function renderCats(type: string) {
      const cats = byType[type] || [];
      catList.innerHTML = '';

      if (cats.length === 0) {
        const msg = document.createElement('div');
        msg.className   = 'tr-no-cats';
        msg.textContent = `No ${type}s yet.`;

        // Provide an actionable next step rather than just explaining the dead-end
        const hint = document.createElement('a');
        hint.className  = 'tr-no-cats-link';
        hint.href       = chrome.runtime.getURL('dashboard.html');
        hint.target     = '_blank';
        hint.rel        = 'noopener noreferrer';
        hint.textContent = `Open dashboard to add a ${type}`;

        catList.appendChild(msg);
        catList.appendChild(hint);
        return;
      }

      catList.innerHTML = cats.map((c: any) => `
        <button class="tr-cat-item"
                data-cat-id="${esc(c.id)}"
                data-cat-name="${esc(c.name)}"
                data-cat-type="${esc(c.type)}"
                role="menuitem"
                aria-label="Save to ${esc(c.name)} (${esc(c.productCount || 0)} products)">
          ${esc(c.name)}
          <span class="tr-cat-count" aria-hidden="true">${esc(c.productCount || 0)}</span>
        </button>
      `).join('');

      catList.querySelectorAll('.tr-cat-item').forEach(item => {
        const btnItem = item as HTMLButtonElement;
        btnItem.addEventListener('click', async () => {
          _categoriesCache = null; // invalidate after structural change
          await TrendResearcherDB.saveProduct({
            ...product,
            categoryId:   btnItem.dataset.catId,
            categoryType: btnItem.dataset.catType,
            categoryName: btnItem.dataset.catName,
          });
          btn.classList.add('tr-saved');
          btn.textContent = '✓';
          btn.setAttribute('aria-label', `Saved to ${btnItem.dataset.catName}`);
          btn.title = `Saved to ${btnItem.dataset.catName}`;
          closeActiveDropdown();
        });
      });
    }

    let activeType = types[0];
    renderCats(activeType);

    dropdown.querySelectorAll('.tr-type-tab').forEach(tab => {
      const btnTab = tab as HTMLButtonElement;
      const isActive = btnTab.dataset.type === activeType;
      if (isActive) {
        btnTab.classList.add('tr-type-tab-active');
        btnTab.setAttribute('aria-selected', 'true');
      }
      btnTab.addEventListener('click', () => {
        dropdown.querySelectorAll('.tr-type-tab').forEach(t => {
          t.classList.remove('tr-type-tab-active');
          t.setAttribute('aria-selected', 'false');
        });
        btnTab.classList.add('tr-type-tab-active');
        btnTab.setAttribute('aria-selected', 'true');
        activeType = btnTab.dataset.type!;
        renderCats(activeType);
      });
    });
  }

  document.body.appendChild(dropdown);
  positionDropdown(dropdown, btn);
  activeDropdown = dropdown;

  // Move focus into the dropdown for keyboard users
  const firstFocusable = dropdown.querySelector<HTMLElement>('button, a');
  firstFocusable?.focus();
}

// ─── Keyboard: close dropdown on Escape ────────────────────────────────────────
document.addEventListener('keydown', (e: KeyboardEvent) => {
  if (e.key === 'Escape' && activeDropdown) closeActiveDropdown();
}, { capture: true });

// ─── addSaveButton — sync; saved-state is marked in bulk by processCards() ─────
export function addSaveButton(card: HTMLElement, product: ExtractedProduct): HTMLButtonElement {
  const btn = document.createElement('button');
  btn.className = 'tr-save-btn';
  btn.textContent = '+';
  btn.setAttribute('aria-label', 'Save to Trend Researcher');
  btn.title = 'Save to Trend Researcher';

  btn.addEventListener('click', e => {
    e.preventDefault();
    e.stopPropagation();
    showDropdown(btn, product);
  });

  card.style.position = 'relative';
  card.appendChild(btn);
  return btn;
}

export function markButtonSaved(btn: HTMLButtonElement, categoryName: string): void {
  btn.classList.add('tr-saved');
  btn.textContent = '✓';
  btn.setAttribute('aria-label', `Saved to ${categoryName}`);
  btn.title = `Saved to ${categoryName}`;
}
