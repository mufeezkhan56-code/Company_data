export function handleStageActions(action: string, payload: any, db: IDBDatabase): Promise<any> | null {
  switch (action) {
    case 'clearStages': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('stages', 'readwrite');
        tx.objectStore('stages').clear();
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'importStages': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('stages', 'readwrite');
        const store = tx.objectStore('stages');
        for (const item of payload) store.put(item);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'getAllStageIds': {
      return new Promise((resolve) => {
        const tx = db.transaction('stages', 'readonly');
        const req = tx.objectStore('stages').getAllKeys();
        req.onsuccess = () => resolve(req.result as string[]);
        req.onerror = () => resolve([]);
      });
    }

    case 'getAllStages': {
      return new Promise((resolve) => {
        const tx = db.transaction('stages', 'readonly');
        const req = tx.objectStore('stages').getAll();
        req.onsuccess = () => resolve(req.result as any[]);
        req.onerror = () => resolve([]);
      });
    }

    case 'lookupStages': {
      return new Promise((resolve) => {
        const tx = db.transaction('stages', 'readonly');
        const store = tx.objectStore('stages');
        const result: Record<string, any> = {};
        let pending = (payload as string[]).length;
        if (pending === 0) return resolve(result);
        for (const id of payload as string[]) {
          const req = store.get(id);
          req.onsuccess = () => {
            if (req.result) result[id] = req.result;
            if (--pending === 0) resolve(result);
          };
          req.onerror = () => { if (--pending === 0) resolve(result); };
        }
      });
    }

    default: return null;
  }
}
