function extractIdSw(url: string | undefined): string | null {
  if (!url) return null;
  const amz  = url.match(/\/dp\/([A-Z0-9]{10})/);
  if (amz)  return 'amz_'  + amz[1];
  const ebay = url.match(/\/itm\/(?:[^?]*\/)?(\d{8,})/);
  if (ebay) return 'ebay_' + ebay[1];
  const etsy = url.match(/\/listing\/(\d+)/);
  if (etsy) return 'etsy_' + etsy[1];
  return null;
}

export function handleProductActions(action: string, payload: any, db: IDBDatabase, notifyDashboard: () => void): Promise<any> | null {
  switch (action) {
    case 'getPagedProducts': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('products', 'readonly');
        const store = tx.objectStore('products');
        const sortBy = payload.sortBy || 'date';
        let request: IDBRequest<IDBCursorWithValue | null>;
        if (payload.categoryId) {
          if (sortBy === 'bsr') {
            request = store.index('by_cat_bsr').openCursor(IDBKeyRange.bound([payload.categoryId, 0], [payload.categoryId, 999999999]), 'next');
          } else {
            request = store.index('by_categoryId').openCursor(IDBKeyRange.only(payload.categoryId), 'prev');
          }
        } else {
          if (sortBy === 'bsr') {
            request = store.index('by_bsr').openCursor(null, 'next');
          } else {
            request = store.index('by_savedAt').openCursor(null, 'prev');
          }
        }
        const results: any[] = [];
        let matchedCount = 0;
        const limit = payload.limit || 50;
        const offset = payload.offset || 0;
        const query = (payload.query || '').toLowerCase();
        const platformFilter = (payload.platform || '').toLowerCase();
        request.onsuccess = (event: Event) => {
          const cursor = (event.target as IDBRequest<IDBCursorWithValue | null>).result;
          if (!cursor) { resolve(results); return; }
          const p = cursor.value;
          let isMatch = true;
          if (query) {
            isMatch = (p.title || '').toLowerCase().includes(query) ||
                      (p.categoryName || '').toLowerCase().includes(query) ||
                      (p.platform || '').toLowerCase().includes(query);
          }
          if (platformFilter) isMatch = isMatch && (p.platform || '').toLowerCase() === platformFilter;
          if (isMatch) {
            if (matchedCount >= offset) results.push(p);
            matchedCount++;
          }
          if (results.length >= limit) resolve(results);
          else cursor.continue();
        };
        request.onerror = (e: Event) => reject((e.target as IDBRequest).error);
      });
    }

    case 'saveProduct': {
      // Atomically save product AND increment category count in one transaction
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['products', 'categories'], 'readwrite');
        tx.objectStore('products').put(payload);
        if (payload.categoryId) {
          const catStore = tx.objectStore('categories');
          const req = catStore.get(payload.categoryId);
          req.onsuccess = () => {
            if (req.result) {
              catStore.put({ ...req.result, productCount: (req.result.productCount || 0) + 1, updatedAt: new Date().toISOString() });
            }
          };
        }
        tx.oncomplete = () => { notifyDashboard(); resolve(true); };
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'deleteProduct': {
      // Atomically delete product AND decrement category count in one transaction
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['products', 'categories'], 'readwrite');
        const prodStore = tx.objectStore('products');
        const req = prodStore.get(payload.id);
        req.onsuccess = () => {
          const prod = req.result;
          prodStore.delete(payload.id);
          if (prod?.categoryId) {
            const catStore = tx.objectStore('categories');
            const catReq = catStore.get(prod.categoryId);
            catReq.onsuccess = () => {
              if (catReq.result) {
                catStore.put({ ...catReq.result, productCount: Math.max((catReq.result.productCount || 1) - 1, 0), updatedAt: new Date().toISOString() });
              }
            };
          }
        };
        tx.oncomplete = () => { notifyDashboard(); resolve(true); };
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'updateProduct': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('products', 'readwrite');
        const store = tx.objectStore('products');
        const req = store.get(payload.id);
        req.onsuccess = () => {
          if (!req.result) return resolve(false);
          store.put({ ...req.result, ...payload.updates });
          resolve(true);
        };
        req.onerror = () => reject(req.error);
      });
    }

    case 'getProduct': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('products', 'readonly');
        const req = tx.objectStore('products').get(payload.id);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    case 'isProductSaved': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('products', 'readonly');
        const store = tx.objectStore('products');
        let found = false;
        if (payload.platformId) {
          const req = store.index('by_platformId').get(payload.platformId);
          req.onsuccess = () => {
            if (req.result) { found = true; return resolve(req.result); }
            fallbackScan();
          };
          req.onerror = () => reject(req.error);
        } else { fallbackScan(); }
        function fallbackScan() {
          if (found) return;
          const req = store.openCursor();
          req.onsuccess = (e) => {
            const cursor = (e.target as IDBRequest).result as IDBCursorWithValue;
            if (!cursor) return resolve(null);
            const p = cursor.value;
            if (payload.platformId && p.platformId === payload.platformId) return resolve(p);
            const pUrlId = extractIdSw(p.productUrl);
            const reqUrlId = extractIdSw(payload.productUrl);
            if (pUrlId && reqUrlId && pUrlId === reqUrlId) return resolve(p);
            cursor.continue();
          };
          req.onerror = () => reject(req.error);
        }
      });
    }

    case 'getProductCount': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('products', 'readonly');
        const req = tx.objectStore('products').count();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    case 'getAllProductPlatformIds': {
      return new Promise((resolve) => {
        const tx = db.transaction('products', 'readonly');
        const req = tx.objectStore('products').getAll();
        req.onsuccess = () => {
          const ids = (req.result as any[])
            .filter(p => p.platformId)
            .map(p => (p.platform === 'amazon' ? 'amz' : p.platform) + '_' + p.platformId);
          resolve(ids);
        };
        req.onerror = () => resolve([]);
      });
    }

    case 'getSavedMap': {
      // Returns { [platformId]: { id, categoryName } } for all saved products
      return new Promise((resolve) => {
        const tx = db.transaction('products', 'readonly');
        const req = tx.objectStore('products').getAll();
        req.onsuccess = () => {
          const map: Record<string, { id: string; categoryName: string }> = {};
          for (const p of req.result as any[]) {
            if (p.platformId) map[p.platformId] = { id: p.id, categoryName: p.categoryName || '' };
          }
          resolve(map);
        };
        req.onerror = () => resolve({});
      });
    }

    default: return null;
  }
}
