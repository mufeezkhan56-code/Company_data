export function handleCategoryActions(action: string, payload: any, db: IDBDatabase, notifyDashboard: () => void): Promise<any> | null {
  switch (action) {
    case 'getCategory': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('categories', 'readonly');
        const req = tx.objectStore('categories').get(payload.id);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    case 'getCategories': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('categories', 'readonly');
        const req = tx.objectStore('categories').getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
    }

    case 'createCategory': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('categories', 'readwrite');
        tx.objectStore('categories').put(payload);
        tx.oncomplete = () => resolve(payload.id);
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'updateCategory': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('categories', 'readwrite');
        const store = tx.objectStore('categories');
        const req = store.get(payload.id);
        req.onsuccess = () => {
          if (!req.result) return resolve(false);
          store.put({ ...req.result, ...payload.updates });
          resolve(true);
        };
        req.onerror = () => reject(req.error);
      });
    }

    case 'deleteCategory': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['categories', 'products'], 'readwrite');
        tx.objectStore('categories').delete(payload.id);
        const pStore = tx.objectStore('products');
        const req = pStore.index('by_categoryId').openCursor(IDBKeyRange.only(payload.id));
        req.onsuccess = (e) => {
          const cursor = (e.target as IDBRequest).result as IDBCursorWithValue;
          if (cursor) { cursor.delete(); cursor.continue(); }
        };
        tx.oncomplete = () => { notifyDashboard(); resolve(true); };
        tx.onerror = () => reject(tx.error);
      });
    }

    default: return null;
  }
}
