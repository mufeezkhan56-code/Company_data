import { migrateFromChromeStorage } from './migration';

export const DB_NAME = 'TrendResearcher';
export const DB_VERSION = 5;

let dbPromise: Promise<IDBDatabase> | null = null;

export function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const tx = (event.target as IDBOpenDBRequest).transaction;

      let productStore: IDBObjectStore;

      if (!db.objectStoreNames.contains('products')) {
        productStore = db.createObjectStore('products', { keyPath: 'id' });
        productStore.createIndex('by_platformId', 'platformId', { unique: false });
        productStore.createIndex('by_categoryId', 'categoryId', { unique: false });
        productStore.createIndex('by_savedAt', 'savedAt', { unique: false });
      } else {
        productStore = tx!.objectStore('products');
      }

      if (!productStore.indexNames.contains('by_bsr')) {
        productStore.createIndex('by_bsr', 'bsrNumber', { unique: false });
      }
      if (!productStore.indexNames.contains('by_cat_bsr')) {
        productStore.createIndex('by_cat_bsr', ['categoryId', 'bsrNumber'], { unique: false });
      }

      // V3: force-recreate by_savedAt to fix old installs where it pointed to 'createdAt'
      if (event.oldVersion < 3 && productStore.indexNames.contains('by_savedAt')) {
        productStore.deleteIndex('by_savedAt');
      }
      if (!productStore.indexNames.contains('by_savedAt')) {
        productStore.createIndex('by_savedAt', 'savedAt', { unique: false });
      }

      if (!db.objectStoreNames.contains('categories')) {
        const catStore = db.createObjectStore('categories', { keyPath: 'id' });
        catStore.createIndex('by_type', 'type', { unique: false });
      }

      if (!db.objectStoreNames.contains('stages')) {
        db.createObjectStore('stages', { keyPath: 'id' });
      }

      if (!db.objectStoreNames.contains('listings')) {
        const ls = db.createObjectStore('listings', { keyPath: 'id', autoIncrement: true });
        ls.createIndex('by_designId', 'designId', { unique: false });
      }
    };

    request.onsuccess = async (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      resolve(db);
    };

    request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error);
  });

  return dbPromise;
}

export function backfillMissingFields(db: IDBDatabase): void {
  const tx = db.transaction('products', 'readwrite');
  const store = tx.objectStore('products');
  store.openCursor().onsuccess = (e) => {
    const cursor = (e.target as IDBRequest).result as IDBCursorWithValue;
    if (!cursor) return;
    const p = cursor.value;
    let dirty = false;
    if (p.bsrNumber === undefined) {
      const m = String(p.bsr || '').replace(/,/g, '').match(/\d+/);
      p.bsrNumber = m ? parseInt(m[0], 10) : 999999999;
      dirty = true;
    }
    if (!p.savedAt) {
      p.savedAt = p.createdAt || p.addedAt || new Date().toISOString();
      dirty = true;
    }
    if (dirty) cursor.update(p);
    cursor.continue();
  };
}

// Ensure migration happens on startup if old data exists
getDB().then(db => {
  migrateFromChromeStorage(db);
  backfillMissingFields(db);
});
