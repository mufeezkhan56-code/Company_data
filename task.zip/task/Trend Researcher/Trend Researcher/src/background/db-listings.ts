export function handleListingActions(action: string, payload: any, db: IDBDatabase): Promise<any> | null {
  switch (action) {
    case 'importListings': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('listings', 'readwrite');
        const store = tx.objectStore('listings');
        store.clear();
        for (const item of payload as Array<{ designId: string; channel: string; listingLink: string; title: string }>) {
          store.add(item);
        }
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'clearListings': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('listings', 'readwrite');
        tx.objectStore('listings').clear();
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'lookupListingsByDesignIds': {
      return new Promise((resolve) => {
        const ids = payload as string[];
        if (ids.length === 0) return resolve([]);
        const tx = db.transaction('listings', 'readonly');
        const store = tx.objectStore('listings');
        const index = store.index('by_designId');
        const results: any[] = [];
        let pending = ids.length;
        for (const designId of ids) {
          const req = index.getAll(IDBKeyRange.only(designId));
          req.onsuccess = () => {
            if (req.result && req.result.length > 0) results.push(...req.result);
            if (--pending === 0) resolve(results);
          };
          req.onerror = () => { if (--pending === 0) resolve(results); };
        }
      });
    }

    case 'getListingsCount': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('listings', 'readonly');
        const req = tx.objectStore('listings').count();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    case 'getAllListings': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction('listings', 'readonly');
        const req = tx.objectStore('listings').getAll();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
    }

    default: return null;
  }
}
