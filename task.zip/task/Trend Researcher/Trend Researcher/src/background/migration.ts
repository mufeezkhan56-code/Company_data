/// <reference types="chrome" />

export async function migrateFromChromeStorage(db: IDBDatabase): Promise<void> {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(null, (data) => {
      if (chrome.runtime.lastError) {
        return reject(chrome.runtime.lastError);
      }
      
      // If we don't have indexes, it's either brand new or already migrated
      if (!data || !data['_prod_index']) {
        return resolve();
      }

      const tx = db.transaction(['products', 'categories'], 'readwrite');
      const pStore = tx.objectStore('products');
      const cStore = tx.objectStore('categories');

      const catIndex = data['_cat_index'] || [];
      const prodIndex = data['_prod_index'] || [];

      try {
        for (const cid of catIndex) {
          const cat = data[`cat_${cid}`];
          if (cat) cStore.put(cat);
        }

        for (const pid of prodIndex) {
          const prod = data[`prod_${pid}`];
          if (prod) {
            if (prod.bsrNumber === undefined) {
              const m = String(prod.bsr || '').replace(/,/g, '').match(/\d+/);
              prod.bsrNumber = m ? parseInt(m[0], 10) : 999999999;
            }
            pStore.put(prod);
          }
        }
      } catch (e) {
        return reject(e);
      }

      tx.oncomplete = () => {
        // Once successfully transferred, clear out the choking legacy memory limit
        chrome.storage.local.clear(() => resolve());
      };
      
      tx.onerror = () => {
        reject(tx.error);
      };
    });
  });
}
