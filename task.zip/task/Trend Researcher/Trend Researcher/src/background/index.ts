/// <reference types="chrome" />
import { getDB, backfillMissingFields } from './db-setup';
import { handleProductActions } from './db-products';
import { handleCategoryActions } from './db-categories';
import { handleStageActions } from './db-stages';
import { handleListingActions } from './db-listings';
import { migrateFromChromeStorage } from './migration';

export { getDB, backfillMissingFields };

// Ensure migration happens on startup if old data exists
getDB().then(db => {
  migrateFromChromeStorage(db);
  backfillMissingFields(db);
});

export function extractBsrNumber(bsrString: string): number {
  if (!bsrString || bsrString === 'N/A' || bsrString === 'Error') return 999999999;
  const match = bsrString.replace(/,/g, '').match(/\d+/);
  if (match) return parseInt(match[0], 10);
  return 999999999;
}

function notifyDashboard(): void {
  chrome.runtime.sendMessage({ type: 'db_changed' }).catch(() => {});
}

async function handleAction(action: string, payload: any): Promise<any> {
  const db = await getDB();

  // Try each handler module in order
  const productResult = handleProductActions(action, payload, db, notifyDashboard);
  if (productResult !== null) return productResult;

  const categoryResult = handleCategoryActions(action, payload, db, notifyDashboard);
  if (categoryResult !== null) return categoryResult;

  const stageResult = handleStageActions(action, payload, db);
  if (stageResult !== null) return stageResult;

  const listingResult = handleListingActions(action, payload, db);
  if (listingResult !== null) return listingResult;

  // Remaining actions handled inline
  switch (action) {
    case 'clearAll': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['products', 'categories'], 'readwrite');
        tx.objectStore('products').clear();
        tx.objectStore('categories').clear();
        tx.oncomplete = () => { notifyDashboard(); resolve(true); };
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'exportAll': {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['products', 'categories', 'stages'], 'readonly');
        const pReq = tx.objectStore('products').getAll();
        const cReq = tx.objectStore('categories').getAll();
        const sReq = tx.objectStore('stages').getAll();
        tx.oncomplete = () => resolve({
          categories: cReq.result,
          products: pReq.result,
          stages: sReq.result,
          exportedAt: new Date().toISOString(),
        });
        tx.onerror = () => reject(tx.error);
      });
    }

    case 'importAll': {
      return new Promise((resolve, reject) => {
        const { products = [], categories = [], stages = [] } = payload;
        const tx = db.transaction(['products', 'categories', 'stages'], 'readwrite');
        const pStore = tx.objectStore('products');
        const cStore = tx.objectStore('categories');
        const sStore = tx.objectStore('stages');
        pStore.getAllKeys().onsuccess = (e) => {
          const existing = new Set((e.target as IDBRequest).result as string[]);
          for (const item of products) if (!existing.has(item.id)) pStore.put(item);
        };
        cStore.getAllKeys().onsuccess = (e) => {
          const existing = new Set((e.target as IDBRequest).result as string[]);
          for (const item of categories) if (!existing.has(item.id)) cStore.put(item);
        };
        sStore.getAllKeys().onsuccess = (e) => {
          const existing = new Set((e.target as IDBRequest).result as string[]);
          for (const item of stages) if (!existing.has(item.id)) sStore.put(item);
        };
        tx.oncomplete = () => { notifyDashboard(); resolve(true); };
        tx.onerror = () => reject(tx.error);
      });
    }

    default:
      throw new Error(`Unknown action: ${action}`);
  }
}

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.type === 'db_action') {
    handleAction(request.action, request.payload)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(error => sendResponse({ success: false, error: String(error) }));
    return true;
  }
});
