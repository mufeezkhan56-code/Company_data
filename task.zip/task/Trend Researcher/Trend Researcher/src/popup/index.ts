import TrendResearcherDB from '../db';

(async () => {
  const [count, categories] = await Promise.all([
    TrendResearcherDB.getProductCount(),
    TrendResearcherDB.getCategories(),
  ]);

  const totalProducts = document.getElementById('totalProducts');
  const totalCategories = document.getElementById('totalCategories');
  const openDashboard = document.getElementById('openDashboard');

  if (totalProducts) totalProducts.textContent = String(count || 0);
  if (totalCategories) totalCategories.textContent = String(categories.length || 0);

  if (openDashboard) {
    openDashboard.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
    });
  }
})();