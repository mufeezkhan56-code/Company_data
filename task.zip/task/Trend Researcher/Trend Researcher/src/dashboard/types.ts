import type { Product } from '../db/products';
import type { Category } from '../db/categories';

export interface DashboardContext {
  currentView: string;
  currentType: string | null;
  allProducts: Product[];
  allCategories: Category[];
  searchQuery: string;
  selectMode: boolean;
  selectedIds: Set<string>;
  fetchingNow: boolean;
  pendingCatType: string | null;
  productsOffset: number;
  hasMoreProducts: boolean;
  sortBy: string;
  platformFilter: string | null;
  stageFilter: 'in-csv' | 'not-in-csv' | null;
  stageIds: Set<string> | null;
  stageNameFilter: string | null;
  stageDataMap: Map<string, string> | null;
  promotionFilters: Map<string, 'yes' | 'no'>;
  seoFilters: Map<string, 'yes' | 'no'>;
  listingsFilter: Map<string, 'yes' | 'no'>;
  listingsChannelsMap: Map<string, Set<string>> | null; // stageId → Set<'amazon'|'ebay'|'etsy'>
  refs: {
    searchInput: HTMLInputElement;
    catModal: HTMLElement;
    catModalTitle: HTMLElement;
    catName: HTMLInputElement;
    catDesc: HTMLInputElement;
    selectBtn: HTMLButtonElement;
    fetchBsrBtn: HTMLButtonElement;
    selectCount: HTMLElement;
    fetchBar: HTMLElement;
    fetchBarFill: HTMLElement;
    fetchBarText: HTMLElement;
    catStatusGroup: HTMLElement;
    catEventStatus: HTMLSelectElement;
    editEventStatus: HTMLSelectElement;
  };
  refresh: (append?: boolean) => Promise<void>;
  selectView: (view: string, type?: string | null) => void;
  updateSelectCount: () => void;
}
