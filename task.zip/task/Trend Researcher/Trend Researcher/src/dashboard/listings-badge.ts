import TrendResearcherDB from '../db';
import type { Product } from '../db/products';
import type { ListingItem } from './listings';

const DESIGN_ID_FIELDS = [
  'designId', 'colourfulDesignId', 'blackDesignId', 'whiteDesignId',
  'designMen', 'designWomen', 'designBoy', 'designGirl',
  'designBabyBoy', 'designBabyGirl',
] as const;

export async function applyListingsBadges(products: Product[]): Promise<void> {
  if (!products.length) return;

  const stageIds = products
    .filter(p => p.platformId)
    .map(p => (p.platform === 'amazon' ? 'amz' : p.platform) + '_' + p.platformId);

  if (!stageIds.length) return;

  const stageMap = await TrendResearcherDB.lookupStages(stageIds) as Record<string, any> | null;
  if (!stageMap || !Object.keys(stageMap).length) return;

  // Collect every designId needed across ALL products in one pass
  const allDesignIds = new Set<string>();
  const productToDesignIds = new Map<string, string[]>();

  for (const product of products) {
    if (!product.platformId) continue;
    const key = (product.platform === 'amazon' ? 'amz' : product.platform) + '_' + product.platformId;
    const record = stageMap[key];
    if (!record) continue;

    const ids = Array.from(new Set(
      DESIGN_ID_FIELDS.map(f => (record[f] || '').trim()).filter(Boolean)
    ));
    if (!ids.length) continue;

    productToDesignIds.set(product.id, ids);
    ids.forEach(id => allDesignIds.add(id));
  }

  if (!allDesignIds.size) return;

  // ONE batch DB call instead of N sequential calls
  const allListings = await TrendResearcherDB.lookupListingsByDesignIds([...allDesignIds]) as ListingItem[];
  if (!allListings?.length) return;

  // Group by designId for fast lookup
  const byDesignId = new Map<string, ListingItem[]>();
  for (const listing of allListings) {
    const arr = byDesignId.get(listing.designId) ?? [];
    arr.push(listing);
    byDesignId.set(listing.designId, arr);
  }

  // Apply badges
  for (const product of products) {
    const designIds = productToDesignIds.get(product.id);
    if (!designIds) continue;

    const listings: ListingItem[] = [];
    for (const id of designIds) {
      const ls = byDesignId.get(id);
      if (ls) listings.push(...ls);
    }
    if (!listings.length) continue;

    const card = document.querySelector(`.product-card[data-id="${product.id}"]`);
    if (!card) continue;

    const btn = card.querySelector('.listings-toggle-btn') as HTMLElement | null;
    if (!btn) continue;

    btn.style.display = 'block';
    btn.dataset.listings = JSON.stringify(listings);
  }
}
