import TrendResearcherDB from '../db';
import type { Product } from '../db/products';

export const STAGE_COLORS: Record<string, string> = {
  'marketing':      '#00c853',
  'design':         '#2196F3',
  'legalreview':    '#ff9900',
  'legalreject':    '#f44336',
  'design-late':    '#9c27b0',
  'marketing-late': '#1b5e20',
  'legal':          '#ff6f00',
  'done':           '#607d8b',
};

export function getStageColor(stage: string): string {
  if (!stage) return '#9e9e9e';
  return STAGE_COLORS[stage.toLowerCase().replace(/\s+/g, '-')] || '#9e9e9e';
}

// ─── CSV Parser ───────────────────────────────────────────────────────────────

function parseCSV(text: string): string[][] {
  const rows: string[][] = [];
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const cols: string[] = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQ) {
        if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') inQ = false;
        else cur += ch;
      } else {
        if (ch === '"') inQ = true;
        else if (ch === ',') { cols.push(cur.trim()); cur = ''; }
        else cur += ch;
      }
    }
    cols.push(cur.trim());
    rows.push(cols);
  }
  return rows;
}

function parseDate(s: string): Date | null {
  if (!s) return null;
  const dmy = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (dmy) return new Date(`${dmy[3]}-${dmy[2].padStart(2,'0')}-${dmy[1].padStart(2,'0')}`);
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

function extractIdFromUrl(url: string): string | null {
  if (!url) return null;
  const amz = url.match(/amazon\.[a-z.]+\/(?:.*\/)?(?:dp|gp\/product)\/([A-Z0-9]{10})/);
  if (amz) return 'amz_' + amz[1];
  const ebay = url.match(/ebay\.[a-z.]+\/itm\/(?:[^?]*\/)?(\d{8,})/);
  if (ebay) return 'ebay_' + ebay[1];
  if (url.includes('ebay')) { const m = url.match(/(\d{10,})/); if (m) return 'ebay_' + m[1]; }
  const etsy = url.match(/etsy\.com\/.*?listing\/(\d+)/);
  if (etsy) return 'etsy_' + etsy[1];
  return null;
}

export interface StageItem {
  id: string;
  stage: string;
  productName: string;
  designName: string;
  inputDate: string;
  stageDays: string;
  designId?: string;
  colourfulDesignId?: string;
  blackDesignId?: string;
  whiteDesignId?: string;
  designMen?: string;
  designWomen?: string;
  designBoy?: string;
  designGirl?: string;
  designBabyBoy?: string;
  designBabyGirl?: string;
}

export function parseCSVToStageItems(text: string): StageItem[] {
  const rows = parseCSV(text);
  if (rows.length < 2) return [];

  const headers = rows[0].map(h => h.replace(/^"|"$/g, '').trim().toLowerCase());
  const col = (name: string) => headers.indexOf(name.toLowerCase());

  const colLink    = col('product link');
  const colStage   = col('current stage');
  const colName    = col('product name');
  const colDesign  = col('design name');
  const colDate    = col('input date');
  const colDId     = col('design id');
  const colColId   = col('colourful design id');
  const colBlkId   = col('black design id');
  const colWhtId   = col('white design id');
  const colDMen    = col('design-men');
  const colDWomen  = col('design-women');
  const colDBoy    = col('design-boy');
  const colDGirl   = col('design-girl');
  const colDBabyB  = col('design-baby boy');
  const colDBabyG  = col('design-baby girl');

  if (colLink === -1 || colStage === -1) return [];

  const stageDateCols: Record<number, number> = {};
  headers.forEach((h, i) => {
    if (h.endsWith(' - date') && h !== 'input date') {
      const dIdx = headers.indexOf(h.replace(' - date', ' - days'));
      stageDateCols[i] = dIdx;
    }
  });

  const items: StageItem[] = [];
  for (const r of rows.slice(1)) {
    const url = (r[colLink] || '').trim();
    if (!url) continue;
    const id = extractIdFromUrl(url);
    if (!id) continue;

    let stageDays = '';
    let latestMs = 0;
    Object.entries(stageDateCols).forEach(([dIdx, dyIdx]) => {
      const dateVal = (r[+dIdx] || '').trim();
      if (!dateVal) return;
      const d = parseDate(dateVal);
      if (d && d.getTime() > latestMs) {
        latestMs = d.getTime();
        stageDays = dyIdx !== -1 ? (r[dyIdx] || '') : '';
      }
    });

    items.push({
      id,
      stage:            (r[colStage] || 'unknown').trim(),
      productName:      colName   !== -1 ? (r[colName]   || '') : '',
      designName:       colDesign !== -1 ? (r[colDesign] || '') : '',
      inputDate:        colDate   !== -1 ? (r[colDate]   || '') : '',
      stageDays,
      designId:         colDId    !== -1 ? (r[colDId]    || '').trim() : '',
      colourfulDesignId:colColId  !== -1 ? (r[colColId]  || '').trim() : '',
      blackDesignId:    colBlkId  !== -1 ? (r[colBlkId]  || '').trim() : '',
      whiteDesignId:    colWhtId  !== -1 ? (r[colWhtId]  || '').trim() : '',
      designMen:        colDMen   !== -1 ? (r[colDMen]   || '').trim() : '',
      designWomen:      colDWomen !== -1 ? (r[colDWomen] || '').trim() : '',
      designBoy:        colDBoy   !== -1 ? (r[colDBoy]   || '').trim() : '',
      designGirl:       colDGirl  !== -1 ? (r[colDGirl]  || '').trim() : '',
      designBabyBoy:    colDBabyB !== -1 ? (r[colDBabyB] || '').trim() : '',
      designBabyGirl:   colDBabyG !== -1 ? (r[colDBabyG] || '').trim() : '',
    });
  }
  return items;
}

// ─── Import + Lookup ──────────────────────────────────────────────────────────

export async function importStagesFromFile(
  file: File,
  onProgress: (pct: number, msg: string) => void
): Promise<{ imported: number }> {
  onProgress(0, 'Reading file…');
  const text = await file.text();
  const items = parseCSVToStageItems(text);
  if (items.length === 0) { onProgress(0, 'No valid rows found'); return { imported: 0 }; }

  onProgress(10, `Importing ${items.length} rows…`);
  await TrendResearcherDB.clearStages();

  const CHUNK = 500;
  for (let i = 0; i < items.length; i += CHUNK) {
    await TrendResearcherDB.importStages(items.slice(i, i + CHUNK));
    onProgress(10 + Math.round(((i + CHUNK) / items.length) * 90), `${Math.min(i + CHUNK, items.length)} / ${items.length}`);
  }
  onProgress(100, `Done — ${items.length} products imported`);
  return { imported: items.length };
}

export async function loadAllStageIds(): Promise<Set<string>> {
  const ids = await TrendResearcherDB.getAllStageIds() as string[];
  return new Set(ids);
}

// ─── Apply Badges to Cards ────────────────────────────────────────────────────

function platformPrefix(platform: string): string {
  return platform === 'amazon' ? 'amz' : platform;
}

function formatDateShort(s: string): string {
  if (!s) return '';
  const d = parseDate(s);
  if (!d) return '';
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

export async function applyStagesBadges(products: Product[]): Promise<void> {
  const lookup = products
    .filter(p => p.platformId)
    .map(p => ({ productId: p.id, stageId: `${platformPrefix(p.platform)}_${p.platformId}` }));

  if (lookup.length === 0) return;

  const stageMap = await TrendResearcherDB.lookupStages(lookup.map(x => x.stageId));
  if (!stageMap || Object.keys(stageMap).length === 0) return;

  for (const { productId, stageId } of lookup) {
    const data = stageMap[stageId];
    if (!data) continue;
    const card = document.querySelector(`.product-card[data-id="${productId}"]`) as HTMLElement | null;
    if (!card) continue;

    const color = getStageColor(data.stage);
    card.style.borderColor = color;
    card.style.borderWidth = '2px';

    const slot = card.querySelector('.pst-badge-slot') as HTMLElement | null;
    if (!slot || slot.hasChildNodes()) continue;

    const sub = [
      data.inputDate ? '📅 ' + formatDateShort(data.inputDate) : '',
      data.stageDays ? data.stageDays + ' days' : '',
    ].filter(Boolean).join(' · ');

    const badge = document.createElement('div');
    badge.className = 'pst-badge';
    badge.style.background = color;
    const stageSpan = document.createElement('span');
    stageSpan.textContent = data.stage.toUpperCase();
    badge.appendChild(stageSpan);
    if (sub) {
      const subEl = document.createElement('small');
      subEl.textContent = sub;
      badge.appendChild(subEl);
    }
    slot.innerHTML = '';
    slot.appendChild(badge);
  }
}
