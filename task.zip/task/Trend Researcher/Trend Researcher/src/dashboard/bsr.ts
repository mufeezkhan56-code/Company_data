import TrendResearcherDB from '../db';
import type { DashboardContext } from './types';
import { buildBsrHtml } from './grid';
import { fetchEbayDemandSignal, fetchEtsyDemandSignal } from './demand';

export function extractBsrNumber(bsrString: string): number {
  if (!bsrString || bsrString === 'N/A' || bsrString === 'Error') return 999999999;
  const match = bsrString.replace(/,/g, '').match(/\d+/);
  if (match) return parseInt(match[0], 10);
  return 999999999;
}

export async function fetchBSRForUrl(productUrl: string) {
  try {
    const res = await fetch(productUrl, {
      credentials: 'include',
      headers: { 'Accept': 'text/html', 'Accept-Language': 'en-GB,en;q=0.9' },
    });
    if (!res.ok) return { bsr: 'Fetch failed', dispatches: 'N/A', soldBy: 'N/A' };

    const html = await res.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    let bsr = 'N/A';

    for (const th of Array.from(doc.querySelectorAll('#productDetails_detailBullets_sections1 th'))) {
      if (th.textContent?.includes('Best Sellers Rank')) { bsr = th.nextElementSibling?.textContent?.trim() || 'N/A'; break; }
    }
    if (bsr === 'N/A') {
      for (const th of Array.from(doc.querySelectorAll('#productDetails_techSpec_section_1 th'))) {
        if (th.textContent?.includes('Best Sellers Rank')) { bsr = th.nextElementSibling?.textContent?.trim() || 'N/A'; break; }
      }
    }
    if (bsr === 'N/A') {
      for (const li of Array.from(doc.querySelectorAll('#detailBullets_feature_div li'))) {
        if (li.textContent?.includes('Best Sellers Rank')) { bsr = li.textContent.replace('Best Sellers Rank:', '').trim(); break; }
      }
    }
    if (bsr === 'N/A') {
      const el = doc.querySelector('#SalesRank > .a-list-item');
      if (el) bsr = el.textContent?.trim() || 'N/A';
    }

    let dispatches = 'N/A', soldBy = 'N/A';
    const merchant = doc.querySelector('#merchant-info');
    if (merchant) dispatches = merchant.textContent?.trim() || 'N/A';
    if (dispatches === 'N/A') {
      const rows = doc.querySelectorAll('#tabular-buybox .tabular-buybox-text');
      if (rows.length >= 2) { dispatches = rows[0]?.textContent?.trim() || 'N/A'; soldBy = rows[1]?.textContent?.trim() || 'N/A'; }
    }

    let rating = 'N/A', reviewCount = 'N/A';
    const ratingEl = doc.querySelector('span[data-hook="rating-out-of-text"], #acrPopover');
    if (ratingEl) rating = ratingEl.textContent?.trim() || 'N/A';
    const reviewEl = doc.querySelector('#acrCustomerReviewText');
    if (reviewEl) reviewCount = reviewEl.textContent?.trim() || 'N/A';

    return { bsr, dispatches, soldBy, rating, reviewCount };
  } catch {
    return { bsr: 'Error', dispatches: 'N/A', soldBy: 'N/A', rating: 'N/A', reviewCount: 'N/A' };
  }
}

function demandSignalHtml(signal: string, icon: string): string {
  return `<span class="bsr-val">${icon} ${signal}</span>`;
}

export function initBSR(ctx: DashboardContext): void {
  const { fetchBsrBtn, fetchBar, fetchBarFill, fetchBarText, selectBtn, selectCount } = ctx.refs;

  fetchBsrBtn.addEventListener('click', async () => {
    if (ctx.selectedIds.size === 0 || ctx.fetchingNow) return;

    ctx.fetchingNow = true;
    fetchBsrBtn.disabled = true;
    fetchBar.classList.add('visible');

    const ids = Array.from(ctx.selectedIds);
    const total = ids.length;
    let done = 0;

    for (const id of ids) {
      const prod = ctx.allProducts.find(p => p.id === id);
      const platform = prod?.platform;
      if (!prod || (platform !== 'amazon' && platform !== 'ebay' && platform !== 'etsy')) {
        done++;
        continue;
      }

      const card = document.querySelector(`.product-card[data-id="${id}"]`);
      if (card) {
        let bsrEl = card.querySelector('.product-card-bsr');
        if (!bsrEl) {
          bsrEl = document.createElement('div');
          bsrEl.className = 'product-card-bsr';
          card.querySelector('.product-card-body')!.appendChild(bsrEl);
        }
        bsrEl.innerHTML = '<em style="color:#2980b9;font-size:10px;">Fetching…</em>';
      }

      if (platform === 'ebay') {
        const signal = await fetchEbayDemandSignal(prod.productUrl);
        const bsr = signal || 'N/A';
        const n = signal ? parseInt(signal.match(/\d+/)?.[0] || '1', 10) : 0;
        await TrendResearcherDB.updateProduct(id, { bsr, bsrNumber: signal ? 999999999 - n : 999999999 });
        if (card) {
          const bsrEl = card.querySelector('.product-card-bsr');
          if (bsrEl) bsrEl.innerHTML = signal ? demandSignalHtml(signal, '🔥') : '';
        }
      } else if (platform === 'etsy') {
        const signal = await fetchEtsyDemandSignal(prod.productUrl);
        const bsr = signal || 'N/A';
        const n = signal ? parseInt(signal.match(/\d+/)?.[0] || '1', 10) : 0;
        await TrendResearcherDB.updateProduct(id, { bsr, bsrNumber: signal ? 999999999 - n : 999999999 });
        if (card) {
          const bsrEl = card.querySelector('.product-card-bsr');
          if (bsrEl) bsrEl.innerHTML = signal ? demandSignalHtml(signal, '🛒') : '';
        }
      } else {
        if (!prod.productUrl || prod.productUrl.includes('/sspa/')) {
          if (prod.platformId) prod.productUrl = `https://www.amazon.co.uk/dp/${prod.platformId}`;
          else { done++; continue; }
        }
        const result = await fetchBSRForUrl(prod.productUrl);
        await TrendResearcherDB.updateProduct(id, {
          bsr: result.bsr,
          bsrNumber: extractBsrNumber(result.bsr),
          dispatches: result.dispatches,
          soldBy: result.soldBy,
          rating: result.rating,
          reviewCount: result.reviewCount,
        });
        if (card) {
          const bsrEl = card.querySelector('.product-card-bsr');
          if (bsrEl) bsrEl.innerHTML = buildBsrHtml(result as any);
        }
      }

      done++;
      fetchBarFill.style.width = Math.round((done / total) * 100) + '%';
      fetchBarText.textContent = `${done} / ${total}`;
    }

    ctx.fetchingNow = false;
    ctx.selectMode = false;
    ctx.selectedIds.clear();
    document.body.classList.remove('select-mode');
    selectBtn.textContent = '☑ Select';
    selectBtn.classList.remove('active');
    selectCount.style.display = 'none';
    fetchBsrBtn.disabled = true;

    setTimeout(() => { fetchBar.classList.remove('visible'); fetchBarFill.style.width = '0%'; }, 2000);
    await ctx.refresh();
  });
}
