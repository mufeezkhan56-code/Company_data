import TrendResearcherDB from '../db';
import type { DashboardContext } from './types';
import type { Product } from '../db/products';
import { applyStagesBadges } from './stages';
import { buildCardHtml } from './grid-card';
import { applyListingsBadges } from './listings-badge';

export { escHtml, buildBsrHtml } from './grid-card';

export function getFilteredProducts(ctx: DashboardContext): Product[] {
  let products = ctx.allProducts;
  if (ctx.currentView !== 'all') {
    products = products.filter(p => p.categoryId === ctx.currentView);
  }
  if (ctx.searchQuery) {
    const q = ctx.searchQuery.toLowerCase();
    products = products.filter(p =>
      (p.title || '').toLowerCase().includes(q) ||
      (p.categoryName || '').toLowerCase().includes(q) ||
      (p.platform || '').toLowerCase().includes(q)
    );
  }
  if (ctx.stageFilter && ctx.stageIds) {
    const pfx = (p: Product) => (p.platform === 'amazon' ? 'amz' : p.platform) + '_' + p.platformId;
    if (ctx.stageFilter === 'in-csv')
      products = products.filter(p => p.platformId && ctx.stageIds!.has(pfx(p)));
    else
      products = products.filter(p => !p.platformId || !ctx.stageIds!.has(pfx(p)));
  }
  if (ctx.promotionFilters.size > 0) {
    products = products.filter(p => {
      const promos = new Set(p.promotions || []);
      for (const [promoId, state] of ctx.promotionFilters) {
        if (state === 'yes' && !promos.has(promoId)) return false;
        if (state === 'no' && promos.has(promoId)) return false;
      }
      return true;
    });
  }
  if (ctx.seoFilters.size > 0) {
    products = products.filter(p => {
      const seo = p.seoChecklist || {};
      for (const [seoId, state] of ctx.seoFilters) {
        const done = seo[seoId] === true;
        if (state === 'yes' && !done) return false;
        if (state === 'no'  &&  done) return false;
      }
      return true;
    });
  }

  if (ctx.listingsFilter.size > 0 && ctx.listingsChannelsMap) {
    products = products.filter(p => {
      const key = p.platformId
        ? (p.platform === 'amazon' ? 'amz' : p.platform) + '_' + p.platformId
        : null;
      const channels = (key && ctx.listingsChannelsMap!.get(key)) ?? new Set<string>();
      for (const [platform, state] of ctx.listingsFilter) {
        if (state === 'yes' && !channels.has(platform)) return false;
        if (state === 'no'  &&  channels.has(platform)) return false;
      }
      return true;
    });
  }

  if (ctx.stageNameFilter && ctx.stageDataMap) {
    const pfx = (p: Product) => (p.platform === 'amazon' ? 'amz' : p.platform) + '_' + p.platformId;
    const target = ctx.stageNameFilter.toLowerCase();
    products = products.filter(p => {
      if (!p.platformId) return false;
      const stageName = ctx.stageDataMap!.get(pfx(p));
      return stageName?.toLowerCase() === target;
    });
  }
  return products;
}

export function renderSidebar(ctx: DashboardContext): void {
  ['event', 'trend', 'asset'].forEach(type => {
    const list = document.getElementById(`${type}-list`)!;
    const cats = ctx.allCategories.filter(c => c.type === type);

    if ((type === 'event' || type === 'trend') && cats.length > 0) {
      const upcoming = cats.filter(c => c.eventStatus === 'upcoming');
      const current = cats.filter(c => c.eventStatus === 'current');
      const past = cats.filter(c => c.eventStatus === 'past');
      const unassigned = cats.filter(c => !c.eventStatus);

      function renderGroup(title: string, groupCats: typeof cats) {
        if (groupCats.length === 0) return '';
        const groupId = `group-${title.toLowerCase()}`;
        return `
          <div class="sidebar-group-title toggle-btn" data-target="${groupId}">
            <span>${title}</span><span class="chevron">▼</span>
          </div>
          <div class="sidebar-group-list" id="${groupId}">
            ${groupCats.map(c => `
              <div class="sidebar-item ${ctx.currentView === c.id ? 'active' : ''}" data-view="${c.id}" data-type="${type}">
                <span>${c.name}</span>
                <span class="sidebar-item-count">${c.productCount || 0}</span>
              </div>`).join('')}
          </div>`;
      }

      list.innerHTML = renderGroup('Current', current) + renderGroup('Upcoming', upcoming)
        + renderGroup('Past', past) + renderGroup('Other', unassigned);
    } else {
      list.innerHTML = cats.map(c => `
        <div class="sidebar-item ${ctx.currentView === c.id ? 'active' : ''}" data-view="${c.id}" data-type="${type}">
          <span>${c.name}</span>
          <span class="sidebar-item-count">${c.productCount || 0}</span>
        </div>`).join('');
    }

    list.querySelectorAll('.sidebar-item').forEach(item => {
      const el = item as HTMLElement;
      el.addEventListener('click', () => ctx.selectView(el.dataset.view!, type));
    });
  });

  const allItem = document.querySelector('[data-view="all"]');
  if (allItem) allItem.className = 'sidebar-item' + (ctx.currentView === 'all' ? ' active' : '');

  const collapsedState = JSON.parse(localStorage.getItem('tr_collapsed_sections') || '[]');
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    const el = btn as HTMLElement;
    const targetId = el.dataset.target;
    if (!targetId) return;
    if (collapsedState.includes(targetId)) {
      el.classList.add('collapsed');
      document.getElementById(targetId)?.classList.add('collapsed');
    }
    el.onclick = (e) => {
      if ((e.target as HTMLElement).closest('.sidebar-item')) return;
      const isCollapsed = el.classList.toggle('collapsed');
      document.getElementById(targetId)?.classList.toggle('collapsed');
      const currentSaved = JSON.parse(localStorage.getItem('tr_collapsed_sections') || '[]');
      if (isCollapsed) currentSaved.push(targetId);
      else { const i = currentSaved.indexOf(targetId); if (i > -1) currentSaved.splice(i, 1); }
      localStorage.setItem('tr_collapsed_sections', JSON.stringify(Array.from(new Set(currentSaved))));
    };
  });
}

export function renderGrid(ctx: DashboardContext): void {
  const products = getFilteredProducts(ctx);
  const topbarTitle = document.getElementById('topbar-title')!;
  const topbarMeta = document.getElementById('topbar-meta')!;

  if (ctx.currentView === 'all') {
    topbarTitle.textContent = 'All Products';
    ctx.refs.editEventStatus.style.display = 'none';
  } else {
    const cat = ctx.allCategories.find(c => c.id === ctx.currentView);
    topbarTitle.textContent = cat ? cat.name : 'Products';
    if (cat?.type === 'event' || cat?.type === 'trend') {
      ctx.refs.editEventStatus.style.display = 'block';
      ctx.refs.editEventStatus.value = cat.eventStatus || 'upcoming';
    } else {
      ctx.refs.editEventStatus.style.display = 'none';
    }
  }
  topbarMeta.textContent = `${products.length} product${products.length !== 1 ? 's' : ''}`;

  const gridWrap = document.getElementById('grid-wrap')!;
  let grid = document.getElementById('product-grid');
  let loader = document.getElementById('grid-loader');

  if (!grid) {
    gridWrap.innerHTML = '<div id="product-grid"></div><div id="grid-loader" style="text-align:center; padding:20px; color:#888; display:none; font-size: 12px;">Loading more...</div>';
    grid = document.getElementById('product-grid');
    loader = document.getElementById('grid-loader');
  }

  if (products.length === 0) {
    grid!.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <div class="empty-state-title">${ctx.searchQuery ? 'No results found' : 'No products here yet'}</div>
        <div class="empty-state-sub">${ctx.searchQuery ? 'Try a different search term.' : 'Browse Amazon, eBay or Etsy and click the + button on any product to save it here.'}</div>
      </div>`;
    if (loader) loader.style.display = 'none';
    return;
  }

  grid!.innerHTML = products.map(p => buildCardHtml(p, ctx.selectedIds)).join('');

  grid!.querySelectorAll('.product-card').forEach(card => {
    const el = card as HTMLElement;
    el.addEventListener('click', e => {
      const target = e.target as HTMLElement;
      if (target.closest('.product-card-delete')) return;
      if (target.closest('.product-card-promo-btn')) return;
      if (target.closest('.product-card-seo-btn')) return;
      if (target.closest('.listings-toggle-btn')) return;
      if (target.closest('#listings-float-panel')) return;
      if (ctx.selectMode) {
        const id = el.dataset.id!;
        if (ctx.selectedIds.has(id)) { ctx.selectedIds.delete(id); el.classList.remove('selected'); }
        else { ctx.selectedIds.add(id); el.classList.add('selected'); }
        ctx.updateSelectCount();
        return;
      }
      const prod = ctx.allProducts.find(p => p.id === el.dataset.id);
      if (prod?.productUrl) window.open(prod.productUrl, '_blank');
    });
  });

  grid!.querySelectorAll('.product-card-delete').forEach(btn => {
    const el = btn as HTMLElement;
    el.addEventListener('click', async e => {
      e.stopPropagation();
      if (!confirm('Remove this product?')) return;
      await TrendResearcherDB.deleteProduct(el.dataset.id!);
      ctx.refresh();
    });
  });

  // ─── Listings toggle — module-level guard prevents duplicate listeners ─────
  function closeListingsPanel() {
    const existing = document.getElementById('listings-float-panel');
    if (existing) {
      const prevBtn = grid!.querySelector(`.listings-toggle-btn[data-id="${existing.dataset.cardId}"]`) as HTMLElement | null;
      prevBtn?.classList.remove('active');
      existing.remove();
    }
  }

  if (!grid!.dataset.hasListingsListener) {
    grid!.dataset.hasListingsListener = 'true';

    grid!.addEventListener('click', (e) => {
      const btn = (e.target as HTMLElement).closest('.listings-toggle-btn') as HTMLElement | null;
      if (!btn) return;
      e.stopPropagation();

      const card = btn.closest('.product-card') as HTMLElement;
      const existing = document.getElementById('listings-float-panel');

      if (existing?.dataset.cardId === card.dataset.id) {
        closeListingsPanel();
        return;
      }

      closeListingsPanel();

      const listings: any[] = JSON.parse(btn.dataset.listings || '[]');
      const CHANNEL_COLORS: Record<string, string> = { amazon: '#ff9900', ebay: '#0064d2', etsy: '#f45800' };

      const panel = document.createElement('div');
      panel.id = 'listings-float-panel';
      panel.className = 'listings-float-panel';
      panel.dataset.cardId = card.dataset.id!;

      const header = document.createElement('div');
      header.className = 'listings-float-panel-header';
      header.textContent = `🔗 My Listings (${listings.length})`;
      panel.appendChild(header);

      for (const l of listings) {
        const color = CHANNEL_COLORS[l.channel?.toLowerCase()] || '#607d8b';
        const a = document.createElement('a');
        a.className = 'listing-link-badge';
        a.href = l.listingLink;
        a.target = '_blank';
        a.rel = 'noopener noreferrer';

        const tag = document.createElement('span');
        tag.className = 'listing-channel-tag';
        tag.style.background = color;
        tag.textContent = l.channel || '';

        const label = document.createElement('span');
        label.className = 'listing-link-label';
        label.textContent = l.title || l.channel || '';

        a.appendChild(tag);
        a.appendChild(label);
        panel.appendChild(a);
      }

      const gridWrap = document.getElementById('grid-wrap')!;
      const wrapRect = gridWrap.getBoundingClientRect();
      const cardRect = card.getBoundingClientRect();
      panel.style.top  = (cardRect.top  - wrapRect.top  + gridWrap.scrollTop)  + 'px';
      panel.style.left = (cardRect.right - wrapRect.left + 10) + 'px';

      gridWrap.appendChild(panel);
      btn.classList.add('active');
    });
  }

  // Document-level close listener — added only once ever
  if (!(window as any).__trListingsDocListener) {
    (window as any).__trListingsDocListener = true;
    document.addEventListener('click', (e) => {
      if (!document.getElementById('listings-float-panel')) return;
      if (!(e.target as HTMLElement).closest('#listings-float-panel') &&
          !(e.target as HTMLElement).closest('.listings-toggle-btn')) {
        document.getElementById('listings-float-panel')?.remove();
      }
    }, { capture: true });
  }

  // Apply stage badges and listings badges async (non-blocking)
  applyStagesBadges(products);
  applyListingsBadges(products);

  // Setup Infinite Scroll
  if (loader) {
    if (ctx.hasMoreProducts) {
      loader.style.display = 'block';
      if (!gridWrap.dataset.hasObserver) {
        const io = new IntersectionObserver((entries) => {
          if (entries[0].isIntersecting && ctx.hasMoreProducts && !ctx.fetchingNow) {
            ctx.fetchingNow = true;
            ctx.refresh(true).finally(() => ctx.fetchingNow = false);
          }
        }, { root: gridWrap, threshold: 0.1 });
        io.observe(loader);
        gridWrap.dataset.hasObserver = 'true';
      }
    } else {
      loader.style.display = 'none';
    }
  }
}
