export interface PromotionDef {
  id: string;
  label: string;
  icon: string;
  color: string;
}

export const PROMOTIONS: PromotionDef[] = [
  { id: 'promoted_ads',  label: 'Promoted Ads',          icon: '📢', color: '#9c27b0' },
  { id: 'discount',      label: '% Discount / Sale',     icon: '🏷️', color: '#f44336' },
  { id: 'coupon',        label: 'Coupon',                 icon: '✂️', color: '#ff9800' },
  { id: 'multibuy',      label: 'Multi-buy / Bundle',    icon: '📦', color: '#2196f3' },
];

export const PROMO_MAP = new Map(PROMOTIONS.map(p => [p.id, p]));

export function buildPromoBadgesHtml(promotions: string[] | undefined): string {
  if (!promotions || promotions.length === 0) return '';
  return promotions.map(id => {
    const def = PROMO_MAP.get(id);
    if (!def) return '';
    return `<span class="promo-badge" style="background:${def.color}" title="${def.label}">${def.icon} ${def.label}</span>`;
  }).join('');
}
