import type { DashboardContext } from '../types';

export function initSelectHandler(ctx: DashboardContext): void {
  const R = ctx.refs;

  ctx.updateSelectCount = function() {
    const n = ctx.selectedIds.size;
    R.fetchBsrBtn.disabled = n === 0 || ctx.fetchingNow;
    if (n > 0) {
      R.selectCount.textContent = `${n} selected`;
      R.selectCount.style.display = '';
    } else {
      R.selectCount.style.display = 'none';
    }
  };

  R.selectBtn.addEventListener('click', () => {
    ctx.selectMode = !ctx.selectMode;
    ctx.selectedIds.clear();
    R.selectBtn.classList.toggle('active', ctx.selectMode);
    R.selectBtn.textContent = ctx.selectMode ? '✕ Cancel' : '☑ Select';
    R.fetchBsrBtn.disabled = true;
    R.selectCount.style.display = 'none';
    document.body.classList.toggle('select-mode', ctx.selectMode);
    document.querySelectorAll('.product-card.selected').forEach(c => c.classList.remove('selected'));
  });
}
