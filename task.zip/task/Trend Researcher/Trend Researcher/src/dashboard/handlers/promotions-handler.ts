import TrendResearcherDB from '../../db';
import { PROMOTIONS, buildPromoBadgesHtml } from '../promotions';
import { renderGrid } from '../grid';
import type { DashboardContext } from '../types';

export function renderPromotionsSidebar(ctx: DashboardContext): void {
  const list = document.getElementById('promo-sidebar-list')!;

  const counts = new Map<string, number>();
  for (const p of ctx.allProducts) {
    for (const promoId of (p.promotions || [])) {
      counts.set(promoId, (counts.get(promoId) || 0) + 1);
    }
  }

  list.innerHTML = PROMOTIONS.map(p => {
    const state = ctx.promotionFilters.get(p.id) || null;
    return `
      <div class="promo-filter-row" data-promo="${p.id}">
        <span class="promo-filter-label">${p.icon} ${p.label}</span>
        <div class="promo-filter-toggles">
          <button class="promo-toggle yes ${state === 'yes' ? 'active' : ''}" data-promo="${p.id}" data-val="yes" title="Has this promotion">Y</button>
          <button class="promo-toggle no ${state === 'no' ? 'active' : ''}" data-promo="${p.id}" data-val="no" title="Does not have this promotion">N</button>
          <button class="promo-toggle clear ${!state ? 'active' : ''}" data-promo="${p.id}" data-val="clear" title="No filter">✕</button>
        </div>
        <span class="sidebar-item-count">${counts.get(p.id) || 0}</span>
      </div>
    `;
  }).join('');

  list.querySelectorAll('.promo-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const el = btn as HTMLButtonElement;
      const promoId = el.dataset.promo!;
      const val = el.dataset.val!;
      if (val === 'clear') {
        ctx.promotionFilters.delete(promoId);
      } else {
        ctx.promotionFilters.set(promoId, val as 'yes' | 'no');
      }
      list.querySelectorAll<HTMLButtonElement>(`.promo-toggle[data-promo="${promoId}"]`).forEach(b => {
        const bVal = b.dataset.val!;
        const newState = ctx.promotionFilters.get(promoId) || null;
        b.classList.toggle('active',
          (bVal === 'yes' && newState === 'yes') ||
          (bVal === 'no'  && newState === 'no')  ||
          (bVal === 'clear' && !newState)
        );
      });
      ctx.productsOffset = 0;
      renderGrid(ctx);
    });
  });
}

export function initPromotionsHandler(ctx: DashboardContext): void {
  const promoModal = document.getElementById('promo-modal')!;
  const promoChecklist = document.getElementById('promo-checklist')!;
  let promoTargetId: string | null = null;

  promoChecklist.innerHTML = PROMOTIONS.map(p => `
    <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13px; color:#0f1111;">
      <input type="checkbox" value="${p.id}" style="width:16px;height:16px;cursor:pointer;">
      <span class="promo-badge" style="background:${p.color}">${p.icon} ${p.label}</span>
    </label>
  `).join('');

  function openPromoModal(productId: string) {
    const prod = ctx.allProducts.find(p => p.id === productId);
    if (!prod) return;
    promoTargetId = productId;
    const active = new Set(prod.promotions || []);
    promoChecklist.querySelectorAll<HTMLInputElement>('input[type=checkbox]').forEach(cb => {
      cb.checked = active.has(cb.value);
    });
    promoModal.classList.add('open');
  }

  document.getElementById('promo-cancel')!.addEventListener('click', () => promoModal.classList.remove('open'));
  promoModal.addEventListener('click', (e: Event) => { if (e.target === promoModal) promoModal.classList.remove('open'); });

  document.getElementById('promo-save')!.addEventListener('click', async () => {
    if (!promoTargetId) return;
    const selected: string[] = [];
    promoChecklist.querySelectorAll<HTMLInputElement>('input[type=checkbox]:checked').forEach(cb => selected.push(cb.value));
    await TrendResearcherDB.updateProduct(promoTargetId, { promotions: selected });
    promoModal.classList.remove('open');
    const card = document.querySelector(`.product-card[data-id="${promoTargetId}"]`);
    if (card) {
      const row = card.querySelector('.promo-badges-row');
      if (row) row.innerHTML = buildPromoBadgesHtml(selected);
    }
    const prod = ctx.allProducts.find(p => p.id === promoTargetId);
    if (prod) prod.promotions = selected;
    promoTargetId = null;
  });

  document.getElementById('grid-wrap')!.addEventListener('click', (e: Event) => {
    const btn = (e.target as HTMLElement).closest('.product-card-promo-btn') as HTMLElement | null;
    if (btn) { e.stopPropagation(); openPromoModal(btn.dataset.id!); }
  });
}
