import { loadAllStageIds } from '../stages';
import type { DashboardContext } from '../types';

function debounce<T extends (...args: any[]) => void>(fn: T, ms: number): T {
  let timer: number;
  return ((...args: any[]) => {
    clearTimeout(timer);
    timer = window.setTimeout(() => fn(...args), ms);
  }) as T;
}

export function initFilterHandlers(ctx: DashboardContext): void {
  const sortBySelect = document.getElementById('sort-by') as HTMLSelectElement;

  // Debounced search — prevents a DB round-trip on every keystroke
  ctx.refs.searchInput.addEventListener('input', debounce((e: Event) => {
    ctx.searchQuery = (e.target as HTMLInputElement).value.trim();
    ctx.productsOffset = 0;
    ctx.refresh();
  }, 300));

  sortBySelect.addEventListener('change', (e: Event) => {
    ctx.sortBy = (e.target as HTMLSelectElement).value;
    ctx.productsOffset = 0;
    ctx.refresh();
  });

  document.querySelectorAll('.platform-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const el = btn as HTMLButtonElement;
      const platform = el.dataset.platform!;
      const toggling = ctx.platformFilter === platform;
      ctx.platformFilter = toggling ? null : platform;
      document.querySelectorAll('.platform-filter-btn').forEach(b =>
        b.classList.toggle('active', !toggling && (b as HTMLButtonElement).dataset.platform === platform));
      ctx.productsOffset = 0;
      ctx.refresh();
    });
  });

  document.querySelectorAll('.stage-filter-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const el = btn as HTMLButtonElement;
      const val = el.id === 'filter-in-csv' ? 'in-csv' : 'not-in-csv' as const;
      const toggling = ctx.stageFilter === val;
      ctx.stageFilter = toggling ? null : val;
      if (!toggling) ctx.stageIds = await loadAllStageIds();
      document.querySelectorAll('.stage-filter-btn').forEach(b =>
        b.classList.toggle('active', !toggling && b.id === el.id));
      ctx.productsOffset = 0;
      ctx.refresh();
    });
  });
}
