import TrendResearcherDB from '../../db';
import { renderGrid } from '../grid';
import type { DashboardContext } from '../types';

const PLATFORMS = [
  { id: 'amazon', label: 'Amazon', color: '#ff9900' },
  { id: 'ebay',   label: 'eBay',   color: '#0064d2' },
  { id: 'etsy',   label: 'Etsy',   color: '#f45800' },
] as const;

const DESIGN_ID_FIELDS = [
  'designId', 'colourfulDesignId', 'blackDesignId', 'whiteDesignId',
  'designMen', 'designWomen', 'designBoy', 'designGirl',
  'designBabyBoy', 'designBabyGirl',
] as const;

function normalizeChannel(ch: string): string | null {
  const lower = (ch || '').toLowerCase();
  if (lower.includes('amazon')) return 'amazon';
  if (lower.includes('ebay'))   return 'ebay';
  if (lower.includes('etsy'))   return 'etsy';
  return null;
}

// Builds a map: stageId (e.g. "amz_B001234567") → Set<channel>
// Uses two parallel DB calls then joins in memory — no N+1.
export async function buildListingsChannelsMap(): Promise<Map<string, Set<string>>> {
  const [stages, listings] = await Promise.all([
    TrendResearcherDB.getAllStages()   as Promise<any[]>,
    TrendResearcherDB.getAllListings() as Promise<any[]>,
  ]);

  if (!stages?.length || !listings?.length) return new Map();

  // Group: designId → Set<channel>
  const byDesignId = new Map<string, Set<string>>();
  for (const l of listings) {
    if (!l.designId) continue;
    const ch = normalizeChannel(l.channel);
    if (!ch) continue;
    const set = byDesignId.get(l.designId) ?? new Set<string>();
    set.add(ch);
    byDesignId.set(l.designId, set);
  }

  // Map stageId → channels via all design ID fields
  const result = new Map<string, Set<string>>();
  for (const stage of stages) {
    const channels = new Set<string>();
    for (const field of DESIGN_ID_FIELDS) {
      const did = ((stage as any)[field] || '').trim();
      if (!did) continue;
      byDesignId.get(did)?.forEach(c => channels.add(c));
    }
    if (channels.size) result.set(stage.id as string, channels);
  }

  return result;
}

export function renderListingsFilterSidebar(ctx: DashboardContext): void {
  const list = document.getElementById('listings-filter-list');
  if (!list) return;

  // Count loaded products per channel
  const counts: Record<string, number> = { amazon: 0, ebay: 0, etsy: 0 };
  if (ctx.listingsChannelsMap) {
    for (const p of ctx.allProducts) {
      if (!p.platformId) continue;
      const key = (p.platform === 'amazon' ? 'amz' : p.platform) + '_' + p.platformId;
      const channels = ctx.listingsChannelsMap.get(key);
      if (!channels) continue;
      for (const ch of channels) if (ch in counts) counts[ch]++;
    }
  }

  list.innerHTML = PLATFORMS.map(p => {
    const state = ctx.listingsFilter.get(p.id) ?? null;
    return `
      <div class="promo-filter-row">
        <span class="promo-filter-label" style="color:${p.color};font-weight:bold;">● ${p.label}</span>
        <div class="promo-filter-toggles">
          <button class="promo-toggle yes   ${state === 'yes' ? 'active' : ''}" data-platform="${p.id}" data-val="yes"   title="Has ${p.label} listing">Y</button>
          <button class="promo-toggle no    ${state === 'no'  ? 'active' : ''}" data-platform="${p.id}" data-val="no"    title="No ${p.label} listing">N</button>
          <button class="promo-toggle clear ${!state          ? 'active' : ''}" data-platform="${p.id}" data-val="clear" title="No filter">✕</button>
        </div>
        <span class="sidebar-item-count">${counts[p.id]}</span>
      </div>
    `;
  }).join('');

  list.querySelectorAll<HTMLButtonElement>('.promo-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const platform = btn.dataset.platform!;
      const val      = btn.dataset.val!;

      if (val === 'clear') {
        ctx.listingsFilter.delete(platform);
      } else {
        ctx.listingsFilter.set(platform, val as 'yes' | 'no');
      }

      // Update toggle active states without full sidebar re-render
      list.querySelectorAll<HTMLButtonElement>(`.promo-toggle[data-platform="${platform}"]`).forEach(b => {
        const bVal     = b.dataset.val!;
        const newState = ctx.listingsFilter.get(platform) ?? null;
        b.classList.toggle('active',
          (bVal === 'yes'   && newState === 'yes') ||
          (bVal === 'no'    && newState === 'no')  ||
          (bVal === 'clear' && !newState)
        );
      });

      ctx.productsOffset = 0;
      renderGrid(ctx);
    });
  });
}
