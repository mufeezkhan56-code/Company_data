import TrendResearcherDB from '../../db';
import { SEO_CHECKLIST, buildSeoBadgesHtml } from '../seo';
import { renderGrid } from '../grid';
import type { DashboardContext } from '../types';

export function renderSEOSidebar(ctx: DashboardContext): void {
  const list = document.getElementById('seo-sidebar-list');
  if (!list) return;

  const counts = new Map<string, number>();
  for (const p of ctx.allProducts) {
    const seo = (p as any).seoChecklist || {};
    for (const item of SEO_CHECKLIST) {
      if (seo[item.id] === true) counts.set(item.id, (counts.get(item.id) || 0) + 1);
    }
  }

  list.innerHTML = SEO_CHECKLIST.map(item => {
    const state = ctx.seoFilters.get(item.id) ?? null;
    return `
      <div class="promo-filter-row" data-seo="${item.id}">
        <span class="promo-filter-label">${item.icon} ${item.label}</span>
        <div class="promo-filter-toggles">
          <button class="promo-toggle yes   ${state === 'yes' ? 'active' : ''}" data-seo="${item.id}" data-val="yes"   title="Has ${item.label}">Y</button>
          <button class="promo-toggle no    ${state === 'no'  ? 'active' : ''}" data-seo="${item.id}" data-val="no"    title="Missing ${item.label}">N</button>
          <button class="promo-toggle clear ${!state          ? 'active' : ''}" data-seo="${item.id}" data-val="clear" title="No filter">✕</button>
        </div>
        <span class="sidebar-item-count">${counts.get(item.id) || 0}</span>
      </div>
    `;
  }).join('');

  list.querySelectorAll<HTMLButtonElement>('.promo-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const seoId = btn.dataset.seo!;
      const val   = btn.dataset.val!;

      if (val === 'clear') {
        ctx.seoFilters.delete(seoId);
      } else {
        ctx.seoFilters.set(seoId, val as 'yes' | 'no');
      }

      list.querySelectorAll<HTMLButtonElement>(`.promo-toggle[data-seo="${seoId}"]`).forEach(b => {
        const bVal     = b.dataset.val!;
        const newState = ctx.seoFilters.get(seoId) ?? null;
        b.classList.toggle('active',
          (bVal === 'yes'   && newState === 'yes') ||
          (bVal === 'no'    && newState === 'no')  ||
          (bVal === 'clear' && !newState)
        );
      });

      ctx.productsOffset = 0;
      renderGrid(ctx);
    });
  });
}

export function initSEOHandler(ctx: DashboardContext): void {
  const modal        = document.getElementById('seo-modal')!;
  const checklist    = document.getElementById('seo-checklist')!;
  let targetId: string | null = null;

  // Build checklist once
  checklist.innerHTML = SEO_CHECKLIST.map(item => `
    <label style="display:flex; align-items:center; gap:10px; cursor:pointer; font-size:13px; color:#0f1111;">
      <input type="checkbox" value="${item.id}" style="width:16px;height:16px;cursor:pointer;">
      <span class="seo-badge" style="background:${item.color}">${item.icon}</span>
      <span>${item.label}</span>
    </label>
  `).join('');

  function openModal(productId: string) {
    const prod = ctx.allProducts.find(p => p.id === productId);
    if (!prod) return;
    targetId = productId;
    const active = (prod as any).seoChecklist || {};
    checklist.querySelectorAll<HTMLInputElement>('input[type=checkbox]').forEach(cb => {
      cb.checked = active[cb.value] === true;
    });
    modal.classList.add('open');
  }

  document.getElementById('seo-cancel')!.addEventListener('click', () => modal.classList.remove('open'));
  modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('open'); });

  document.getElementById('seo-save')!.addEventListener('click', async () => {
    if (!targetId) return;
    const seoChecklist: Record<string, boolean> = {};
    checklist.querySelectorAll<HTMLInputElement>('input[type=checkbox]').forEach(cb => {
      seoChecklist[cb.value] = cb.checked;
    });
    await TrendResearcherDB.updateProduct(targetId, { seoChecklist } as any);
    modal.classList.remove('open');

    // Update card badges inline without full refresh
    const card = document.querySelector(`.product-card[data-id="${targetId}"]`);
    if (card) {
      const row = card.querySelector('.seo-badges-row');
      if (row) row.innerHTML = buildSeoBadgesHtml(seoChecklist);
    }
    const prod = ctx.allProducts.find(p => p.id === targetId);
    if (prod) (prod as any).seoChecklist = seoChecklist;

    targetId = null;
  });

  // Delegate SEO button clicks from grid-wrap
  document.getElementById('grid-wrap')!.addEventListener('click', (e: Event) => {
    const btn = (e.target as HTMLElement).closest('.product-card-seo-btn') as HTMLElement | null;
    if (btn) { e.stopPropagation(); openModal(btn.dataset.id!); }
  });
}
