import TrendResearcherDB from '../../db';
import type { DashboardContext } from '../types';

export function initCategoryHandlers(ctx: DashboardContext): void {
  const R = ctx.refs;

  function openCatModal(type: string) {
    ctx.pendingCatType = type;
    R.catModalTitle.textContent = `Add ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    R.catName.value = '';
    R.catDesc.value = '';
    if (type === 'event' || type === 'trend') {
      R.catStatusGroup.style.display = 'block';
    } else {
      R.catStatusGroup.style.display = 'none';
    }
    R.catModal.classList.add('open');
    R.catName.focus();
  }

  function closeCatModal() {
    R.catModal.classList.remove('open');
    ctx.pendingCatType = null;
  }

  document.getElementById('add-event-btn')!.addEventListener('click', () => openCatModal('event'));
  document.getElementById('add-trend-btn')!.addEventListener('click', () => openCatModal('trend'));
  document.getElementById('add-asset-btn')!.addEventListener('click', () => openCatModal('asset'));

  document.getElementById('cat-cancel')!.addEventListener('click', closeCatModal);
  R.catModal.addEventListener('click', (e: Event) => { if (e.target === R.catModal) closeCatModal(); });

  document.getElementById('cat-save')!.addEventListener('click', async () => {
    const name = R.catName.value.trim();
    if (!name || !ctx.pendingCatType) return;
    const eventStatus = (ctx.pendingCatType === 'event' || ctx.pendingCatType === 'trend')
      ? (R.catEventStatus.value as 'upcoming' | 'current' | 'past')
      : undefined;
    await TrendResearcherDB.createCategory({
      type: ctx.pendingCatType,
      name,
      description: R.catDesc.value.trim(),
      eventStatus,
    });
    closeCatModal();
    await ctx.refresh();
  });

  document.querySelector('[data-view="all"]')!.addEventListener('click', () => ctx.selectView('all'));

  R.editEventStatus.addEventListener('change', async (e: Event) => {
    if ((ctx.currentType === 'event' || ctx.currentType === 'trend') && ctx.currentView !== 'all') {
      const newStatus = (e.target as HTMLSelectElement).value as 'upcoming' | 'current' | 'past';
      await TrendResearcherDB.updateCategory(ctx.currentView, { eventStatus: newStatus });
      await ctx.refresh();
    }
  });
}
