import TrendResearcherDB from '../../db';
import { importStagesFromFile } from '../stages';
import { importListingsFromFile } from '../listings';
import type { DashboardContext } from '../types';

export async function renderStagesSidebar(ctx: DashboardContext): Promise<void> {
  const list = document.getElementById('stage-list')!;
  const [stages, productIds] = await Promise.all([
    TrendResearcherDB.getAllStages() as Promise<Array<{ id: string; stage: string }>>,
    TrendResearcherDB.getAllProductPlatformIds() as Promise<string[]>,
  ]);
  ctx.stageDataMap = new Map(stages.map(s => [s.id, s.stage]));

  const savedSet = new Set(productIds);
  const counts = new Map<string, number>();
  for (const s of stages) {
    if (!s.stage || !savedSet.has(s.id)) continue;
    counts.set(s.stage, (counts.get(s.stage) || 0) + 1);
  }

  if (counts.size === 0) {
    list.innerHTML = '<div style="font-size:11px;color:#565674;padding:8px 12px;">No stages imported</div>';
    return;
  }

  const sorted = Array.from(counts.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  list.innerHTML = sorted.map(([name, count]) => `
    <div class="sidebar-item ${ctx.stageNameFilter === name ? 'active' : ''}" data-stage="${name}">
      <span>${name}</span>
      <span class="sidebar-item-count">${count}</span>
    </div>
  `).join('');

  list.querySelectorAll('.sidebar-item').forEach(item => {
    const el = item as HTMLElement;
    el.addEventListener('click', () => {
      const stage = el.dataset.stage!;
      ctx.stageNameFilter = ctx.stageNameFilter === stage ? null : stage;
      ctx.productsOffset = 0;
      ctx.refresh();
    });
  });
}

export function initImportExportHandlers(ctx: DashboardContext): void {
  document.getElementById('export-btn')!.addEventListener('click', async () => {
    const data = await TrendResearcherDB.exportAll();
    const a = Object.assign(document.createElement('a'), {
      href: URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })),
      download: `trend-researcher-${new Date().toISOString().slice(0, 10)}.json`,
    });
    a.click(); URL.revokeObjectURL(a.href);
  });

  const jsonFileInput = document.getElementById('json-file-input') as HTMLInputElement;
  document.getElementById('import-json-btn')!.addEventListener('click', () => jsonFileInput.click());
  jsonFileInput.addEventListener('change', async () => {
    const file = jsonFileInput.files?.[0];
    if (!file || !confirm('Import and merge? New items will be added, existing ones kept.')) {
      jsonFileInput.value = ''; return;
    }
    await TrendResearcherDB.importAll(JSON.parse(await file.text()));
    jsonFileInput.value = '';
    ctx.currentView = 'all';
    await ctx.refresh();
  });

  const stagesFileInput = document.getElementById('stages-file-input') as HTMLInputElement;
  const stagesStatus = document.getElementById('stages-status')!;

  document.getElementById('import-stages-btn')!.addEventListener('click', () => stagesFileInput.click());
  stagesFileInput.addEventListener('change', async () => {
    const file = stagesFileInput.files?.[0];
    if (!file) return;
    stagesStatus.style.display = '';
    await importStagesFromFile(file, (_pct, msg) => { stagesStatus.textContent = msg; });
    stagesFileInput.value = '';
    ctx.stageNameFilter = null;
    await ctx.refresh();
  });

  const listingsFileInput = document.getElementById('listings-file-input') as HTMLInputElement;
  const listingsStatus = document.getElementById('listings-status')!;

  document.getElementById('import-listings-btn')!.addEventListener('click', () => listingsFileInput.click());
  listingsFileInput.addEventListener('change', async () => {
    const file = listingsFileInput.files?.[0];
    if (!file) return;
    listingsStatus.style.display = '';
    await importListingsFromFile(file, msg => { listingsStatus.textContent = msg; });
    listingsFileInput.value = '';
    await ctx.refresh();
  });

  document.getElementById('clear-btn')!.addEventListener('click', async () => {
    if (!confirm('Clear all products and categories? This cannot be undone.')) return;
    await TrendResearcherDB.clearAll();
    ctx.currentView = 'all';
    await ctx.refresh();
  });
}
