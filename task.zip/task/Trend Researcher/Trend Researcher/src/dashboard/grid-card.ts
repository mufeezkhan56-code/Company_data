import type { Product } from '../db/products';
import { buildPromoBadgesHtml } from './promotions';
import { buildSeoBadgesHtml } from './seo';

export function escHtml(str: any): string {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export function buildBsrHtml(p: Product): string {
  if (!p.bsr || p.bsr === 'N/A') return '';
  if (p.platform === 'ebay') return `<span class="bsr-val">🔥 ${escHtml(p.bsr)}</span>`;
  if (p.platform === 'etsy') return `<span class="bsr-val">🛒 ${escHtml(p.bsr)}</span>`;
  let html = `<span class="bsr-val">BSR: ${escHtml(p.bsr)}</span>`;
  if (p.rating      && p.rating      !== 'N/A') html += `<span>⭐ ${escHtml(p.rating)}</span>`;
  if (p.reviewCount && p.reviewCount !== 'N/A') html += `<span>💬 ${escHtml(p.reviewCount)}</span>`;
  if (p.dispatches  && p.dispatches  !== 'N/A') html += `<span>📦 ${escHtml(p.dispatches)}</span>`;
  return html;
}

export function buildCardHtml(p: Product, selectedIds: Set<string>): string {
  const title     = escHtml(p.title || 'Untitled');
  const imageUrl  = escHtml(p.imageUrl || '');
  const platform  = escHtml(p.platform || '');
  const price     = p.price ? escHtml(p.price) : '';
  const id        = escHtml(p.id);
  const isSelected = selectedIds.has(p.id);

  return `
<div class="product-card${isSelected ? ' selected' : ''}"
     data-id="${id}"
     role="article"
     aria-label="${title}">

  <div class="product-card-checkbox" aria-hidden="true">✓</div>

  <img class="product-card-img"
       src="${imageUrl}"
       alt="${title}"
       loading="lazy"
       onerror="this.style.display='none'">

  <button class="product-card-delete"
          data-id="${id}"
          aria-label="Remove ${title}"
          title="Remove product">✕</button>

  <button class="product-card-promo-btn"
          data-id="${id}"
          aria-label="Set promotions for ${title}"
          title="Set promotions">🏷️</button>

  <button class="product-card-seo-btn"
          data-id="${id}"
          aria-label="SEO checklist for ${title}"
          title="SEO Checklist">✅</button>

  <div class="product-card-body">
    <div class="product-card-title">${title}</div>

    <div class="product-card-meta">
      <span class="product-card-platform platform-${platform}">${platform}</span>
      ${price ? `<span class="product-card-price">${price}</span>` : ''}
    </div>

    ${p.bsr && p.bsr !== 'N/A'
      ? `<div class="product-card-bsr">${buildBsrHtml(p)}</div>`
      : ''}

    <div class="pst-badge-slot"></div>

    ${p.promotions && p.promotions.length > 0
      ? `<div class="promo-badges-row">${buildPromoBadgesHtml(p.promotions)}</div>`
      : '<div class="promo-badges-row"></div>'}

    <div class="seo-badges-row">${buildSeoBadgesHtml(p.seoChecklist)}</div>

    <button class="listings-toggle-btn"
            data-id="${id}"
            aria-label="View my listings for ${title}"
            title="My Listings"
            hidden>🔗 My Listings</button>
  </div>
</div>
`;
}