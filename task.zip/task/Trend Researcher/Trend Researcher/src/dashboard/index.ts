import TrendResearcherDB from '../db';
import { renderSidebar, renderGrid } from './grid';
import { initBSR } from './bsr';
import type { DashboardContext } from './types';
import { initCategoryHandlers } from './handlers/categories';
import { initFilterHandlers } from './handlers/filters';
import { initImportExportHandlers, renderStagesSidebar } from './handlers/import-export';
import { initPromotionsHandler, renderPromotionsSidebar } from './handlers/promotions-handler';
import { buildListingsChannelsMap, renderListingsFilterSidebar } from './handlers/listings-filter-handler';
import { initSEOHandler, renderSEOSidebar } from './handlers/seo-handler';
import { initSelectHandler } from './handlers/select';

(async () => {
  const ctx: DashboardContext = {
    currentView: 'all',
    currentType: null,
    allProducts: [],
    allCategories: [],
    searchQuery: '',
    selectMode: false,
    selectedIds: new Set<string>(),
    fetchingNow: false,
    pendingCatType: null,
    productsOffset: 0,
    hasMoreProducts: true,
    sortBy: 'date',
    platformFilter: null,
    stageFilter: null,
    stageIds: null,
    stageNameFilter: null,
    stageDataMap: null,
    promotionFilters: new Map(),
    listingsFilter: new Map(),
    listingsChannelsMap: null,
    seoFilters: new Map(),
    refs: {} as any,
    refresh: async (_append?: boolean) => {},
    selectView: () => {},
    updateSelectCount: () => {},
  };

  const R = ctx.refs;
  R.searchInput       = document.getElementById('search-input') as HTMLInputElement;
  R.catModal          = document.getElementById('cat-modal')!;
  R.catModalTitle     = document.getElementById('cat-modal-title')!;
  R.catName           = document.getElementById('cat-name') as HTMLInputElement;
  R.catDesc           = document.getElementById('cat-desc') as HTMLInputElement;
  R.selectBtn         = document.getElementById('select-btn') as HTMLButtonElement;
  R.fetchBsrBtn       = document.getElementById('fetch-bsr-btn') as HTMLButtonElement;
  R.selectCount       = document.getElementById('select-count')!;
  R.fetchBar          = document.getElementById('fetch-bar')!;
  R.fetchBarFill      = document.getElementById('fetch-bar-fill')!;
  R.fetchBarText      = document.getElementById('fetch-bar-text')!;
  R.catStatusGroup    = document.getElementById('cat-status-group')!;
  R.catEventStatus    = document.getElementById('cat-event-status') as HTMLSelectElement;
  R.editEventStatus   = document.getElementById('edit-event-status') as HTMLSelectElement;

  async function loadData(append = false) {
    if (!append) { ctx.productsOffset = 0; ctx.hasMoreProducts = true; }
    ctx.allCategories = await TrendResearcherDB.getCategories();
    if (!append) ctx.listingsChannelsMap = await buildListingsChannelsMap();
    const limit = 50;
    const newProducts = await TrendResearcherDB.getPagedProducts({
      categoryId: ctx.currentView !== 'all' ? ctx.currentView : undefined,
      query: ctx.searchQuery,
      sortBy: ctx.sortBy,
      platform: ctx.platformFilter || undefined,
      limit,
      offset: ctx.productsOffset,
    });
    if (newProducts.length < limit) ctx.hasMoreProducts = false;
    ctx.allProducts = append ? [...ctx.allProducts, ...newProducts] : newProducts;
    ctx.productsOffset += newProducts.length;
    const count = await TrendResearcherDB.getProductCount();
    const countEl = document.getElementById('count-all');
    if (countEl) countEl.textContent = String(count);
  }

  ctx.selectView = function(view: string, type: string | null = null) {
    ctx.currentView = view;
    ctx.currentType = type;
    ctx.productsOffset = 0;
    ctx.refresh();
  };

  ctx.refresh = async function(append = false) {
    await loadData(append);
    if (!append) {
      renderSidebar(ctx);
      await renderStagesSidebar(ctx);
      renderPromotionsSidebar(ctx);
      renderListingsFilterSidebar(ctx);
      renderSEOSidebar(ctx);
    }
    renderGrid(ctx);
  };

  initSelectHandler(ctx);
  initCategoryHandlers(ctx);
  initFilterHandlers(ctx);
  initImportExportHandlers(ctx);
  initPromotionsHandler(ctx);
  initBSR(ctx);
  initSEOHandler(ctx);

  await ctx.refresh();

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'db_changed') ctx.refresh();
  });
})();
