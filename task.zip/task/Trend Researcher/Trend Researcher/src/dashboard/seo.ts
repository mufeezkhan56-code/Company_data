export interface SEOItem {
  id: string;
  label: string;
  icon: string;
  color: string;
}

export const SEO_CHECKLIST: SEOItem[] = [
  { id: 'title',         label: 'Title',          icon: '📝', color: '#3498db' },
  { id: 'price',         label: 'Price',          icon: '💰', color: '#2ecc71' },
  { id: 'images',        label: 'Images',         icon: '🖼️', color: '#e74c3c' },
  { id: 'video',         label: 'Video',          icon: '🎥', color: '#9b59b6' },
  { id: 'description',   label: 'Description',    icon: '📄', color: '#f39c12' },
  { id: 'itemSpecifics', label: 'Item Specifics', icon: '📋', color: '#1abc9c' },
];

export const SEO_MAP = new Map(SEO_CHECKLIST.map(s => [s.id, s]));

export function buildSeoBadgesHtml(seoChecklist: Record<string, boolean> | undefined): string {
  if (!seoChecklist) return '';
  return SEO_CHECKLIST
    .filter(item => seoChecklist[item.id] === true)
    .map(item => `<span class="seo-badge" style="background:${item.color}" title="${item.label}">${item.icon}</span>`)
    .join('');
}
