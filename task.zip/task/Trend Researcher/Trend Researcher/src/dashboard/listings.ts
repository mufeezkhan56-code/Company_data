import TrendResearcherDB from '../db';

export interface ListingItem {
  designId: string;
  channel: string;
  listingLink: string;
  title: string;
}

// ─── CSV Parser ───────────────────────────────────────────────────────────────

function parseCSVRow(line: string): string[] {
  const cols: string[] = [];
  let cur = '', inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQ) {
      if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (ch === '"') inQ = false;
      else cur += ch;
    } else {
      if (ch === '"') inQ = true;
      else if (ch === ',') { cols.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
  }
  cols.push(cur.trim());
  return cols;
}

function parseListingsCSV(text: string): ListingItem[] {
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  if (lines.length < 2) return [];

  const headers = parseCSVRow(lines[0]).map(h => h.toLowerCase().trim());
  const col = (name: string) => headers.indexOf(name);

  const colDesignId    = col('design_id');
  const colChannel     = col('channel');
  const colLink        = col('listing_link');
  const colTitle       = col('title');

  if (colDesignId === -1 || colLink === -1) return [];

  const items: ListingItem[] = [];
  for (const line of lines.slice(1)) {
    const r = parseCSVRow(line);
    const designId = (r[colDesignId] || '').trim();
    if (!designId) continue;
    items.push({
      designId,
      channel:     colChannel !== -1 ? (r[colChannel] || '').trim() : '',
      listingLink: (r[colLink]  || '').trim(),
      title:       colTitle  !== -1 ? (r[colTitle]  || '').trim() : '',
    });
  }
  return items;
}

// ─── Import ───────────────────────────────────────────────────────────────────

export async function importListingsFromFile(
  file: File,
  onProgress: (msg: string) => void
): Promise<{ imported: number }> {
  onProgress('Reading file…');
  const text = await file.text();
  const items = parseListingsCSV(text);

  if (items.length === 0) {
    onProgress('No valid rows found');
    return { imported: 0 };
  }

  onProgress(`Importing ${items.length} listings…`);
  await TrendResearcherDB.importListings(items);
  onProgress(`✓ ${items.length} listings imported`);
  return { imported: items.length };
}

// ─── Lookup ───────────────────────────────────────────────────────────────────

const DESIGN_ID_FIELDS = [
  'designId', 'colourfulDesignId', 'blackDesignId', 'whiteDesignId',
  'designMen', 'designWomen', 'designBoy', 'designGirl',
  'designBabyBoy', 'designBabyGirl',
] as const;

export async function lookupListingsForStageRecord(stageRecord: any): Promise<ListingItem[]> {
  const ids = Array.from(new Set(
    DESIGN_ID_FIELDS
      .map(f => (stageRecord[f] || '').trim())
      .filter(Boolean)
  ));
  if (ids.length === 0) return [];
  return await TrendResearcherDB.lookupListingsByDesignIds(ids) as ListingItem[];
}
