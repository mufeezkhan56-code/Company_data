// Demand signal fetchers for eBay and Etsy product pages

// ─── eBay ─────────────────────────────────────────────────────────────────────

const EBAY_DEMAND_PATTERNS = [
  /\d+\s+sold\s+today/i,
  /\d+\s+viewed\s+today/i,
  /\d+\s+views?\s+in\s+the\s+last/i,
  /this\s+one[''s]*\s+trending/i,
  /almost\s+gone/i,
  /nearly\s+gone/i,
  /last\s+one/i,
  /\d+\s+watchers?/i,
  /\d+\s+sold\s+in\s+last/i,
  /in\s+demand/i,
  /popular\s+now/i,
  /in\s+\d+\+?\s*(baskets?|carts?)/i,
  /\d+\s+people\s+(are\s+)?watching/i,
];

function matchesEbayDemand(text: string): boolean {
  return EBAY_DEMAND_PATTERNS.some(p => p.test(text));
}

export async function fetchEbayDemandSignal(listingUrl: string): Promise<string | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(listingUrl, {
      credentials: 'include',
      signal: controller.signal,
      headers: { 'Accept': 'text/html', 'Accept-Language': 'en-GB,en;q=0.9' },
    });
    if (!res.ok) return null;
    const html = await res.text();

    // Strategy 1: urgencySignalText in embedded JSON
    const jsonMatch = html.match(/"urgencySignalText"\s*:\s*"([^"]+)"/i);
    if (jsonMatch) return jsonMatch[1].replace(/\\u[\dA-Fa-f]{4}/g,
      c => String.fromCharCode(parseInt(c.slice(2), 16)));

    // Strategy 2: DOM urgency elements
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const urgency = doc.querySelector(
      '.vim-soldcnt-badge, [data-testid="x-ebay-signal"] .ux-textspans, ' +
      '.vim.x-urgency-signal .ux-textspans, .x-urgency-signal .ux-textspans'
    );
    if (urgency) {
      const t = urgency.textContent?.trim() || '';
      if (t.length > 2 && matchesEbayDemand(t)) return t;
    }

    // Strategy 3: TreeWalker on visible text nodes
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const tag = (node as Text).parentElement?.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let node: Node | null;
    while ((node = walker.nextNode())) {
      const text = (node as Text).nodeValue?.trim() || '';
      if (text.length > 3 && text.length < 200 && matchesEbayDemand(text)) return text;
    }

    // Strategy 4: Script JSON blocks
    for (const script of Array.from(doc.querySelectorAll('script:not([src])'))) {
      const content = script.textContent || '';
      if (content.length < 10) continue;
      const m = content.match(
        /((?:in\s+)?\d+\+?\s*(?:baskets?|carts?|\s*sold\s+today|\s*viewed\s+today|\s*watchers?)[^"]{0,60}|this\s+one[''s]*\s+trending[^"]{0,60}|almost\s+gone|nearly\s+gone|last\s+one|in\s+demand|popular\s+now)/i
      );
      if (m) return m[0].slice(0, 120).replace(/\\n/g, ' ').replace(/\\/g, '').trim();
    }
    return null;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

// ─── Etsy ─────────────────────────────────────────────────────────────────────

const BADGE_SLOT_REGEX = /product image \d+ of [\d+]+\s+([\s\S]*?)\s*(?:Now\s+)?Price:/i;

const ETSY_DEMAND_PATTERNS = [
  /in\s+(over\s+)?\d+\+?\s*(baskets?|carts?)/i,
  /\d+\s+people\s+bought\s+this/i,
  /\d+\s+sold\s+in\s+the\s+last/i,
  /in\s+demand/i,
  /popular\s+now/i,
  /\d+\s+views?\s+in\s+the\s+last\s+\d+\s+hours?/i,
  /\d+\s+favourited/i,
  /nearly\s+gone/i,
  /almost\s+gone/i,
];

function matchesEtsyDemand(text: string): boolean {
  return ETSY_DEMAND_PATTERNS.some(p => p.test(text));
}

export async function fetchEtsyDemandSignal(listingUrl: string): Promise<string | null> {
  try {
    const res = await fetch(listingUrl, {
      credentials: 'include',
      headers: { 'Accept': 'text/html', 'Accept-Language': 'en-GB,en;q=0.9' },
    });
    if (!res.ok) return null;
    const html = await res.text();

    // Strategy 1: Regex on raw HTML between product image and Price lines
    const rawMatch = html.match(BADGE_SLOT_REGEX);
    if (rawMatch) {
      const raw = rawMatch[1].replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
      if (raw.length > 0) return raw;
    }

    // Strategy 2: TreeWalker on visible text nodes
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, null);
    let node: Node | null;
    while ((node = walker.nextNode())) {
      const text = (node as Text).nodeValue?.trim() || '';
      if (matchesEtsyDemand(text)) return text;
    }

    // Strategy 3: Script JSON blocks
    for (const script of Array.from(doc.querySelectorAll('script[type="application/json"], script:not([src])'))) {
      const content = script.textContent || '';
      if (content.length < 10) continue;
      const m = content.match(
        /(in\s+(over\s+)?\d+\+?\s*(baskets?|carts?)|\d+\s+people\s+bought\s+this[^"]{0,60}|\d+\s+sold\s+in\s+the\s+last[^"]{0,40}|in\s+demand|popular\s+now|nearly\s+gone|almost\s+gone)/i
      );
      if (m) return m[0].replace(/\\n/g, ' ').replace(/\\/g, '').trim();
    }
    return null;
  } catch {
    return null;
  }
}
