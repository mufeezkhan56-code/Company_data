/// <reference types="chrome" />

export function isAlive(): boolean {
  try { return !!chrome.runtime.id; } catch (e) { return false; }
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export function now(): string { return new Date().toISOString(); }

export function extractId(url: string | undefined): string | null {
  if (!url) return null;
  const amz  = url.match(/\/dp\/([A-Z0-9]{10})/);
  if (amz)  return 'amz_'  + amz[1];
  const ebay = url.match(/\/itm\/(?:[^?]*\/)?(\d{8,})/);
  if (ebay) return 'ebay_' + ebay[1];
  const etsy = url.match(/\/listing\/(\d+)/);
  if (etsy) return 'etsy_' + etsy[1];
  return null;
}

export async function dispatch(action: string, payload?: any): Promise<any> {
  if (!isAlive()) return null;
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'db_action', action, payload }, response => {
      if (chrome.runtime.lastError) {
        console.error("Extension comms error:", chrome.runtime.lastError.message);
        resolve(null);
      } else if (response && response.success) {
        resolve(response.data);
      } else {
        console.error("DB Action Failed:", response?.error);
        resolve(null);
      }
    });
  });
}

export async function clearAll(): Promise<void> {
  await dispatch('clearAll');
}
