import * as dbCategories from './categories';
import * as dbProducts from './products';
import * as dbStorage from './storage';

export const TrendResearcherDB = {
  // Categories
  getCategories:        dbCategories.getCategories,
  getCategoriesByType:  dbCategories.getCategoriesByType,
  getCategory:          dbCategories.getCategory,
  createCategory:       dbCategories.createCategory,
  updateCategory:       dbCategories.updateCategory,
  deleteCategory:       dbCategories.deleteCategory,
  
  // Products
  getProducts:           dbProducts.getProducts,
  getPagedProducts:      dbProducts.getPagedProducts,
  getProductCount:       dbProducts.getProductCount,
  getProduct:            dbProducts.getProduct,
  saveProduct:           dbProducts.saveProduct,
  updateProduct:         dbProducts.updateProduct,
  deleteProduct:         dbProducts.deleteProduct,
  isProductSaved:        dbProducts.isProductSaved,
  exportAll:             dbProducts.exportAll,
  importAll:             (data: any) => dbStorage.dispatch('importAll', data),
  
  // Stages (CSV import)
  clearStages:    () => dbStorage.dispatch('clearStages'),
  importStages:   (items: any[]) => dbStorage.dispatch('importStages', items),
  lookupStages:   (ids: string[]) => dbStorage.dispatch('lookupStages', ids),
  getAllStageIds:  () => dbStorage.dispatch('getAllStageIds'),
  getAllStages:    () => dbStorage.dispatch('getAllStages'),
  getAllProductPlatformIds: () => dbStorage.dispatch('getAllProductPlatformIds'),
  getSavedMap:             () => dbStorage.dispatch('getSavedMap'),

  // Listings (design_id CSV)
  importListings:           (items: any[]) => dbStorage.dispatch('importListings', items),
  clearListings:            () => dbStorage.dispatch('clearListings'),
  getListingsCount:         () => dbStorage.dispatch('getListingsCount'),
  getAllListings:            () => dbStorage.dispatch('getAllListings'),
  lookupListingsByDesignIds:(ids: string[]) => dbStorage.dispatch('lookupListingsByDesignIds', ids),

  // Storage utils
  clearAll: dbStorage.clearAll,
};

export default TrendResearcherDB;
