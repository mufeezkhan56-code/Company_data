import { dispatch, generateId, now } from './storage';

export interface Product {
  id: string;
  title: string;
  imageUrl: string;
  productUrl: string;
  platform: string;
  platformId: string | null;
  categoryId: string;
  categoryType?: string;
  categoryName?: string;
  price?: string;
  currency?: string;
  rating?: string;
  reviewCount?: string;
  bsr?: string;
  bsrNumber?: number;
  dispatches?: string;
  soldBy?: string;
  notes?: string;
  tags?: string[];
  promotions?: string[];
  seoChecklist?: Record<string, boolean>;
  source?: string;
  savedAt: string;
  updatedAt: string;
}

export async function getProducts(): Promise<Product[]> {
    return await dispatch('getPagedProducts', { limit: 10000 });
}

export async function getPagedProducts(options: { categoryId?: string, query?: string, sortBy?: string, limit?: number, offset?: number, platform?: string } = {}): Promise<Product[]> {
    return await dispatch('getPagedProducts', options);
}

export async function getProductCount(): Promise<number> {
    return await dispatch('getProductCount');
}

export async function getProduct(id: string): Promise<Product | null> {
  return await dispatch('getProduct', { id });
}

export async function saveProduct(input: any): Promise<Product> {
  const prod: Product = {
    id: generateId(),
    title: input.title,
    imageUrl: input.imageUrl,
    productUrl: input.productUrl,
    platform: input.platform,
    platformId: input.platformId,
    categoryId: input.categoryId,
    categoryType: input.categoryType,
    categoryName: input.categoryName,
    price: input.price || '',
    currency: input.currency || '',
    rating: input.rating || '',
    reviewCount: input.reviewCount || '',
    bsr: input.bsr || '',
    bsrNumber: 999999999,
    dispatches: input.dispatches || '',
    soldBy: input.soldBy || '',
    notes: input.notes || '',
    tags: input.tags || [],
    source: input.source || '',
    savedAt: now(),
    updatedAt: now()
  };
  // Background handler atomically saves product + updates category count in one transaction
  await dispatch('saveProduct', prod);
  return prod;
}

export async function updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
  updates.updatedAt = now();
  const success = await dispatch('updateProduct', { id, updates });
  if (!success) return null;
  return await getProduct(id);
}

export async function deleteProduct(id: string): Promise<void> {
  // Background handler atomically deletes product + updates category count in one transaction
  await dispatch('deleteProduct', { id });
}

export async function isProductSaved(productUrl: string, platformId?: string | null): Promise<Product | null> {
  return await dispatch('isProductSaved', { productUrl, platformId });
}

export async function exportAll(): Promise<any> {
  return await dispatch('exportAll');
}
