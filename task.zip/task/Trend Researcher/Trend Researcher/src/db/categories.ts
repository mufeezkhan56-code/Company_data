import { dispatch, generateId, now } from './storage';

export interface Category {
  id: string;
  type: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  tags: string[];
  productCount: number;
  eventStatus?: 'current' | 'past' | 'upcoming';
  createdAt: string;
  updatedAt: string;
}

export async function getCategories(): Promise<Category[]> {
  return (await dispatch('getCategories')) || [];
}

export async function getCategoriesByType(type: string): Promise<Category[]> {
  const all = await getCategories();
  return all.filter(c => c.type === type);
}

export async function getCategory(id: string): Promise<Category | null> {
  return await dispatch('getCategory', { id });
}

export async function createCategory({ type, name, description = '', color = '', icon = '', tags = [], eventStatus }: { type: string, name: string, description?: string, color?: string, icon?: string, tags?: string[], eventStatus?: 'current' | 'past' | 'upcoming' }): Promise<Category> {
  const cat: Category = {
    id: generateId(), type, name, description, color, icon, tags, productCount: 0, eventStatus, createdAt: now(), updatedAt: now()
  };
  await dispatch('createCategory', cat);
  return cat;
}

export async function updateCategory(id: string, updates: Partial<Category>): Promise<Category | null> {
  updates.updatedAt = now();
  const success = await dispatch('updateCategory', { id, updates });
  if (!success) return null;
  return await getCategory(id);
}

export async function deleteCategory(id: string): Promise<void> {
  await dispatch('deleteCategory', { id });
}
