# Task: Add "✅ SEO Checklist" Feature to Dashboard

## Overview

Add a **new SEO Checklist feature** that allows users to mark which SEO elements are complete for each product, and filter products by SEO checklist status — similar to the Promotions filter system.

---

## What We Want to Achieve

### 1. SEO Checklist Items

Each product should have a checklist with these SEO items:

| Item | Icon | Color | Description |
|------|------|-------|-------------|
| **Title** | 📝 | `#3498db` | Product title is optimized |
| **Price** | 💰 | `#2ecc71` | Price is competitive/optimized |
| **Images** | 🖼️ | `#e74c3c` | Has quality product images |
| **Video** | 🎥 | `#9b59b6` | Has product video |
| **Description** | 📄 | `#f39c12` | Has detailed description |
| **Item Specifics** | 📋 | `#1abc9c` | Has complete item specifics/attributes |

### 2. Product Card: SEO Button

On each product card (similar to the "🏷️" promotions button), add:
- A **"✅ SEO"** button that appears on hover
- Clicking it opens a modal to check off completed SEO items

### 3. SEO Modal

When clicking the SEO button, show a modal with checkboxes for all 6 items. User can check/uncheck and save.

### 4. SEO Badges on Product Card

After saving, show completed SEO items as colored badges on the product card (icon only, compact).

### 5. SEO Filter in Sidebar

Add a **new filter section** in sidebar (same style as Promotions filter):

```
┌─────────────────────────────────┐
│ ✅ SEO Checklist                │
├─────────────────────────────────┤
│ 📝 Title       [Y] [N] [✕]  85 │
│ 💰 Price       [Y] [N] [✕]  72 │
│ 🖼️ Images      [Y] [N] [✕]  91 │
│ 🎥 Video       [Y] [N] [✕]  34 │
│ 📄 Description [Y] [N] [✕]  68 │
│ 📋 Item Specs  [Y] [N] [✕]  45 │
└─────────────────────────────────┘
```

**Filter Behavior:**
- **Y (Yes)** — Show only products that HAVE this SEO item checked
- **N (No)** — Show only products that do NOT have this SEO item checked
- **✕ (Clear)** — Remove this filter

Filters should be **combinable** (e.g., Title=Yes + Video=No).

---

## Data Structure

### Product Schema Update

Add `seoChecklist` field to products:

```typescript
seoChecklist?: {
  title?: boolean;
  price?: boolean;
  images?: boolean;
  video?: boolean;
  description?: boolean;
  itemSpecifics?: boolean;
};
```

### SEO Checklist Definition

```typescript
interface SEOItem {
  id: string;
  label: string;
  icon: string;
  color: string;
}

const SEO_CHECKLIST: SEOItem[] = [
  { id: 'title',         label: 'Title',         icon: '📝', color: '#3498db' },
  { id: 'price',         label: 'Price',         icon: '💰', color: '#2ecc71' },
  { id: 'images',        label: 'Images',        icon: '🖼️', color: '#e74c3c' },
  { id: 'video',         label: 'Video',         icon: '🎥', color: '#9b59b6' },
  { id: 'description',   label: 'Description',   icon: '📄', color: '#f39c12' },
  { id: 'itemSpecifics', label: 'Item Specifics',icon: '📋', color: '#1abc9c' },
];
```

---

## Files to Create / Modify

### New Files to Create

| File | Purpose |
|------|---------|
| `src/dashboard/seo.ts` | SEO checklist definitions, SEO badge HTML builder, helper functions |
| `src/dashboard/handlers/seo-handler.ts` | SEO modal handler (open, save, close), event listeners |

### Files to Modify

| File | What to Change |
|------|----------------|
| `src/dashboard/types.ts` | Add `seoFilters: Map<string, 'yes' | 'no'>` to DashboardContext |
| `src/db/products.ts` | Add `seoChecklist` field to Product interface |
| `src/dashboard/grid-card.ts` | Add SEO badge rendering in `buildCardHtml()` |
| `src/dashboard/grid.ts` | Add SEO filter logic in `getFilteredProducts()`; Add SEO button click handler; Import and call `renderSEOSidebar()` |
| `src/dashboard/handlers/filters.ts` | Initialize SEO filter toggle button listeners |
| `dashboard.html` | Add SEO modal HTML structure |
| `dashboard.css` | Add styles for SEO badges, SEO button, SEO modal, SEO filter toggles |
| `src/background/db-products.ts` | Ensure `updateProduct` handles `seoChecklist` field |

---

## Modular Architecture

Follow the same pattern as Promotions:

```
promotions.ts          →  seo.ts
  (definitions)            (definitions)

promotions-handler.ts  →  seo-handler.ts
  (modal logic)            (modal logic)

promotionFilters       →  seoFilters
  (Map in context)         (Map in context)

promo-badges-row       →  seo-badges-row
  (rendered badges)        (rendered badges)
```

---

## UI/UX Requirements

### SEO Button on Product Card
- Appears on hover (same as promotions button)
- Positioned next to promotions button
- Icon: ✅
- Tooltip: "SEO Checklist"

### SEO Modal
- Title: "✅ SEO Checklist"
- 6 checkboxes with icon + label for each item
- Save button updates the product
- Cancel button closes without saving
- Click outside modal closes it

### SEO Badges
- Small badges showing completed SEO items
- Colored background per item (from SEO_CHECKLIST)
- Show icon only (compact)
- Positioned near promotions badges

### SEO Filter in Sidebar
- Section title: "✅ SEO Checklist"
- One row per SEO item
- Each row has: Icon + Label + Y/N/✕ toggles + Count
- Toggles work same as promotions filter
- Counts update dynamically

---

## Filter Logic

In `getFilteredProducts()` function:

```typescript
if (ctx.seoFilters.size > 0) {
  products = products.filter(p => {
    const seo = p.seoChecklist || {};
    
    for (const [seoId, state] of ctx.seoFilters) {
      const isComplete = seo[seoId] === true;
      
      if (state === 'yes' && !isComplete) return false;
      if (state === 'no' && isComplete) return false;
    }
    
    return true;
  });
}
```

---

## Testing Checklist

After implementation, test:

- [ ] SEO button appears on product cards on hover
- [ ] Clicking SEO button opens modal
- [ ] Modal shows all 6 SEO items with checkboxes
- [ ] Can check/uncheck items and save
- [ ] Saved SEO badges appear on product card
- [ ] SEO filter section appears in sidebar
- [ ] Each SEO item filter (Y/N/✕) works correctly
- [ ] Multiple SEO filters can be combined
- [ ] Counts update when SEO checklists are saved
- [ ] Works together with other filters (promotions, my listings, stages, search, platform)
- [ ] SEO badges are colored correctly per item
- [ ] Modal closes on Cancel, Save, and click outside

---

## Reference: Promotions Implementation

Look at these existing files for the pattern to follow:

| Promotions Feature | SEO Feature (New) |
|--------------------|-------------------|
| `src/dashboard/promotions.ts` | `src/dashboard/seo.ts` |
| `src/dashboard/handlers/promotions-handler.ts` | `src/dashboard/handlers/seo-handler.ts` |
| `promotionFilters` in types | `seoFilters` in types |
| Promo badges on cards | SEO badges on cards |
| Promotions sidebar filter | SEO sidebar filter |

**Key Difference:**
- Promotions = array of promotion IDs (`string[]`)
- SEO Checklist = object with boolean fields (`{ title: boolean, price: boolean, ... }`)

---

## Summary

> We want to add an **SEO Checklist feature** similar to the Promotions system. Each product should have a checklist with 6 items: Title, Price, Images, Video, Description, and Item Specifics.
>
> Users can:
> 1. Click an **"✅ SEO"** button on each product card
> 2. Check off completed SEO items in a modal
> 3. See SEO badges on the product card showing completed items
> 4. Filter products in the sidebar by SEO checklist status (Yes/No/Clear for each item)
>
> **Create separate modular files:**
> - `src/dashboard/seo.ts` — SEO definitions and badge rendering (like `promotions.ts`)
> - `src/dashboard/handlers/seo-handler.ts` — SEO modal handler (like `promotions-handler.ts`)
>
> The implementation should follow the **exact same pattern as Promotions**, with:
> - A new `seoChecklist` field on products
> - SEO badges rendered on product cards
> - SEO filter section in sidebar with Y/N/✕ toggles
> - Filter logic in `getFilteredProducts()`
>
> Filters should be **combinable** and work alongside all existing filters.
