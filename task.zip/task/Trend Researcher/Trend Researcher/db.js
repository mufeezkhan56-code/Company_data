/**
 * db.js — Public TrendResearcherDB facade
 * Load order: db-storage.js → db-categories.js → db-products.js → db.js
 */
const TrendResearcherDB = (() => {
  'use strict';
  return {
    // Categories
    getCategories:        _TRCategories.getCategories,
    getCategoriesByType:  _TRCategories.getCategoriesByType,
    getCategory:          _TRCategories.getCategory,
    createCategory:       _TRCategories.createCategory,
    updateCategory:       _TRCategories.updateCategory,
    deleteCategory:       _TRCategories.deleteCategory,
    // Products
    getProducts:           _TRProducts.getProducts,
    getProductsByCategory: _TRProducts.getProductsByCategory,
    getProduct:            _TRProducts.getProduct,
    saveProduct:           _TRProducts.saveProduct,
    updateProduct:         _TRProducts.updateProduct,
    deleteProduct:         _TRProducts.deleteProduct,
    isProductSaved:        _TRProducts.isProductSaved,
    exportAll:             _TRProducts.exportAll,
    // Storage utils
    getMeta:  _TRStorage.getMeta,
    clearAll: _TRStorage.clearAll,
  };
})();
