# Bug Fix: SEO Button Opens Product Link Instead of Modal

## Problem

When clicking the **✅ SEO** button on a product card, it opens the product link in a new tab instead of opening the SEO checklist modal.

The **🏷️ Promotions** button works correctly — it opens the promotions modal without opening the product link.

## Root Cause

In `src/dashboard/grid.ts`, the card click handler has exclusions for certain buttons:

```typescript
el.addEventListener('click', e => {
  const target = e.target as HTMLElement;
  if (target.closest('.product-card-delete')) return;
  if (target.closest('.product-card-promo-btn')) return;  // ✅ This exists
  if (target.closest('.listings-toggle-btn')) return;
  if (target.closest('#listings-float-panel')) return;
  
  // ❌ Missing: .product-card-seo-btn
  
  // Opens product link
  const prod = ctx.allProducts.find(p => p.id === el.dataset.id);
  if (prod?.productUrl) window.open(prod.productUrl, '_blank');
});
```

The SEO button (`.product-card-seo-btn`) is **NOT** in the exclusion list, so the click falls through and opens the product link.

## Solution

Add the SEO button to the exclusion list in `src/dashboard/grid.ts`:

```typescript
if (target.closest('.product-card-delete')) return;
if (target.closest('.product-card-promo-btn')) return;
if (target.closest('.product-card-seo-btn')) return;  // ← Add this line
if (target.closest('.listings-toggle-btn')) return;
if (target.closest('#listings-float-panel')) return;
```

## Files to Modify

| File | Change |
|------|--------|
| `src/dashboard/grid.ts` | Add exclusion for `.product-card-seo-btn` (around line 194) |

## Testing

After fixing:

- [ ] Clicking ✅ SEO button opens the SEO modal (not product link)
- [ ] Clicking 🏷️ Promotions button still works correctly
- [ ] Clicking 🔗 My Listings button still works correctly
- [ ] Clicking on the card body (not buttons) still opens product link
