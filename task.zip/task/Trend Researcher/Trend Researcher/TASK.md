# Task: Add "🔗 My Listings" Filter to Dashboard

## Overview

Add a **new filter section** to the dashboard sidebar called **"🔗 My Listings"** that allows filtering products based on whether they have associated listings on Amazon, eBay, or Etsy.

---

## Current System (What We Have)

### 1. Listings CSV Import

We currently upload a CSV with these columns:

```csv
design_id,channel,listing_link,title
12345,Amazon,https://amazon.co.uk/dp/B0ABC123,"My T-Shirt"
12345,eBay,https://ebay.co.uk/itm/987654321,"My T-Shirt"
12345,Etsy,https://etsy.com/listing/112233445,"My T-Shirt"
```

**Channel naming convention:** Our channel names usually follow patterns like:
- `amazon_hashim`
- `amazon-hashim`
- `Amazon`
- `eBay`
- `Etsy`

**Key point:** The channel name **always contains** "amazon", "ebay", or "etsy" (case-insensitive).

### 2. Current Display

When a product's design_id matches a listing:
- A **"🔗 My Listings"** button appears on the product card
- Clicking it shows a floating panel with listings
- Each listing shows a **colored tag** based on channel:
  - Amazon → Orange (`#ff9900`)
  - eBay → Blue (`#0064d2`)
  - Etsy → Red-Orange (`#f45800`)

### 3. Current Filters

We already have similar filters in the sidebar:
- **📋 Stages** — Filter by stage name from CSV
- **🏷️ Promotions** — Filter by Yes/No/X (has promotion, doesn't have, no filter)

---

## What We Want to Achieve

### New Sidebar Section: "🔗 My Listings"

Add a filter section similar to the **Promotions filter** with these options:

```
┌─────────────────────────────────┐
│ 🔗 My Listings                  │
├─────────────────────────────────┤
│ 🟠 Amazon    [Y] [N] [✕]  125  │
│ 🔵 eBay      [Y] [N] [✕]   87  │
│ 🟠 Etsy      [Y] [N] [✕]   43  │
└─────────────────────────────────┘
```

### Filter Behavior

| Button | Meaning |
|--------|---------|
| **Y (Yes)** | Show only products that HAVE listings on this platform |
| **N (No)** | Show only products that do NOT have listings on this platform |
| **✕ (Clear)** | Remove this filter (show all) |

### Filter Combinations

User should be able to combine filters like:
- Amazon = Yes, eBay = No → Show products with Amazon listings but no eBay listings
- Amazon = Yes, Etsy = Yes → Show products listed on both Amazon AND Etsy
- All Clear → Show all products

---

## How to Detect Platform

Since our CSV channel names always contain "amazon", "ebay", or "etsy", the platform should be detected like this:

```javascript
If channel contains "amazon" (case-insensitive) → Platform = Amazon
If channel contains "ebay" (case-insensitive)   → Platform = eBay
If channel contains "etsy" (case-insensitive)   → Platform = Etsy
```

This handles all our naming variations:
- `amazon_hashim` → Amazon ✅
- `amazon-hashim` → Amazon ✅
- `Amazon` → Amazon ✅
- `eBay` → eBay ✅
- `Etsy` → Etsy ✅

---

## Filter Logic

For each product in the database:

1. **Get the product's stage record** (from Stages CSV import)
2. **Extract all design IDs** from the stage record (designId, colourfulDesignId, blackDesignId, etc.)
3. **Find all listings** that match those design IDs (from Listings CSV import)
4. **Check which platforms** the product has listings on by reading the `channel` column

Then apply filters:
- If **Amazon = Yes**: Only show products that have at least one Amazon listing
- If **Amazon = No**: Only show products that have NO Amazon listings
- Same logic for eBay and Etsy

---

## Files to Work With

| File | Purpose | What to Do |
|------|---------|------------|
| `src/dashboard/types.ts` | Dashboard context interface | Add new property for listing filters (similar to how promotion filters are stored) |
| `src/dashboard/grid.ts` | Product filtering and sidebar rendering | Add filter logic to `getFilteredProducts()` function; Add sidebar rendering for "My Listings" section |
| `src/dashboard/handlers/filters.ts` | Filter initialization | Add event listeners for the new filter toggle buttons |
| `src/dashboard/listings.ts` | Listings data handling | May need to add helper function to detect platform from channel and check if product has listings |
| `src/dashboard/listings-badge.ts` | Listing badges on cards | Reference for how listings are currently matched to products |
| `dashboard.html` | Dashboard UI | May need to add HTML structure for the new filter section (if not rendered dynamically) |
| `dashboard.css` | Dashboard styles | Add styles for the new filter toggle buttons (can copy promotions filter styles) |

---

## UI/UX Requirements

### Sidebar Appearance

The "My Listings" section should:

1. Appear in sidebar below "Promotions" section
2. Show 3 rows (Amazon, eBay, Etsy)
3. Each row has:
   - Platform icon (🟠 for Amazon, 🔵 for eBay, 🟠 for Etsy)
   - Platform name
   - Three toggle buttons (Y/N/✕)
   - Count of products with listings on that platform

### Toggle Button Behavior

Same as promotions filter:
- Click "Y" → Active (green), filters to show only products WITH listings
- Click "N" → Active (red), filters to show only products WITHOUT listings
- Click "✕" → Active (gray), removes filter
- Only one state active per platform at a time

### Counts Update

Counts should update dynamically when:
- New listings are imported
- Products are deleted
- Filters are applied

---

## Testing Checklist

After implementation, test:

- [ ] Sidebar shows "🔗 My Listings" section
- [ ] Amazon filter (Y/N/✕) works correctly
- [ ] eBay filter (Y/N/✕) works correctly
- [ ] Etsy filter (Y/N/✕) works correctly
- [ ] Multiple platform filters can be combined (e.g., Amazon=Yes + eBay=No)
- [ ] Counts update when listings are imported
- [ ] Works with channel names like "amazon_hashim", "amazon-hashim", "Amazon", etc.
- [ ] Works together with other filters (search, platform, stages, promotions)

---

## Reference: Similar Existing Feature

Look at the **Promotions filter** implementation for reference:
- Same toggle button pattern (Yes/No/Clear)
- Same sidebar rendering approach
- Same filter logic structure

The "My Listings" filter should work the same way, but instead of checking `product.promotions`, it checks whether the product has matching listings on each platform.

---

## Summary

> We have a Listings CSV import system that stores our Amazon, eBay, and Etsy listing links with channel names (like 'amazon_hashim', 'eBay', 'Etsy'). We want to add a **new sidebar filter section** called **'🔗 My Listings'** similar to the existing Promotions filter.
>
> Each platform (Amazon, eBay, Etsy) should have **Yes/No/Clear toggle buttons**:
> - **Yes** = Show only products that HAVE listings on this platform
> - **No** = Show only products that do NOT have listings on this platform
> - **Clear** = Remove filter
>
> The platform should be detected from the `channel` column in our listings CSV by checking if it contains 'amazon', 'ebay', or 'etsy' (case-insensitive).
>
> Filters should be **combinable** (e.g., Amazon=Yes + eBay=No) and work alongside existing filters (search, platform, stages, promotions).
