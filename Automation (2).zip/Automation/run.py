#!/usr/bin/env python3
"""
Phase 0 CLI — Reminder Old/New SKU + Zayn Manual export edit.

Short form (testing / main path):
  python run.py 4113650610
  python run.py 4113650610 --dry-run
  python run.py 4113650610 --api-dry-run
  python run.py 4113650610 --allow-rerun

Long form still works:
  python run.py dry-run --order 4113650610
  python run.py apply-sku --order 4113650610 --export path.csv
"""

from __future__ import annotations

import argparse
import copy
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from replacement.channel_check import assess_sku_pair
from replacement.config import (
    mapping_name,
    output_dir,
    reminder_csv_path,
    replacement_queue_path,
    shipstation_bulk_max_calls,
    shipstation_manual_store_id,
    shipstation_tag_all_resend,
    shipstation_tag_bulk_making,
)
from replacement.export_finder import find_export_for_order
from replacement.logutil import setup_logger, write_run_report
from replacement.processed_ledger import mark_processed, was_processed
from replacement.sheet_reader import (
    filter_queue_rows,
    find_by_order_id,
    load_reminder_rows,
    parse_user_date,
    write_queue_csv,
)
from replacement.shipstation_api import (
    AmbiguousOrderError,
    OrderNotFoundError,
    ShipStationClient,
    ShipStationError,
    summarize_order,
)
from replacement.sku_editor import apply_sku_change, _is_discount_or_empty_sku


def _print_row_assessment(logger, row, assessment, prior) -> list[str]:
    block = [
        f"--- Row {row.source_row} ---",
        f"Order ID : {row.order_id}",
        f"CHANNEL  : {row.channel!r} (notes only)",
        f"Old SKU  : {row.old_sku or '(empty)'}",
        f"New SKU  : {row.new_sku or '(empty)'}",
        f"SKU mode : {assessment.get('sku_mode', '')}",
        f"Reason   : {row.reason or '(empty)'}",
        f"Status   : {row.status or '(empty) — manual green later'}",
        f"Clarity  : {assessment['clarity']}",
        f"Ready    : {assessment['use_as_sku']}",
    ]
    if prior:
        block.append(
            f"Already processed: YES at {prior.get('processed_at_utc')} "
            f"(sku={prior.get('sku_text')}) — do not ship twice"
        )
    else:
        block.append("Already processed: no")
    for flag in assessment["flags"]:
        block.append(f"Flag     : {flag}")
    block.append("")
    for line in block:
        logger.info("%s", line)
    return block


def run_dry_run(order: str | None, last: int, csv: str | None) -> int:
    logger = setup_logger()
    csv_path = Path(csv) if csv else reminder_csv_path()
    logger.info("Reading reminder CSV: %s", csv_path)

    rows = load_reminder_rows(csv_path)
    logger.info("Loaded %s non-empty rows (sheet is read-only — no writes)", len(rows))

    if order:
        selected = find_by_order_id(rows, order)
        if not selected:
            logger.error("Order not found: %s", order)
            return 1
    else:
        selected = [row for row in rows if row.order_id.strip()][-last:]

    report: list[str] = [
        "Phase 0 dry-run (Old SKU → New SKU)",
        f"Reminder CSV: {csv_path}",
        f"ShipStation mapping (later): {mapping_name()}",
        f"Rows selected: {len(selected)}",
        "Live MS sheet: NOT modified",
        "",
    ]

    for row in selected:
        assessment = assess_sku_pair(row)
        prior = was_processed(row.normalized_order_id, action="apply-sku")
        report.extend(_print_row_assessment(logger, row, assessment, prior))

        # If short dry-run for one order, also show which export would be used
        if order and assessment["use_as_sku"]:
            try:
                export_path = find_export_for_order(row.normalized_order_id)
                logger.info("Export auto-found: %s", export_path)
                report.append(f"Export auto-found: {export_path}")
                report.append("")
            except FileNotFoundError as exc:
                logger.warning("%s", exc)
                report.append(f"Export: NOT FOUND yet — {exc}")
                report.append("")

    report_path = write_run_report(report, prefix="dry-run")
    logger.info("Report saved: %s", report_path)
    print(f"\nDone. Report: {report_path}")
    return 0


def run_api_dry_run(
    order: str, csv: str | None = None, ship_order: str | None = None
) -> int:
    """Read exactly one ShipStation order. This function performs no writes.

    ``order`` is the Reminder Order ID (source of Old/New SKU).
    ``ship_order`` optionally overrides the exact ShipStation order number when
    it differs from the Reminder id (e.g. a one-time test order). It must still
    match a single live order exactly — no nearby/prefix selection.
    """
    logger = setup_logger()
    csv_path = Path(csv) if csv else reminder_csv_path()
    rows = load_reminder_rows(csv_path)
    matches = find_by_order_id(rows, order)
    if not matches:
        logger.error("Order not found in Reminder CSV: %s. No API call made.", order)
        return 1

    replacements, err = expand_replacements(matches)
    if err:
        logger.error("%s No API call made.", err)
        return 2

    normalized_order = matches[-1].normalized_order_id
    prior = was_processed(normalized_order, action="api-replacement")
    if prior:
        logger.error(
            "BLOCKED: API replacement already recorded for %s at %s. No API call made.",
            normalized_order,
            prior.get("processed_at_utc"),
        )
        return 3

    ship_lookup = (ship_order or normalized_order).strip()
    try:
        client = ShipStationClient()
        live_order, match_mode = resolve_original_for_resend(
            client, ship_lookup, replacements
        )
    except ShipStationError as exc:
        logger.error("%s", exc)
        return 4

    summary = summarize_order(live_order)
    live_items = summary["items"]
    live_skus = {
        str(item.get("sku") or "").strip().lower()
        for item in live_items
        if str(item.get("sku") or "").strip()
    }
    missing_old = [old for old, _new in replacements if old.lower() not in live_skus]
    matched = [old for old, _new in replacements if old.lower() in live_skus]

    report = [
        "Phase 1 ShipStation API dry-run (READ ONLY)",
        f"Reminder Order ID: {normalized_order}",
        f"ShipStation exact lookup: {ship_lookup}",
        f"Locate mode: {match_mode}",
        f"ShipStation Order Number: {summary['order_number']}",
        f"ShipStation internal Order ID: {summary['order_id']}",
        f"Status: {summary['status']}",
        f"Custom Field 1: {summary['custom_field_1'] or '(empty)'}",
        f"Reminder replacements: {replacements}",
        f"Matched Old SKU(s): {matched or '(none)'}",
        f"Missing Old SKU(s): {missing_old or '(none)'}",
        f"Live line count: {len(live_items)}",
        f"API calls used: {client.calls_made}",
        (
            "Rate limit: "
            f"limit={client.rate_limit.limit}, "
            f"remaining={client.rate_limit.remaining}, "
            f"reset_seconds={client.rate_limit.reset_seconds}"
        ),
        "WRITE PERFORMED: NO",
        "Custom Field / SKU / order: NOT modified",
    ]
    for index, item in enumerate(live_items, start=1):
        report.append(
            f"Line {index}: sku={item['sku']!r}, qty={item['quantity']!r}, "
            f"name={item['name']!r}"
        )

    for line in report:
        logger.info("%s", line)
    report_path = write_run_report(report, prefix="api-dry-run")
    logger.info("Report saved: %s", report_path)

    if missing_old:
        logger.error(
            "BLOCKED: Reminder Old SKU did not match every requested live item. "
            "No writes made."
        )
        return 5
    if summary["status"] not in {"awaiting_payment", "awaiting_shipment", "on_hold"}:
        logger.warning(
            "Order status is %s; V1 create/update only supports open orders. No writes made.",
            summary["status"],
        )
        return 6

    logger.info("API dry-run passed. Exact order and Old SKU match; still no writes made.")
    return 0


OPEN_STATUSES = {"awaiting_payment", "awaiting_shipment", "on_hold"}


def _sku_key(value: object) -> str:
    return " ".join(str(value or "").split()).lower()


def _split_skus(value: str) -> list[str]:
    """One Reminder cell may hold several SKUs separated by commas."""
    parts = [p.strip() for p in str(value or "").replace(";", ",").split(",")]
    return [p for p in parts if p]


RESEND_KEY_PREFIX = "resend-"


def _is_resend_order(order: dict, resend_value: str = "resend") -> bool:
    key = str(order.get("orderKey") or "").strip().lower()
    cf1 = _sku_key((order.get("advancedOptions") or {}).get("customField1"))
    return key.startswith(RESEND_KEY_PREFIX) or cf1 == _sku_key(resend_value)


def _order_matches_old_skus(order: dict, replacements: list[tuple[str, str]]) -> bool:
    live_items = order.get("items") or []
    for old_sku, _new in replacements:
        hits = [it for it in live_items if _sku_key(it.get("sku")) == _sku_key(old_sku)]
        if len(hits) != 1:
            return False
    return True


def resolve_original_for_resend(
    client: ShipStationClient,
    order_number: str,
    replacements: list[tuple[str, str]],
    resend_value: str = "resend",
) -> tuple[dict, str]:
    """Pick the original child order for a resend. Normal exact match first; then Multiple.

  Stops safely if ambiguous — never guesses wrong order.
    """
    requested = order_number.strip().lstrip("#").strip()
    requested_norm = client._normalize_order_number(requested)

    def disambiguate(originals: list[dict], label: str) -> tuple[dict, str]:
        if not originals:
            raise OrderNotFoundError(
                f"No original ShipStation order for {requested}. No writes made."
            )
        if len(originals) == 1:
            chosen = originals[0]
            if not _order_matches_old_skus(chosen, replacements):
                raise ShipStationError(
                    f"Order {chosen.get('orderNumber')} found but Old SKU line count wrong. "
                    "Stopped; no writes made."
                )
            return chosen, label
        sku_ok = [o for o in originals if _order_matches_old_skus(o, replacements)]
        if len(sku_ok) == 1:
            return sku_ok[0], f"{label}_by_sku"
        ids = [f"{o.get('orderId')}:{o.get('orderNumber')}" for o in originals]
        raise AmbiguousOrderError(
            f"Multiple originals for {requested}: {ids}. Stopped; no writes made."
        )

    # --- Normal path: exact order number (unchanged for typical orders) ---
    exact_candidates = client.search_by_order_number(requested)
    originals_exact = [o for o in exact_candidates if not _is_resend_order(o, resend_value)]
    if originals_exact:
        return disambiguate(originals_exact, "exact_order_number")

    # --- (Multiple) path: wider search + child match by Old SKU / number ---
    related = client.search_orders_related_to_number(requested)
    originals_related = [o for o in related if not _is_resend_order(o, resend_value)]
    exact_in_related = [
        o
        for o in originals_related
        if client._normalize_order_number(str(o.get("orderNumber", ""))) == requested_norm
    ]
    if exact_in_related:
        return disambiguate(exact_in_related, "multiple_exact_child")

    sku_ok = [o for o in originals_related if _order_matches_old_skus(o, replacements)]
    if len(sku_ok) == 1:
        child_num = sku_ok[0].get("orderNumber")
        return (
            sku_ok[0],
            f"multiple_child_by_sku (resolved {child_num})",
        )
    if len(sku_ok) > 1:
        ids = [f"{o.get('orderId')}:{o.get('orderNumber')}" for o in sku_ok]
        raise AmbiguousOrderError(
            f"Multiple (Multiple) children match Old SKU for {requested}: {ids}. "
            "Stopped; fix Reminder or handle manually."
        )

    raise OrderNotFoundError(
        f"Order not found in ShipStation for {requested} (checked exact + Multiple search). "
        "No writes made."
    )


def pick_original_order(candidates: list, resend_value: str = "resend"):
    """From orders sharing one number, return the ORIGINAL (never a resend).

    Resends we create carry a ``resend-`` orderKey and Custom Field 1 = resend,
    so they are excluded. Anything still ambiguous stops the run.
    """
    if not candidates:
        raise OrderNotFoundError("Exact order not found in ShipStation. No writes made.")
    if len(candidates) == 1:
        return candidates[0]

    originals = []
    for order in candidates:
        key = str(order.get("orderKey") or "").strip().lower()
        cf1 = _sku_key((order.get("advancedOptions") or {}).get("customField1"))
        if key.startswith(RESEND_KEY_PREFIX) or cf1 == _sku_key(resend_value):
            continue
        originals.append(order)

    if not originals:
        raise ShipStationError(
            "Every order with this number looks like a resend; cannot identify the "
            "original. Stopped; no writes made."
        )
    if len(originals) > 1:
        ids = [str(o.get("orderId", "?")) for o in originals]
        raise AmbiguousOrderError(
            f"More than one non-resend order found: {ids}. Stopped; no writes made."
        )
    return originals[0]


def select_resend_items(
    items: list, replacements: list[tuple[str, str]]
) -> tuple[list, list[str], int, int]:
    """Keep only Reminder Old-SKU lines; drop discount/empty and other products.

    Original order is never mutated — caller must pass a copy of items.
    Multiple Old SKUs on the same order all stay (each pair is kept).
    """
    old_map = {_sku_key(old): new for old, new in replacements}
    kept: list = []
    changed: list[str] = []
    removed_discount = 0
    removed_other = 0
    for item in items:
        sku = str(item.get("sku") or "").strip()
        name = str(item.get("name") or "").strip()
        if _is_discount_or_empty_sku(sku, name):
            removed_discount += 1
            continue
        key = _sku_key(sku)
        if key not in old_map:
            removed_other += 1
            continue
        item.pop("orderItemId", None)
        new_sku = old_map[key]
        if key != _sku_key(new_sku):
            item["sku"] = new_sku
            changed.append(f"{sku} -> {new_sku}")
        kept.append(item)
    return kept, changed, removed_discount, removed_other


def expand_replacements(matches) -> tuple[list[tuple[str, str]], str | None]:
    """Turn Reminder rows (Old/New may be comma-lists) into Old->New pairs.

    Returns (pairs, error). Old and New counts must line up per row.
    """
    pairs: list[tuple[str, str]] = []
    for row in matches:
        olds = _split_skus(row.old_sku)
        news = _split_skus(row.new_sku)
        if not olds or not news:
            return [], f"Row {row.source_row}: Old/New SKU empty."
        if len(olds) != len(news):
            return [], (
                f"Row {row.source_row}: {len(olds)} Old SKU vs {len(news)} New SKU — "
                "counts must match (comma order = pair order)."
            )
        for old, new in zip(olds, news):
            pairs.append((old, new))
    return pairs, None


def run_api_apply(
    order: str,
    csv: str | None = None,
    ship_order: str | None = None,
    allow_rerun: bool = False,
    confirm: bool = False,
    clear_blank_carrier: bool = False,
    testing_only: bool = False,
    resend_value: str = "resend",
) -> int:
    """TESTING ONLY — rewrite the SKU on the original order in place.

    This is not the ops path. Live ops uses Option A (``apply-sku`` file →
    Zayn Manual import → one new resend order, original untouched).

    Nothing is deleted. Every other line, address and field is sent back exactly
    as ShipStation returned it, because V1 has no partial update.
    """
    logger = setup_logger()
    if not testing_only:
        logger.error(
            "In-place SKU rewrite is TESTING ONLY and overwrites the original order. "
            "Ops path is Option A: python run.py <order-id> then import the file. "
            "Pass --testing-only if you really mean to rewrite the original."
        )
        return 1
    if not confirm:
        logger.error("Refusing to write without --confirm. No API call made.")
        return 1
    logger.warning(
        "TESTING ONLY path: this overwrites the ORIGINAL order (no new resend order)."
    )

    csv_path = Path(csv) if csv else reminder_csv_path()
    rows = load_reminder_rows(csv_path)
    matches = find_by_order_id(rows, order)
    if not matches:
        logger.error("Order not found in Reminder CSV: %s. No API call made.", order)
        return 1

    replacements: list[tuple[str, str]] = []
    for row in matches:
        assessment = assess_sku_pair(row)
        if not assessment["use_as_sku"]:
            logger.error(
                "Reminder row %s is not ready. Fill Old SKU + New SKU. No API call made.",
                row.source_row,
            )
            return 2
        replacements.append((row.old_sku.strip(), row.new_sku.strip()))

    normalized_order = matches[-1].normalized_order_id
    prior = was_processed(normalized_order, action="api-replacement")
    if prior and not allow_rerun:
        logger.error(
            "BLOCKED: API replacement already recorded for %s at %s. "
            "Re-run can ship twice. Use --allow-rerun only if intentional.",
            normalized_order,
            prior.get("processed_at_utc"),
        )
        return 3

    ship_lookup = (ship_order or normalized_order).strip()
    try:
        client = ShipStationClient()
        live_order = client.get_exact_order(ship_lookup)
    except ShipStationError as exc:
        logger.error("%s", exc)
        return 4

    before = summarize_order(live_order)
    if before["status"] not in OPEN_STATUSES:
        logger.error(
            "Order status is %s (not open). Refusing to write. Nothing changed.",
            before["status"],
        )
        return 6

    payload = copy.deepcopy(live_order)
    items = payload.get("items")
    if not isinstance(items, list) or not items:
        logger.error("Live order has no item list. Nothing changed.")
        return 7

    changed: list[str] = []
    for old_sku, new_sku in replacements:
        hits = [item for item in items if _sku_key(item.get("sku")) == _sku_key(old_sku)]
        if not hits:
            logger.error(
                "Old SKU %s not found on the live order. Nothing changed.", old_sku
            )
            return 5
        if len(hits) > 1:
            logger.error(
                "Old SKU %s matches %d lines; ambiguous. Nothing changed.",
                old_sku,
                len(hits),
            )
            return 5
        if _sku_key(old_sku) == _sku_key(new_sku):
            logger.info("Old SKU = New SKU for %s; no SKU rewrite.", old_sku)
            continue
        hits[0]["sku"] = new_sku
        changed.append(f"{old_sku} -> {new_sku}")

    if len(items) != len(before["items"]):
        logger.error("Item count changed while building payload. Aborted, nothing sent.")
        return 7

    advanced = payload.get("advancedOptions")
    if not isinstance(advanced, dict):
        advanced = {}
    advanced["customField1"] = resend_value
    payload["advancedOptions"] = advanced

    # V1 rejects a carrier that has no service selected ("Invalid serviceCode").
    # Only an explicit flag may blank that carrier, and it is always logged.
    carrier_cleared = ""
    carrier_code = str(payload.get("carrierCode") or "").strip()
    service_code = str(payload.get("serviceCode") or "").strip()
    if carrier_code and not service_code:
        if not clear_blank_carrier:
            logger.error(
                "Order has carrierCode=%s with no serviceCode; ShipStation would reject "
                "the update. Re-run with --clear-blank-carrier to blank that carrier, "
                "or set a service in ShipStation first. Nothing changed.",
                carrier_code,
            )
            return 10
        payload["carrierCode"] = None
        payload["serviceCode"] = None
        carrier_cleared = carrier_code
        logger.warning(
            "Blanking carrierCode=%s (no service was set) so the update is accepted.",
            carrier_code,
        )

    proof_dir = output_dir()
    proof_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    proof_path = proof_dir / f"api-order-{normalized_order}-{stamp}.json"
    proof_path.write_text(
        json.dumps({"before": live_order, "sent": payload}, indent=2),
        encoding="utf-8",
    )

    try:
        client.update_order(payload)
        verify_order = client.get_exact_order(ship_lookup)
    except ShipStationError as exc:
        logger.error("%s", exc)
        logger.error("Check ShipStation manually before any re-run. Proof: %s", proof_path)
        return 8

    after = summarize_order(verify_order)
    after_skus = [item["sku"] for item in after["items"]]
    expected_new = [new for old, new in replacements if _sku_key(old) != _sku_key(new)]
    missing_new = [
        sku for sku in expected_new if _sku_key(sku) not in {_sku_key(s) for s in after_skus}
    ]
    lines_ok = len(after["items"]) == len(before["items"])
    field_ok = _sku_key(after["custom_field_1"]) == _sku_key(resend_value)
    verified = not missing_new and lines_ok and field_ok

    report = [
        "Phase 1 ShipStation API apply (WRITE)",
        f"Reminder Order ID: {normalized_order}",
        f"ShipStation exact lookup: {ship_lookup}",
        f"ShipStation Order Number: {after['order_number']}",
        f"ShipStation internal Order ID: {after['order_id']}",
        f"Status: {after['status']}",
        f"SKU change(s) applied: {changed or '(none — Old SKU = New SKU)'}",
        f"Custom Field 1 before: {before['custom_field_1'] or '(empty)'}",
        f"Custom Field 1 after: {after['custom_field_1'] or '(empty)'}",
        f"Line count before/after: {len(before['items'])} / {len(after['items'])}",
        "Lines deleted: 0 (delete is never performed)",
        f"Carrier blanked (no service was set): {carrier_cleared or '(no)'}",
        f"Verified after re-read: {verified}",
        f"API calls used: {client.calls_made}",
        (
            "Rate limit: "
            f"limit={client.rate_limit.limit}, "
            f"remaining={client.rate_limit.remaining}, "
            f"reset_seconds={client.rate_limit.reset_seconds}"
        ),
        f"Local proof file: {proof_path}",
        "Live MS sheet: NOT modified",
    ]
    for index, item in enumerate(after["items"], start=1):
        report.append(
            f"Line {index}: sku={item['sku']!r}, qty={item['quantity']!r}, "
            f"name={item['name']!r}"
        )

    for line in report:
        logger.info("%s", line)
    report_path = write_run_report(report, prefix="api-apply")
    logger.info("Report saved: %s", report_path)

    if not verified:
        logger.error(
            "Write sent but verification failed (missing_new=%s, lines_ok=%s, field_ok=%s). "
            "Check ShipStation manually; not marked as processed.",
            missing_new,
            lines_ok,
            field_ok,
        )
        return 9

    ledger = mark_processed(
        normalized_order,
        action="api-replacement",
        sku_text="; ".join(changed) if changed else "same_no_rewrite",
        output_file=str(proof_path),
        note="rerun" if prior else "",
    )
    logger.info("Processed ledger: %s", ledger)
    print(f"\nDone. ShipStation order updated and verified. Report: {report_path}")
    return 0


def run_api_create_resend(
    order: str,
    csv: str | None = None,
    ship_order: str | None = None,
    allow_rerun: bool = False,
    confirm: bool = False,
    resend_value: str = "resend",
) -> int:
    """Option A via API: keep the original order, create ONE new resend order.

    The new order copies the original (same order number, customer, address),
    moves to the Manual store, changes only the matched line SKUs (Old -> New),
    sets Custom Field 1 = resend, and uses a fresh orderKey so the original is
    never overwritten. Without --confirm this is a read-only preview.
    """
    logger = setup_logger()
    csv_path = Path(csv) if csv else reminder_csv_path()
    rows = load_reminder_rows(csv_path)
    matches = find_by_order_id(rows, order)
    if not matches:
        logger.error("Order not found in Reminder CSV: %s. No API call made.", order)
        return 1

    replacements, err = expand_replacements(matches)
    if err:
        logger.error("%s No API call made.", err)
        return 2

    normalized_order = matches[-1].normalized_order_id
    prior = was_processed(normalized_order, action="api-resend")
    if prior and not allow_rerun:
        logger.error(
            "BLOCKED: resend already recorded for %s at %s. "
            "Re-run can ship twice. Use --allow-rerun only if intentional. No API call made.",
            normalized_order,
            prior.get("processed_at_utc"),
        )
        return 3

    ship_lookup = (ship_order or normalized_order).strip()
    try:
        client = ShipStationClient()
        original, match_mode = resolve_original_for_resend(
            client, ship_lookup, replacements, resend_value
        )
        related = client.search_orders_related_to_number(ship_lookup)
    except ShipStationError as exc:
        logger.error("%s", exc)
        return 4

    existing_resends = sum(1 for o in related if _is_resend_order(o, resend_value))
    if existing_resends > 0:
        logger.warning(
            "%d resend order(s) already exist for this lookup; original identified as %s.",
            existing_resends,
            original.get("orderId"),
        )

    before = summarize_order(original)
    # Resend copies the original into a NEW order, so the original's status does
    # not matter — real replacements are usually for already-shipped orders.
    if before["status"] not in OPEN_STATUSES:
        logger.info(
            "Original status is %s; that is fine — we only read it and build a NEW order.",
            before["status"],
        )

    original_key = str(original.get("orderKey") or "").strip()
    original_store = (original.get("advancedOptions") or {}).get("storeId")

    # Match every Old SKU on the live order (exactly once each).
    live_items = original.get("items") or []
    for old_sku, _new in replacements:
        hits = [it for it in live_items if _sku_key(it.get("sku")) == _sku_key(old_sku)]
        if len(hits) != 1:
            logger.error(
                "Old SKU %s matched %d live lines (need exactly 1). Nothing changed.",
                old_sku,
                len(hits),
            )
            return 5

    # Find the Manual store (env override wins).
    manual_store_id: object = shipstation_manual_store_id() or None
    manual_store_name = ""
    try:
        if manual_store_id:
            manual_store_id = int(str(manual_store_id))
        else:
            store = client.find_manual_store()
            if store:
                manual_store_id = store.get("storeId")
                manual_store_name = str(store.get("storeName") or "")
    except ShipStationError as exc:
        logger.error("Could not read stores: %s", exc)
        return 7
    if not manual_store_id:
        logger.error(
            "Manual store not found. Set SHIPSTATION_MANUAL_STORE_ID in .env. Nothing changed."
        )
        return 7

    # Build the NEW order payload from the original.
    payload = copy.deepcopy(original)
    payload.pop("orderId", None)
    new_key = f"resend-{normalized_order}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
    payload["orderKey"] = new_key

    # A resend must start fresh: never inherit the original's shipped state.
    payload["orderStatus"] = "awaiting_shipment"
    for stale in ("shipDate", "holdUntilDate"):
        payload[stale] = None
    payload.pop("shipByDate", None)

    # Drop the original's tags (e.g. shift / 1017). New order gets 1014 only.
    dropped_tags = payload.get("tagIds") or []
    all_resend_tag = shipstation_tag_all_resend()
    payload["tagIds"] = [all_resend_tag]

    kept_items, changed, removed_discount, removed_other = select_resend_items(
        payload.get("items") or [], replacements
    )
    if not kept_items:
        logger.error(
            "No matching product lines left after dropping discount/other. Nothing changed."
        )
        return 5
    payload["items"] = kept_items

    advanced = payload.get("advancedOptions")
    if not isinstance(advanced, dict):
        advanced = {}
    advanced["customField1"] = resend_value
    advanced["storeId"] = manual_store_id
    payload["advancedOptions"] = advanced

    # A new order copying a carrier with no service would 400; blanking it only
    # affects the NEW resend order, never the original.
    carrier_cleared = ""
    if str(payload.get("carrierCode") or "").strip() and not str(
        payload.get("serviceCode") or ""
    ).strip():
        carrier_cleared = str(payload.get("carrierCode"))
        payload["carrierCode"] = None
        payload["serviceCode"] = None

    proof_dir = output_dir()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    proof_path = proof_dir / f"api-resend-{normalized_order}-{stamp}.json"
    proof_path.write_text(
        json.dumps({"original": original, "new_order_sent": payload}, indent=2),
        encoding="utf-8",
    )

    preview = [
        "Option A API resend (create NEW order; original untouched)",
        f"Mode: {'WRITE' if confirm else 'DRY-RUN (read only)'}",
        f"Reminder Order ID: {normalized_order}",
        f"ShipStation exact lookup: {ship_lookup}",
        f"Original locate mode: {match_mode}",
        f"Original Order Number: {before['order_number']}",
        f"Original internal Order ID: {before['order_id']}",
        f"Original store id: {original_store}",
        f"Original orderKey: {original_key}",
        f"New order store id (Manual): {manual_store_id} {manual_store_name}".rstrip(),
        f"New orderKey: {new_key}",
        f"New order status: {payload['orderStatus']} (never inherits shipped)",
        f"Original tags dropped on new order: {dropped_tags or '(none)'}",
        f"New order tagIds: {[all_resend_tag]} (1014 ALL-RESEND)",
        f"SKU change(s): {changed or '(none — Old = New)'}",
        f"Custom Field 1 on new order: {resend_value}",
        f"Carrier blanked on new order: {carrier_cleared or '(no)'}",
        (
            f"Line count on new order: {len(payload.get('items') or [])} "
            f"(dropped discount/empty={removed_discount}, other={removed_other})"
        ),
        f"API calls used so far: {client.calls_made}",
        f"Local proof file: {proof_path}",
        "Original order: NOT modified",
        "Live MS sheet: NOT modified",
    ]

    if not confirm:
        for line in preview:
            logger.info("%s", line)
        report_path = write_run_report(preview, prefix="api-resend-dryrun")
        logger.info("Report saved: %s", report_path)
        logger.info("DRY-RUN only. Re-run with --confirm to create the new resend order.")
        return 0

    try:
        client.create_new_order(payload, original_key)
        after_orders = client.search_by_order_number(ship_lookup)
    except ShipStationError as exc:
        logger.error("%s", exc)
        logger.error("Check ShipStation manually before any re-run. Proof: %s", proof_path)
        return 8

    original_after = next(
        (o for o in after_orders if str(o.get("orderKey") or "") == original_key), None
    )
    new_after = next(
        (o for o in after_orders if str(o.get("orderKey") or "") == new_key), None
    )
    original_ok = False
    if original_after:
        orig_skus = {_sku_key(i.get("sku")) for i in (original_after.get("items") or [])}
        expected_orig = {_sku_key(old) for old, _n in replacements}
        original_ok = expected_orig.issubset(orig_skus)
    new_ok = False
    new_status = ""
    new_cf1 = ""
    if new_after:
        new_skus = {_sku_key(i.get("sku")) for i in (new_after.get("items") or [])}
        expected_new = {_sku_key(n) for o, n in replacements if _sku_key(o) != _sku_key(n)}
        new_cf1 = str((new_after.get("advancedOptions") or {}).get("customField1") or "")
        new_status = str(new_after.get("orderStatus") or "")
        new_ok = (
            expected_new.issubset(new_skus)
            and _sku_key(new_cf1) == _sku_key(resend_value)
            and new_status == "awaiting_shipment"
        )
    verified = bool(original_after and new_after and original_ok and new_ok)

    report = list(preview)
    report[1] = "Mode: WRITE (done)"
    report += [
        f"Orders now with this number: {len(after_orders)}",
        f"Original still present & unchanged: {original_ok}",
        f"New order status (read back): {new_status or '(not found)'}",
        f"New order Custom Field 1 (read back): {new_cf1 or '(empty)'}",
        f"New resend present & correct: {new_ok}",
        f"Verified: {verified}",
        f"API calls used: {client.calls_made}",
    ]
    for line in report:
        logger.info("%s", line)
    report_path = write_run_report(report, prefix="api-resend")
    logger.info("Report saved: %s", report_path)

    if not verified:
        logger.error(
            "Create sent but verification incomplete (original_ok=%s, new_ok=%s, count=%d). "
            "Check ShipStation manually; not marked processed.",
            original_ok,
            new_ok,
            len(after_orders),
        )
        return 9

    ledger = mark_processed(
        normalized_order,
        action="api-resend",
        sku_text="; ".join(changed) if changed else "same_no_rewrite",
        output_file=str(proof_path),
        note="rerun" if prior else "",
    )
    logger.info("Processed ledger: %s", ledger)
    print(f"\nDone. New resend order created; original untouched. Report: {report_path}")
    return 0


def parse_bulk_order_ids(raw: str) -> list[str]:
    """Split comma / space / semicolon Order IDs; keep order, drop empties."""
    parts: list[str] = []
    for chunk in str(raw or "").replace(";", ",").split(","):
        parts.extend(chunk.split())
    cleaned: list[str] = []
    seen: set[str] = set()
    for part in parts:
        oid = part.strip().lstrip("#").strip()
        if not oid:
            continue
        key = oid.lower()
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(oid)
    return cleaned


def run_api_bulk_resend(
    orders_raw: str,
    csv: str | None = None,
    allow_rerun: bool = False,
    confirm: bool = False,
    resend_value: str = "resend",
) -> int:
    """Bulk Option A: clean 1017 leftovers → tag today's originals → create each resend.

    You run this from the BAT (preview, then type CREATE). Script never invents
    Order IDs — only the list you paste (2–5).
    """
    logger = setup_logger()
    order_ids = parse_bulk_order_ids(orders_raw)
    if len(order_ids) < 2 or len(order_ids) > 5:
        logger.error(
            "Bulk needs 2-5 Order IDs (got %d). Use Single menu for one order. No API call made.",
            len(order_ids),
        )
        return 1

    csv_path = Path(csv) if csv else reminder_csv_path()
    rows = load_reminder_rows(csv_path)
    tag_1017 = shipstation_tag_bulk_making()
    tag_1014 = shipstation_tag_all_resend()

    plans: list[dict] = []
    for oid in order_ids:
        matches = find_by_order_id(rows, oid)
        if not matches:
            logger.error("Order not found in Reminder CSV: %s. Stopped; no writes.", oid)
            return 1
        replacements, err = expand_replacements(matches)
        if err:
            logger.error("%s (%s). Stopped; no writes.", err, oid)
            return 2
        normalized = matches[-1].normalized_order_id
        prior = was_processed(normalized, action="api-resend")
        if prior and not allow_rerun:
            logger.error(
                "BLOCKED: resend already recorded for %s at %s. "
                "Use --allow-rerun only if intentional. No writes.",
                normalized,
                prior.get("processed_at_utc"),
            )
            return 3
        plans.append(
            {
                "input": oid,
                "normalized": normalized,
                "replacements": replacements,
                "prior": prior,
            }
        )

    try:
        client = ShipStationClient(max_calls=shipstation_bulk_max_calls())
        leftovers = client.list_all_orders_by_tag(tag_1017, "shipped")
    except ShipStationError as exc:
        logger.error("%s", exc)
        return 4

    leftover_lines = []
    for order in leftovers:
        leftover_lines.append(
            f"  - {order.get('orderNumber')} (internal {order.get('orderId')}, "
            f"status={order.get('orderStatus')})"
        )

    # Resolve Manual store once for the whole bulk run.
    manual_store_id: object = shipstation_manual_store_id() or None
    manual_store_name = ""
    try:
        if manual_store_id:
            manual_store_id = int(str(manual_store_id))
        else:
            store = client.find_manual_store()
            if store:
                manual_store_id = store.get("storeId")
                manual_store_name = str(store.get("storeName") or "")
    except ShipStationError as exc:
        logger.error("Could not read stores: %s", exc)
        return 7
    if not manual_store_id:
        logger.error(
            "Manual store not found. Set SHIPSTATION_MANUAL_STORE_ID in .env. Nothing changed."
        )
        return 7

    per_order_preview: list[str] = []
    prepared: list[dict] = []
    for plan in plans:
        ship_lookup = plan["normalized"]
        try:
            original, match_mode = resolve_original_for_resend(
                client, ship_lookup, plan["replacements"], resend_value
            )
        except ShipStationError as exc:
            logger.error("%s (%s)", exc, ship_lookup)
            return 4

        before = summarize_order(original)
        live_items = original.get("items") or []
        for old_sku, _new in plan["replacements"]:
            hits = [it for it in live_items if _sku_key(it.get("sku")) == _sku_key(old_sku)]
            if len(hits) != 1:
                logger.error(
                    "Order %s: Old SKU %s matched %d live lines (need exactly 1). Stopped.",
                    plan["normalized"],
                    old_sku,
                    len(hits),
                )
                return 5

        payload = copy.deepcopy(original)
        payload.pop("orderId", None)
        new_key = (
            f"resend-{plan['normalized']}-"
            f"{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        )
        payload["orderKey"] = new_key
        payload["orderStatus"] = "awaiting_shipment"
        for stale in ("shipDate", "holdUntilDate"):
            payload[stale] = None
        payload.pop("shipByDate", None)
        dropped_tags = payload.get("tagIds") or []
        payload["tagIds"] = [tag_1014]

        kept_items, changed, removed_discount, removed_other = select_resend_items(
            payload.get("items") or [], plan["replacements"]
        )
        if not kept_items:
            logger.error(
                "Order %s: no matching product lines after drop. Stopped.",
                plan["normalized"],
            )
            return 5
        payload["items"] = kept_items

        advanced = payload.get("advancedOptions")
        if not isinstance(advanced, dict):
            advanced = {}
        advanced["customField1"] = resend_value
        advanced["storeId"] = manual_store_id
        payload["advancedOptions"] = advanced

        if str(payload.get("carrierCode") or "").strip() and not str(
            payload.get("serviceCode") or ""
        ).strip():
            payload["carrierCode"] = None
            payload["serviceCode"] = None

        original_key = str(original.get("orderKey") or "").strip()
        original_id = original.get("orderId")
        per_order_preview.append(
            f"--- {plan['normalized']} --- locate={match_mode} | "
            f"orig internal={before['order_id']} status={before['status']} | "
            f"SKU {changed or '(same)'} | drop disc={removed_discount} other={removed_other} | "
            f"new tag={tag_1014} cf1={resend_value}"
        )
        prepared.append(
            {
                **plan,
                "original": original,
                "original_key": original_key,
                "original_id": original_id,
                "payload": payload,
                "new_key": new_key,
                "changed": changed,
                "dropped_tags": dropped_tags,
                "existing_resends": 0,
            }
        )

    preview = [
        "BULK Option A API resend",
        f"Mode: {'WRITE' if confirm else 'DRY-RUN (read only)'}",
        f"Today's Order IDs ({len(prepared)}): "
        + ", ".join(p["normalized"] for p in prepared),
        f"Tag {tag_1017} on shipped (leftovers to clean): {len(leftovers)}",
        *(leftover_lines or ["  - (none)"]),
        f"Plan: remove ONLY tag {tag_1017} from leftovers (never delete orders / other tags)",
        f"Plan: add tag {tag_1017} on today's originals so they appear in that filter",
        f"Plan: create ONE new Manual resend each (tag {tag_1014} + Custom Field 1={resend_value})",
        f"Manual store id: {manual_store_id} {manual_store_name}".rstrip(),
        f"API calls so far: {client.calls_made}",
        "Live MS sheet: NOT modified",
        "",
        *per_order_preview,
    ]
    for line in preview:
        logger.info("%s", line)

    if not confirm:
        report_path = write_run_report(preview, prefix="api-bulk-resend-dryrun")
        logger.info("Report saved: %s", report_path)
        logger.info("DRY-RUN only. Re-run with --confirm to apply tags + create resends.")
        return 0

    # --- WRITE: clean leftovers ---
    removed_ok = 0
    for order in leftovers:
        oid = order.get("orderId")
        if oid is None:
            logger.error("Leftover order missing orderId; stopped mid-clean.")
            return 8
        try:
            client.remove_tag(int(oid), tag_1017)
            removed_ok += 1
            logger.info(
                "Removed tag %s from leftover %s (internal %s)",
                tag_1017,
                order.get("orderNumber"),
                oid,
            )
        except ShipStationError as exc:
            logger.error(
                "Failed removing tag %s from %s: %s. Stopped; check ShipStation.",
                tag_1017,
                order.get("orderNumber"),
                exc,
            )
            return 8

    # --- WRITE: tag today's originals + create ---
    results: list[str] = [
        f"Removed tag {tag_1017} from {removed_ok} leftover shipped order(s)",
    ]
    failures = 0
    for item in prepared:
        oid = item["original_id"]
        if oid is None:
            logger.error("Original missing orderId for %s; skipped.", item["normalized"])
            failures += 1
            continue
        try:
            client.add_tag(int(oid), tag_1017)
            logger.info(
                "Added tag %s on today's original %s (internal %s)",
                tag_1017,
                item["normalized"],
                oid,
            )
        except ShipStationError as exc:
            logger.error(
                "Failed adding tag %s on %s: %s. Skipping create for this order.",
                tag_1017,
                item["normalized"],
                exc,
            )
            failures += 1
            results.append(f"{item['normalized']}: FAIL add-tag — {exc}")
            continue

        # Fresh key at write time so bulk same-second creates never collide.
        new_key = (
            f"resend-{item['normalized']}-"
            f"{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}"
        )
        item["payload"]["orderKey"] = new_key
        item["new_key"] = new_key

        proof_dir = output_dir()
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        proof_path = proof_dir / f"api-bulk-resend-{item['normalized']}-{stamp}.json"
        proof_path.write_text(
            json.dumps(
                {"original": item["original"], "new_order_sent": item["payload"]},
                indent=2,
            ),
            encoding="utf-8",
        )

        try:
            client.create_new_order(item["payload"], item["original_key"])
            after_orders = client.search_by_order_number(item["normalized"])
        except ShipStationError as exc:
            logger.error(
                "Create failed for %s: %s. Check ShipStation before re-run. Proof: %s",
                item["normalized"],
                exc,
                proof_path,
            )
            failures += 1
            results.append(f"{item['normalized']}: FAIL create — {exc}")
            continue

        original_after = next(
            (
                o
                for o in after_orders
                if str(o.get("orderKey") or "") == item["original_key"]
            ),
            None,
        )
        new_after = next(
            (o for o in after_orders if str(o.get("orderKey") or "") == item["new_key"]),
            None,
        )
        original_ok = False
        if original_after:
            orig_skus = {
                _sku_key(i.get("sku")) for i in (original_after.get("items") or [])
            }
            expected_orig = {_sku_key(old) for old, _n in item["replacements"]}
            original_ok = expected_orig.issubset(orig_skus)
        new_ok = False
        new_status = ""
        new_cf1 = ""
        if new_after:
            new_skus = {_sku_key(i.get("sku")) for i in (new_after.get("items") or [])}
            expected_new = {
                _sku_key(n)
                for o, n in item["replacements"]
                if _sku_key(o) != _sku_key(n)
            }
            new_cf1 = str(
                (new_after.get("advancedOptions") or {}).get("customField1") or ""
            )
            new_status = str(new_after.get("orderStatus") or "")
            new_ok = (
                expected_new.issubset(new_skus)
                and _sku_key(new_cf1) == _sku_key(resend_value)
                and new_status == "awaiting_shipment"
            )
        verified = bool(original_after and new_after and original_ok and new_ok)
        if not verified:
            failures += 1
            results.append(
                f"{item['normalized']}: created but verify incomplete "
                f"(orig_ok={original_ok}, new_ok={new_ok}, count={len(after_orders)})"
            )
            logger.error(
                "Verify incomplete for %s; not marked processed. Proof: %s",
                item["normalized"],
                proof_path,
            )
            continue

        mark_processed(
            item["normalized"],
            action="api-resend",
            sku_text="; ".join(item["changed"]) if item["changed"] else "same_no_rewrite",
            output_file=str(proof_path),
            note="bulk" + (";rerun" if item["prior"] else ""),
        )
        results.append(
            f"{item['normalized']}: OK — new resend + tag {tag_1014}; original untouched"
        )
        logger.info("OK bulk resend for %s", item["normalized"])

    report = list(preview)
    report[1] = "Mode: WRITE (done)"
    report += ["", "Results:", *results, f"API calls used: {client.calls_made}"]
    for line in results:
        logger.info("%s", line)
    logger.info("API calls used: %s", client.calls_made)
    report_path = write_run_report(report, prefix="api-bulk-resend")
    logger.info("Report saved: %s", report_path)

    if failures:
        print(
            f"\nBulk finished with {failures} failure(s). "
            f"Check ShipStation + report: {report_path}"
        )
        return 9

    print(f"\nDone. Bulk resends created; originals untouched. Report: {report_path}")
    return 0


def run_build_queue(
    date_from: str,
    date_to: str | None = None,
    csv: str | None = None,
    queue: str | None = None,
) -> int:
    """Read Reminder export → filter date + Ready + not Done → write queue CSV."""
    logger = setup_logger()
    try:
        start = parse_user_date(date_from)
        end = parse_user_date(date_to or date_from)
    except ValueError as exc:
        logger.error("%s", exc)
        return 1
    if end < start:
        logger.error("End date is before start date. Nothing written.")
        return 1

    csv_path = Path(csv) if csv else reminder_csv_path()
    queue_path = Path(queue) if queue else replacement_queue_path()
    try:
        all_rows = load_reminder_rows(csv_path)
    except (FileNotFoundError, ValueError) as exc:
        logger.error("%s", exc)
        return 1

    selected = filter_queue_rows(all_rows, start, end)
    write_queue_csv(selected, queue_path)

    preview = [
        "Build replacement queue (file only — no ShipStation writes)",
        f"Reminder export: {csv_path}",
        f"Date range: {start.strftime('%d/%m/%Y')} to {end.strftime('%d/%m/%Y')}",
        "Filter: Ready to make = Ready, STATUS not Done, Order ID + Old/New SKU filled",
        f"Queue file written: {queue_path}",
        f"Orders in queue: {len(selected)}",
        "Live MS sheet: NOT modified",
        "",
    ]
    if not selected:
        preview.append("No matching Ready rows for this date range.")
    else:
        for row in selected:
            sku_note = (
                f"{row.old_sku} -> {row.new_sku}"
                if row.old_sku.strip().lower() != row.new_sku.strip().lower()
                else f"{row.old_sku} (same)"
            )
            preview.append(
                f"  - {row.normalized_order_id} | {row.insert_date} | {sku_note}"
            )

    for line in preview:
        logger.info("%s", line)
    report_path = write_run_report(preview, prefix="build-queue")
    logger.info("Report saved: %s", report_path)
    if not selected:
        return 2
    logger.info("Queue ready. Review the file, then run with CREATE to build resends.")
    return 0


def run_queue_resend(
    queue: str | None = None,
    allow_rerun: bool = False,
    confirm: bool = False,
) -> int:
    """Process every order in the queue file (API resend, no 1017 tags)."""
    logger = setup_logger()
    queue_path = Path(queue) if queue else replacement_queue_path()
    if not queue_path.exists():
        logger.error("Queue file not found: %s. Run build-queue first.", queue_path)
        return 1

    rows = load_reminder_rows(queue_path)
    if not rows:
        logger.error("Queue file is empty: %s", queue_path)
        return 2

    preview = [
        "Queue resend (API — new Manual order each; original untouched)",
        f"Mode: {'WRITE' if confirm else 'DRY-RUN (read only)'}",
        f"Queue file: {queue_path}",
        f"Orders: {len(rows)}",
        "No tag 1017 / no bulk leftover cleanup",
        f"New order tag: {shipstation_tag_all_resend()} (1014 ALL-RESEND)",
        "Live MS sheet: NOT modified",
        "",
    ]
    blocked = 0
    for row in rows:
        prior = was_processed(row.normalized_order_id, action="api-resend")
        if prior and not allow_rerun:
            preview.append(
                f"  - {row.normalized_order_id}: BLOCKED (ledger {prior.get('processed_at_utc')})"
            )
            blocked += 1
        else:
            preview.append(
                f"  - {row.normalized_order_id}: {row.old_sku} -> {row.new_sku}"
            )

    for line in preview:
        logger.info("%s", line)

    if not confirm:
        report_path = write_run_report(preview, prefix="queue-resend-dryrun")
        logger.info("Report saved: %s", report_path)
        logger.info("DRY-RUN only. Re-run with --confirm after you type CREATE in the BAT.")
        return 0

    if blocked and not allow_rerun:
        logger.error(
            "%d order(s) blocked by ledger. Fix queue or use --allow-rerun if intentional.",
            blocked,
        )
        return 3

    failures = 0
    results: list[str] = []
    for row in rows:
        code = run_api_create_resend(
            order=row.normalized_order_id,
            csv=str(queue_path),
            allow_rerun=allow_rerun,
            confirm=True,
        )
        if code == 0:
            results.append(f"{row.normalized_order_id}: OK")
        else:
            failures += 1
            results.append(f"{row.normalized_order_id}: FAIL (exit {code})")

    report = list(preview)
    report[1] = "Mode: WRITE (done)"
    report += ["", "Results:", *results]
    report_path = write_run_report(report, prefix="queue-resend")
    logger.info("Report saved: %s", report_path)
    for line in results:
        logger.info("%s", line)

    if failures:
        print(f"\nFinished with {failures} failure(s). Report: {report_path}")
        return 9
    print(f"\nDone. {len(rows)} resend(s) from queue. Report: {report_path}")
    return 0


def run_apply_sku(
    order: str,
    export: str | None,
    csv: str | None = None,
    old_sku: str | None = None,
    new_sku: str | None = None,
    force: bool = False,
    allow_rerun: bool = False,
    resend_value: str = "resend",
) -> int:
    """Build the Option A import file: original order stays untouched, and this
    file is what ShipStation imports as the one new resend order."""
    logger = setup_logger()
    csv_path = Path(csv) if csv else reminder_csv_path()

    try:
        export_path = find_export_for_order(order, explicit=export)
    except FileNotFoundError as exc:
        logger.error("%s", exc)
        return 1

    logger.info("Using export: %s", export_path)

    rows = load_reminder_rows(csv_path)
    matches = find_by_order_id(rows, order)
    if not matches:
        logger.error("Order not found in reminder CSV: %s", order)
        return 1

    replacements: list[tuple[str, str]] = []
    for row in matches:
        assessment = assess_sku_pair(row)
        o = old_sku.strip() if old_sku else row.old_sku.strip()
        n = new_sku.strip() if new_sku else row.new_sku.strip()
        if old_sku or new_sku:
            if not o or not n:
                logger.error("Both --old-sku and --new-sku are required when overriding")
                return 1
            replacements = [(o, n)]
            break
        if assessment["use_as_sku"]:
            replacements.append((o, n))
        elif not force:
            logger.error(
                "Row %s not ready (clarity=%s). Fill Old SKU + New SKU.",
                row.source_row,
                assessment["clarity"],
            )
            for flag in assessment["flags"]:
                logger.error("  %s", flag)
            return 2

    if not replacements:
        logger.error("No Old SKU / New SKU pairs ready for order %s", order)
        return 1

    primary = matches[-1]
    prior = was_processed(primary.normalized_order_id, action="apply-sku")
    if prior and not allow_rerun:
        logger.error(
            "BLOCKED: order %s already processed at %s (sku=%s). "
            "Re-run can ship twice. Use --allow-rerun only if intentional.",
            primary.normalized_order_id,
            prior.get("processed_at_utc"),
            prior.get("sku_text"),
        )
        return 3

    out_name = f"shipstation-sku-{primary.normalized_order_id.replace('/', '_')}.csv"
    output_path = output_dir() / out_name

    try:
        result = apply_sku_change(
            export_csv=export_path,
            new_sku=replacements[0][1],
            output_csv=output_path,
            order_id=primary.normalized_order_id,
            replacements=replacements,
            custom_field1_value=resend_value,
        )
    except PermissionError:
        from datetime import datetime, timezone

        stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        output_path = output_dir() / (
            f"shipstation-sku-{primary.normalized_order_id.replace('/', '_')}-{stamp}.csv"
        )
        logger.warning(
            "Output file locked (close Excel if open). Writing instead to: %s",
            output_path,
        )
        try:
            result = apply_sku_change(
                export_csv=export_path,
                new_sku=replacements[0][1],
                output_csv=output_path,
                order_id=primary.normalized_order_id,
                replacements=replacements,
                custom_field1_value=resend_value,
            )
        except ValueError as exc:
            logger.error("%s", exc)
            return 4
    except ValueError as exc:
        logger.error("%s", exc)
        return 4

    ledger_sku = "; ".join(f"{o}->{n}" for o, n in replacements)
    ledger = mark_processed(
        order_id=primary.normalized_order_id,
        action="apply-sku",
        sku_text=ledger_sku,
        output_file=result["output"],
        note="rerun" if prior else "",
    )

    modes = []
    for o, n in replacements:
        modes.append("same_no_rewrite" if o.lower() == n.lower() else "rewrite")

    report = [
        "Option A import file (original order stays untouched)",
        f"Order ID: {primary.order_id}",
        f"Replacements: {replacements}",
        f"SKU mode(s): {modes}",
        f"Input export: {export_path}",
        f"Output file: {result['output']}",
        f"SKU column: {result['sku_column']}",
        f"Custom Field 1 column: {result['custom_field1_column'] or '(not in export)'}",
        (
            f"Custom Field 1 value: {result['custom_field1_value'] or '(none)'} "
            f"on {result['custom_field1_rows']} row(s)"
        ),
        f"Rows kept/changed: {result['rows_changed']} (from {result['rows_total']})",
        f"Removed discount/empty (file only): {result['removed_discount']}",
        f"Removed other lines (file only): {result['removed_other']}",
        f"Old SKUs matched: {result['old_skus']}",
        f"Processed ledger: {ledger}",
        "Original ShipStation order: NOT modified",
        "Live MS sheet: NOT modified",
        "Next: import this file with Zayn Manual mapping -> creates ONE new resend order",
    ]
    if resend_value and not result["custom_field1_column"]:
        logger.warning(
            "Export has no Custom - Field 1 column, so %r could not be written. "
            "Set it in ShipStation via Bulk Update after import.",
            resend_value,
        )
    report_path = write_run_report(report, prefix="apply-sku")
    for line in report:
        logger.info("%s", line)
    print(f"\nDone. Changed file: {result['output']}")
    print(f"Report: {report_path}")
    return 0


def cmd_dry_run(args: argparse.Namespace) -> int:
    return run_dry_run(order=args.order, last=args.last, csv=args.csv)


def cmd_apply_sku(args: argparse.Namespace) -> int:
    return run_apply_sku(
        order=args.order,
        export=args.export,
        csv=args.csv,
        old_sku=args.old_sku,
        new_sku=args.new_sku,
        force=args.force,
        allow_rerun=args.allow_rerun,
    )


def cmd_api_check(args: argparse.Namespace) -> int:
    return run_api_dry_run(order=args.order, csv=args.csv, ship_order=args.ship_order)


def cmd_api_apply(args: argparse.Namespace) -> int:
    return run_api_apply(
        order=args.order,
        csv=args.csv,
        ship_order=args.ship_order,
        allow_rerun=args.allow_rerun,
        confirm=args.confirm,
        clear_blank_carrier=args.clear_blank_carrier,
        testing_only=args.testing_only,
    )


def cmd_api_resend(args: argparse.Namespace) -> int:
    return run_api_create_resend(
        order=args.order,
        csv=args.csv,
        ship_order=args.ship_order,
        allow_rerun=args.allow_rerun,
        confirm=args.confirm,
    )


def cmd_api_bulk_resend(args: argparse.Namespace) -> int:
    return run_api_bulk_resend(
        orders_raw=args.orders,
        csv=args.csv,
        allow_rerun=args.allow_rerun,
        confirm=args.confirm,
    )


def cmd_build_queue(args: argparse.Namespace) -> int:
    return run_build_queue(
        date_from=args.date,
        date_to=args.date_to,
        csv=args.csv,
        queue=args.queue,
    )


def cmd_queue_resend(args: argparse.Namespace) -> int:
    return run_queue_resend(
        queue=args.queue,
        allow_rerun=args.allow_rerun,
        confirm=args.confirm,
    )


def cmd_short(order_id: str, argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog=f"python run.py {order_id}",
        description="Short form: dry-run or apply-sku with auto export lookup.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only preview Reminder Old/New (+ which export would be used)",
    )
    parser.add_argument(
        "--api-dry-run",
        action="store_true",
        help="Read exact live ShipStation order and validate Old SKU; never write",
    )
    parser.add_argument(
        "--api-resend",
        action="store_true",
        help="Option A via API: preview (or with --confirm create) a new resend order",
    )
    parser.add_argument("--export", help="Optional explicit Zayn export path")
    parser.add_argument("--csv", help="Optional Reminder CSV path")
    parser.add_argument(
        "--ship-order",
        help="Exact ShipStation order number if it differs from the Reminder id",
    )
    parser.add_argument("--allow-rerun", action="store_true", help="Allow ledger re-run")
    parser.add_argument(
        "--confirm", action="store_true", help="With --api-resend: actually create the order"
    )
    args = parser.parse_args(argv)

    chosen = [f for f in (args.dry_run, args.api_dry_run, args.api_resend) if f]
    if len(chosen) > 1:
        parser.error("Choose only one of --dry-run / --api-dry-run / --api-resend")
    if args.api_resend:
        return run_api_create_resend(
            order=order_id,
            csv=args.csv,
            ship_order=args.ship_order,
            allow_rerun=args.allow_rerun,
            confirm=args.confirm,
        )
    if args.api_dry_run:
        return run_api_dry_run(order=order_id, csv=args.csv, ship_order=args.ship_order)
    if args.dry_run:
        return run_dry_run(order=order_id, last=1, csv=args.csv)
    return run_apply_sku(
        order=order_id,
        export=args.export,
        csv=args.csv,
        allow_rerun=args.allow_rerun,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Replacement Phase 0 — Old SKU → New SKU on Zayn Manual export."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    dry = sub.add_parser("dry-run", help="Preview Order ID + Old/New SKU (logs only)")
    dry.add_argument("--order", help="Single order id from Reminder sheet")
    dry.add_argument("--last", type=int, default=3, help="If no --order, show last N rows")
    dry.add_argument("--csv", help="Path to Reminder CSV export")
    dry.set_defaults(func=cmd_dry_run)

    apply = sub.add_parser(
        "apply-sku",
        help="Match Old SKU in Zayn export, set New SKU, drop discount/other lines",
    )
    apply.add_argument("--order", required=True, help="Order id from Reminder sheet")
    apply.add_argument(
        "--export",
        help="Zayn export CSV (optional — auto-finds in data/input or data/samples)",
    )
    apply.add_argument("--old-sku", help="Override Reminder Old SKU")
    apply.add_argument("--new-sku", help="Override Reminder New SKU")
    apply.add_argument("--csv", help="Path to Reminder CSV export")
    apply.add_argument("--force", action="store_true", help="Allow incomplete sheet rows")
    apply.add_argument("--allow-rerun", action="store_true", help="Allow ledger re-run")
    apply.set_defaults(func=cmd_apply_sku)

    api_check = sub.add_parser(
        "api-check",
        help="Read exact live ShipStation order and validate Old SKU (no writes)",
    )
    api_check.add_argument("--order", required=True, help="Exact Reminder Order ID")
    api_check.add_argument("--csv", help="Path to Reminder CSV export")
    api_check.add_argument(
        "--ship-order",
        help="Exact ShipStation order number if it differs from the Reminder id",
    )
    api_check.set_defaults(func=cmd_api_check)

    api_apply = sub.add_parser(
        "api-apply",
        help="TESTING ONLY — rewrite SKU on the original order in place",
    )
    api_apply.add_argument("--order", required=True, help="Exact Reminder Order ID")
    api_apply.add_argument("--csv", help="Path to Reminder CSV export")
    api_apply.add_argument(
        "--ship-order",
        help="Exact ShipStation order number if it differs from the Reminder id",
    )
    api_apply.add_argument("--allow-rerun", action="store_true", help="Allow ledger re-run")
    api_apply.add_argument(
        "--confirm", action="store_true", help="Required to actually write to ShipStation"
    )
    api_apply.add_argument(
        "--clear-blank-carrier",
        action="store_true",
        help="Blank a carrier that has no service selected (V1 rejects that combination)",
    )
    api_apply.add_argument(
        "--testing-only",
        action="store_true",
        help="Required: acknowledges this overwrites the original order (not ops path)",
    )
    api_apply.set_defaults(func=cmd_api_apply)

    api_resend = sub.add_parser(
        "api-resend",
        help="Option A via API: keep original, create ONE new resend order",
    )
    api_resend.add_argument("--order", required=True, help="Exact Reminder Order ID")
    api_resend.add_argument("--csv", help="Path to Reminder CSV export")
    api_resend.add_argument(
        "--ship-order",
        help="Exact ShipStation order number if it differs from the Reminder id",
    )
    api_resend.add_argument("--allow-rerun", action="store_true", help="Allow ledger re-run")
    api_resend.add_argument(
        "--confirm",
        action="store_true",
        help="Actually create the new order (without this it is a read-only preview)",
    )
    api_resend.set_defaults(func=cmd_api_resend)

    api_bulk = sub.add_parser(
        "api-bulk-resend",
        help="Bulk Option A: clean 1017 leftovers, tag today's originals, create resends",
    )
    api_bulk.add_argument(
        "--orders",
        required=True,
        help="2-5 Reminder Order IDs (comma or space separated)",
    )
    api_bulk.add_argument("--csv", help="Path to Reminder CSV export")
    api_bulk.add_argument("--allow-rerun", action="store_true", help="Allow ledger re-run")
    api_bulk.add_argument(
        "--confirm",
        action="store_true",
        help="Apply 1017 cleanup/tags and create new resend orders",
    )
    api_bulk.set_defaults(func=cmd_api_bulk_resend)

    build_q = sub.add_parser(
        "build-queue",
        help="From Reminder export: date + Ready rows -> replacement-queue.csv",
    )
    build_q.add_argument(
        "--date",
        required=True,
        help="Start date DD/MM/YYYY (e.g. 26/08/2026)",
    )
    build_q.add_argument(
        "--date-to",
        help="End date DD/MM/YYYY (optional; default = same as --date)",
    )
    build_q.add_argument("--csv", help="Reminder export CSV (default: auto-find)")
    build_q.add_argument("--queue", help="Output queue CSV path")
    build_q.set_defaults(func=cmd_build_queue)

    queue_run = sub.add_parser(
        "run-queue",
        help="Create resends for every order in replacement-queue.csv",
    )
    queue_run.add_argument("--queue", help="Queue CSV path")
    queue_run.add_argument("--allow-rerun", action="store_true", help="Allow ledger re-run")
    queue_run.add_argument(
        "--confirm",
        action="store_true",
        help="Actually create resend orders (without this: preview only)",
    )
    queue_run.set_defaults(func=cmd_queue_resend)

    return parser


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    reserved = {
        "dry-run",
        "apply-sku",
        "api-check",
        "api-apply",
        "api-resend",
        "api-bulk-resend",
        "build-queue",
        "run-queue",
        "-h",
        "--help",
    }
    if argv and argv[0] not in reserved and not argv[0].startswith("-"):
        return cmd_short(argv[0], argv[1:])

    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "dry-run" and not args.order and args.last < 1:
        parser.error("--last must be >= 1")
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
