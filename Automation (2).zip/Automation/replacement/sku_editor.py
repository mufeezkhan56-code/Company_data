from __future__ import annotations

import csv
from pathlib import Path


def _norm(name: str) -> str:
    return " ".join((name or "").strip().lower().split())


def detect_sku_column(fieldnames: list[str]) -> str | None:
    """Prefer Item - SKU only — never Item - Fill SKU."""
    mapping = {_norm(name): name for name in fieldnames if name}
    preferred = (
        "item - sku",
        "item sku",
        "sku",
    )
    for alias in preferred:
        if alias in mapping:
            return mapping[alias]
    # Last resort: a column that is exactly sku-ish but not "fill sku"
    for key, original in mapping.items():
        if "fill" in key and "sku" in key:
            continue
        if key.endswith("sku") or key == "sku" or key.startswith("item") and "sku" in key:
            return original
    return None


def detect_order_column(fieldnames: list[str]) -> str | None:
    mapping = {_norm(name): name for name in fieldnames if name}
    preferred = (
        "order - number",
        "order number",
        "order #",
        "order#",
        "order id",
        "orderid",
    )
    for alias in preferred:
        if alias in mapping:
            return mapping[alias]
    for key, original in mapping.items():
        if "order" in key and ("number" in key or "id" in key or "#" in key):
            return original
    return None


def detect_name_column(fieldnames: list[str]) -> str | None:
    mapping = {_norm(name): name for name in fieldnames if name}
    for alias in ("item - name", "item name", "name"):
        if alias in mapping:
            return mapping[alias]
    return None


def detect_custom_field1_column(fieldnames: list[str]) -> str | None:
    """Zayn Manual calls it 'Custom - Field 1'; accept the common variants."""
    mapping = {_norm(name): name for name in fieldnames if name}
    for alias in (
        "custom - field 1",
        "custom field 1",
        "customfield1",
        "custom - field1",
    ):
        if alias in mapping:
            return mapping[alias]
    return None


def _is_discount_or_empty_sku(sku: str, name: str) -> bool:
    if not sku.strip():
        return True
    return "discount" in (name or "").strip().lower()


def _order_matches(cell: str, order_id: str) -> bool:
    cell = (cell or "").strip()
    order_id = (order_id or "").strip()
    if not order_id:
        return True
    return order_id in cell or cell in order_id


def apply_sku_change(
    export_csv: Path,
    new_sku: str,
    output_csv: Path,
    order_id: str | None = None,
    old_sku: str | None = None,
    replacements: list[tuple[str, str]] | None = None,
    custom_field1_value: str | None = None,
) -> dict:
    """
    Edit a Zayn Manual / ShipStation line-items export:
    - Always drop Discount / empty Item-SKU rows
    - Keep only lines whose Item-SKU matches Old SKU (case-insensitive)
    - Write New SKU on those lines
    - Drop other product lines on the same order
    - Optionally stamp Custom - Field 1 (e.g. ``resend``) on the kept lines
    Original file is never modified.
    """
    if not export_csv.exists():
        raise FileNotFoundError(f"ShipStation export not found: {export_csv}")

    pairs: list[tuple[str, str]] = []
    if replacements:
        pairs = [(o.strip(), n.strip()) for o, n in replacements if o.strip() and n.strip()]
    elif old_sku and new_sku:
        pairs = [(old_sku.strip(), new_sku.strip())]
    elif new_sku and not old_sku:
        # Legacy: change all non-discount rows (discouraged)
        pairs = []
        legacy_new = new_sku.strip()
    else:
        raise ValueError("Need Old SKU + New SKU (or replacements list)")

    if replacements is None and old_sku and new_sku:
        pass
    elif not pairs and not (new_sku and not old_sku):
        raise ValueError("Need Old SKU + New SKU")

    with export_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError("ShipStation export has no header")
        fieldnames = list(reader.fieldnames)
        sku_col = detect_sku_column(fieldnames)
        if not sku_col:
            raise ValueError(f"No Item - SKU column found. Headers: {fieldnames}")
        if _norm(sku_col) == "item - fill sku":
            raise ValueError("Refusing to use Item - Fill SKU; need Item - SKU")
        order_col = detect_order_column(fieldnames)
        name_col = detect_name_column(fieldnames)
        custom1_col = detect_custom_field1_column(fieldnames)
        rows = list(reader)

    kept: list[dict] = []
    removed_discount = 0
    removed_other = 0
    changed = 0
    old_values: list[str] = []
    pair_map = {o.lower(): n for o, n in pairs}

    for row in rows:
        sku = (row.get(sku_col) or "").strip()
        name = (row.get(name_col) or "").strip() if name_col else ""

        if order_id and order_col:
            cell = (row.get(order_col) or "").strip()
            if not _order_matches(cell, order_id):
                removed_other += 1
                continue

        if _is_discount_or_empty_sku(sku, name):
            removed_discount += 1
            continue

        if pair_map:
            key = sku.lower()
            if key not in pair_map:
                removed_other += 1
                continue
            old_values.append(sku)
            row[sku_col] = pair_map[key]
            changed += 1
            kept.append(row)
        else:
            # Legacy all-rows new_sku only
            old_values.append(sku)
            row[sku_col] = legacy_new
            changed += 1
            kept.append(row)

    if pair_map and changed == 0:
        raise ValueError(
            f"No export row matched Old SKU(s) {list(pair_map)}. "
            f"SKU column={sku_col!r}. Check Reminder Old SKU vs Item - SKU."
        )

    # Option A: the imported (new) resend order carries the resend flag itself,
    # so ops does not need the manual Bulk Update step.
    custom1_written = 0
    stamp = (custom_field1_value or "").strip()
    if stamp and custom1_col:
        for row in kept:
            row[custom1_col] = stamp
            custom1_written += 1

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(kept)

    return {
        "sku_column": sku_col,
        "order_column": order_col,
        "custom_field1_column": custom1_col,
        "custom_field1_value": stamp,
        "custom_field1_rows": custom1_written,
        "rows_total": len(rows),
        "rows_kept": len(kept),
        "rows_changed": changed,
        "removed_discount": removed_discount,
        "removed_other": removed_other,
        "old_skus": old_values,
        "new_sku": pairs[0][1] if pairs else (new_sku or ""),
        "replacements": pairs,
        "output": str(output_csv),
    }
