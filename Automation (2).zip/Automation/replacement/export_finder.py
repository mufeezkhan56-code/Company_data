from __future__ import annotations

import csv
from pathlib import Path

from replacement.config import ROOT
from replacement.sku_editor import detect_order_column, detect_sku_column


def export_search_dirs() -> list[Path]:
    dirs = [
        ROOT / "data" / "input",
        ROOT / "data" / "samples",
        ROOT,
    ]
    return [d for d in dirs if d.exists()]


def _order_in_csv(path: Path, order_id: str) -> bool:
    needle = order_id.strip()
    if not needle:
        return False
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                return False
            order_col = detect_order_column(list(reader.fieldnames))
            sku_col = detect_sku_column(list(reader.fieldnames))
            if not order_col or not sku_col:
                return False
            for row in reader:
                cell = (row.get(order_col) or "").strip()
                if needle in cell or cell in needle:
                    return True
    except OSError:
        return False
    return False


def find_export_for_order(order_id: str, explicit: str | Path | None = None) -> Path:
    """
    Resolve Zayn/ShipStation export CSV for an order.
    Preference: explicit path → filename contains order id → CSV that contains the order.
    Search: data/input, data/samples, project root.
    """
    if explicit:
        path = Path(explicit)
        if not path.is_absolute():
            path = ROOT / path
        if not path.exists():
            raise FileNotFoundError(f"Export file not found: {path}")
        return path

    order_id = order_id.strip()
    needle = order_id.replace("/", "_")
    name_hits: list[Path] = []
    content_hits: list[Path] = []

    for folder in export_search_dirs():
        for path in sorted(folder.glob("*.csv"), key=lambda p: p.stat().st_mtime, reverse=True):
            # Skip reminder / ledger / output naming
            lower = path.name.lower()
            if "replacement reminder" in lower or lower.startswith("processed-orders"):
                continue
            if "refund and replacemnet" in lower:
                continue
            if needle and needle in path.name:
                name_hits.append(path)
                continue
            if _order_in_csv(path, order_id):
                content_hits.append(path)

    if name_hits:
        return name_hits[0]
    if content_hits:
        return content_hits[0]

    searched = ", ".join(str(d) for d in export_search_dirs())
    raise FileNotFoundError(
        f"No Zayn/ShipStation export found for order {order_id}. "
        f"Put the CSV in data/input or data/samples (name can include the order id), "
        f"or pass --export path. Searched: {searched}"
    )
