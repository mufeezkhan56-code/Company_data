from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path


ORDER_COL_ALIASES = {
    "customer name/order id",
    "customer name / order id",
    "order id",
    "orderid",
}
CHANNEL_COL_ALIASES = {"channel"}
OLD_SKU_ALIASES = {"old sku", "replace sku", "old_sku"}
NEW_SKU_ALIASES = {"new sku", "new_sku"}
REASON_COL_ALIASES = {"reason"}
STATUS_COL_ALIASES = {"status"}
DATE_COL_ALIASES = {"insert date", "date"}
READY_COL_ALIASES = {"ready to make", "ready"}
NOTE_COL_ALIASES = {"reason of not booking"}

QUEUE_HEADERS = [
    "Insert Date",
    "CHANNEL",
    "CUSTOMER NAME/ORDER ID",
    "Reason",
    "old sku",
    "New SKU",
    "Ready to make",
    "STATUS",
]


@dataclass
class ReminderRow:
    order_id: str
    channel: str = ""
    old_sku: str = ""
    new_sku: str = ""
    reason: str = ""
    status: str = ""
    insert_date: str = ""
    ready_to_make: str = ""
    note: str = ""
    source_row: int = 0

    @property
    def normalized_order_id(self) -> str:
        return normalize_order_id(self.order_id)


def normalize_order_id(value: str) -> str:
    text = (value or "").strip()
    if text.startswith("#"):
        text = text[1:].strip()
    return text


def _norm_header(name: str) -> str:
    return re.sub(r"\s+", " ", (name or "").strip().lower())


def _pick_column(fieldnames: list[str], aliases: set[str]) -> str | None:
    mapping = {_norm_header(name): name for name in fieldnames if name}
    for alias in aliases:
        if alias in mapping:
            return mapping[alias]
    return None


def is_zendesk_or_url(order_id: str) -> bool:
    text = (order_id or "").lower()
    return "zendesk.com" in text or text.startswith("http://") or text.startswith("https://")


def _decode_csv_text(csv_path: Path) -> str:
    """Excel/SharePoint exports are often Windows-1252, not UTF-8."""
    raw = csv_path.read_bytes()
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def load_reminder_rows(csv_path: Path) -> list[ReminderRow]:
    if not csv_path.exists():
        raise FileNotFoundError(f"Reminder CSV not found: {csv_path}")

    rows: list[ReminderRow] = []
    text = _decode_csv_text(csv_path)
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise ValueError("Reminder CSV has no header row")

    fieldnames = list(reader.fieldnames)
    order_col = _pick_column(fieldnames, ORDER_COL_ALIASES)
    if not order_col:
        raise ValueError(
            "Reminder CSV needs CUSTOMER NAME/ORDER ID column. "
            f"Found: {fieldnames}"
        )

    channel_col = _pick_column(fieldnames, CHANNEL_COL_ALIASES)
    old_sku_col = _pick_column(fieldnames, OLD_SKU_ALIASES)
    new_sku_col = _pick_column(fieldnames, NEW_SKU_ALIASES)
    reason_col = _pick_column(fieldnames, REASON_COL_ALIASES)
    status_col = _pick_column(fieldnames, STATUS_COL_ALIASES)
    date_col = _pick_column(fieldnames, DATE_COL_ALIASES)
    note_col = _pick_column(fieldnames, NOTE_COL_ALIASES)
    ready_col = _pick_column(fieldnames, READY_COL_ALIASES)

    for index, raw in enumerate(reader, start=2):
        order_id = (raw.get(order_col) or "").strip()
        channel = (raw.get(channel_col) or "").strip() if channel_col else ""
        old_sku = (raw.get(old_sku_col) or "").strip() if old_sku_col else ""
        new_sku = (raw.get(new_sku_col) or "").strip() if new_sku_col else ""
        if not order_id and not channel and not old_sku and not new_sku:
            continue
        rows.append(
            ReminderRow(
                order_id=order_id,
                channel=channel,
                old_sku=old_sku,
                new_sku=new_sku,
                reason=(raw.get(reason_col) or "").strip() if reason_col else "",
                status=(raw.get(status_col) or "").strip() if status_col else "",
                insert_date=(raw.get(date_col) or "").strip() if date_col else "",
                ready_to_make=(raw.get(ready_col) or "").strip() if ready_col else "",
                note=(raw.get(note_col) or "").strip() if note_col else "",
                source_row=index,
            )
        )
    return rows


def find_by_order_id(rows: list[ReminderRow], order_id: str) -> list[ReminderRow]:
    needle = normalize_order_id(order_id).lower()
    if not needle:
        return []
    matches = [row for row in rows if row.normalized_order_id.lower() == needle]
    if matches:
        return matches
    return [
        row
        for row in rows
        if needle in row.normalized_order_id.lower() or row.normalized_order_id.lower() in needle
    ]


def parse_sheet_date(value: str) -> date | None:
    """Parse Insert Date from export (DD/MM/YYYY, D/M/YY, M/D/YYYY, etc.)."""
    text = (value or "").strip()
    if not text or text.lower() == "test":
        return None
    # Keep only the first line if a cell has line breaks.
    text = text.splitlines()[0].strip()
    for fmt in (
        "%d/%m/%Y",
        "%d/%m/%y",
        "%m/%d/%Y",
        "%m/%d/%y",
        "%Y-%m-%d",
        "%d-%m-%Y",
        "%d-%m-%y",
    ):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def parse_user_date(value: str) -> date:
    """Parse a date the user typed in the BAT (DD/MM/YYYY preferred)."""
    parsed = parse_sheet_date(value)
    if not parsed:
        raise ValueError(f"Could not parse date: {value!r}. Use DD/MM/YYYY (e.g. 26/08/2026).")
    return parsed


def is_done_status(status: str) -> bool:
    text = (status or "").strip().lower()
    if not text:
        return False
    return text.startswith("done") or text == "refunded" or text.startswith("refund")


def is_ready_row(row: ReminderRow) -> bool:
    return (row.ready_to_make or "").strip().lower() == "ready"


def row_in_date_range(row: ReminderRow, start: date, end: date) -> bool:
    row_date = parse_sheet_date(row.insert_date)
    if not row_date:
        return False
    return start <= row_date <= end


def row_eligible_for_queue(row: ReminderRow, start: date, end: date) -> tuple[bool, str]:
    if not row_in_date_range(row, start, end):
        return False, "date out of range"
    if not is_ready_row(row):
        return False, "not Ready"
    if is_done_status(row.status):
        return False, "already Done/Refunded"
    if is_zendesk_or_url(row.order_id):
        return False, "Zendesk/URL row"
    if not row.order_id.strip():
        return False, "missing Order ID"
    if not row.old_sku.strip() or not row.new_sku.strip():
        return False, "missing Old/New SKU"
    return True, ""


def filter_queue_rows(rows: list[ReminderRow], start: date, end: date) -> list[ReminderRow]:
    selected: list[ReminderRow] = []
    seen_orders: set[str] = set()
    for row in rows:
        ok, _reason = row_eligible_for_queue(row, start, end)
        if not ok:
            continue
        key = row.normalized_order_id.lower()
        if key in seen_orders:
            continue
        seen_orders.add(key)
        selected.append(row)
    return selected


def write_queue_csv(rows: list[ReminderRow], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=QUEUE_HEADERS)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "Insert Date": row.insert_date,
                    "CHANNEL": row.channel,
                    "CUSTOMER NAME/ORDER ID": row.order_id,
                    "Reason": row.reason,
                    "old sku": row.old_sku,
                    "New SKU": row.new_sku,
                    "Ready to make": row.ready_to_make,
                    "STATUS": row.status,
                }
            )
