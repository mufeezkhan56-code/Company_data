from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from replacement.config import ROOT
from replacement.sheet_reader import normalize_order_id


LEDGER_PATH = ROOT / "data" / "processed-orders.csv"
FIELDNAMES = ["order_id", "action", "sku_text", "output_file", "processed_at_utc", "note"]


def ledger_path() -> Path:
    LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)
    return LEDGER_PATH


def _read_rows() -> list[dict[str, str]]:
    path = ledger_path()
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def find_processed(order_id: str, action: str | None = None) -> list[dict[str, str]]:
    needle = normalize_order_id(order_id).lower()
    rows = _read_rows()
    matches = [row for row in rows if normalize_order_id(row.get("order_id", "")).lower() == needle]
    if action:
        matches = [row for row in matches if (row.get("action") or "") == action]
    return matches


def was_processed(order_id: str, action: str = "apply-sku") -> dict[str, str] | None:
    matches = find_processed(order_id, action=action)
    return matches[-1] if matches else None


def mark_processed(
    order_id: str,
    action: str,
    sku_text: str = "",
    output_file: str = "",
    note: str = "",
) -> Path:
    path = ledger_path()
    exists = path.exists()
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        if not exists:
            writer.writeheader()
        writer.writerow(
            {
                "order_id": normalize_order_id(order_id),
                "action": action,
                "sku_text": sku_text,
                "output_file": output_file,
                "processed_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "note": note,
            }
        )
    return path
