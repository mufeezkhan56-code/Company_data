"""Phase 0: read Reminder CSV, dry-run SKU preview, edit ShipStation export CSV."""

__version__ = "0.1.0"
