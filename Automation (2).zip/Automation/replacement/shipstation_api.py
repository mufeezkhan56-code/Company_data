from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from replacement.config import (
    shipstation_api_key,
    shipstation_api_secret,
    shipstation_base_url,
    shipstation_max_calls,
)


class ShipStationError(RuntimeError):
    """Safe, user-facing ShipStation API failure."""


class OrderNotFoundError(ShipStationError):
    pass


class AmbiguousOrderError(ShipStationError):
    pass


@dataclass
class RateLimit:
    limit: int | None = None
    remaining: int | None = None
    reset_seconds: int | None = None


class ShipStationClient:
    """ShipStation V1 client with strict per-run call limits."""

    def __init__(self, max_calls: int | None = None) -> None:
        key = shipstation_api_key()
        secret = shipstation_api_secret()
        if not key or not secret:
            raise ShipStationError(
                "ShipStation API credentials missing. Put key and secret in .env."
            )

        token = base64.b64encode(f"{key}:{secret}".encode("utf-8")).decode("ascii")
        self._authorization = f"Basic {token}"
        self._base_url = shipstation_base_url()
        self._max_calls = max_calls if max_calls is not None else shipstation_max_calls()
        self.calls_made = 0
        self.rate_limit = RateLimit()

    def _update_rate_limit(self, headers: Any) -> None:
        def as_int(name: str) -> int | None:
            value = headers.get(name)
            try:
                return int(value) if value is not None else None
            except (TypeError, ValueError):
                return None

        self.rate_limit = RateLimit(
            limit=as_int("X-Rate-Limit-Limit"),
            remaining=as_int("X-Rate-Limit-Remaining"),
            reset_seconds=as_int("X-Rate-Limit-Reset"),
        )

    def _get(self, path: str, params: dict[str, str]) -> dict[str, Any]:
        if self.calls_made >= self._max_calls:
            raise ShipStationError(
                f"API call cap reached ({self._max_calls}); stopped safely."
            )

        query = urlencode(params)
        url = f"{self._base_url}{path}?{query}"
        request = Request(
            url,
            headers={
                "Authorization": self._authorization,
                "Accept": "application/json",
                "User-Agent": "Daataa-Replacement-Automation/phase1",
            },
            method="GET",
        )
        self.calls_made += 1

        try:
            with urlopen(request, timeout=30) as response:
                self._update_rate_limit(response.headers)
                raw = response.read().decode("utf-8")
                return json.loads(raw)
        except HTTPError as exc:
            self._update_rate_limit(exc.headers)
            if exc.code == 401:
                raise ShipStationError(
                    "ShipStation authentication failed (401). Check .env key/secret."
                ) from exc
            if exc.code == 404:
                raise OrderNotFoundError("ShipStation endpoint/order not found (404).") from exc
            if exc.code == 429:
                wait = self.rate_limit.reset_seconds
                suffix = f" Retry after about {wait}s." if wait is not None else ""
                raise ShipStationError(
                    f"ShipStation rate limit reached (429). Stopped; no auto-retry.{suffix}"
                ) from exc
            raise ShipStationError(
                f"ShipStation API returned HTTP {exc.code}; stopped without writes."
            ) from exc
        except URLError as exc:
            raise ShipStationError(
                f"Could not connect to ShipStation: {exc.reason}"
            ) from exc
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ShipStationError("ShipStation returned an unreadable response.") from exc

    @staticmethod
    def _normalize_order_number(value: str) -> str:
        """Trim, drop a leading #, collapse internal whitespace, lowercase.

        This only ignores spacing/case noise (ShipStation sometimes stores extra
        or trailing spaces). It still requires the exact same characters/tokens,
        so a genuinely different order number can never match.
        """
        cleaned = value.strip().lstrip("#").strip()
        return " ".join(cleaned.split()).lower()

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        if self.calls_made >= self._max_calls:
            raise ShipStationError(
                f"API call cap reached ({self._max_calls}); stopped safely."
            )

        body = json.dumps(payload).encode("utf-8")
        request = Request(
            f"{self._base_url}{path}",
            data=body,
            headers={
                "Authorization": self._authorization,
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "Daataa-Replacement-Automation/phase1",
            },
            method="POST",
        )
        self.calls_made += 1

        try:
            with urlopen(request, timeout=60) as response:
                self._update_rate_limit(response.headers)
                raw = response.read().decode("utf-8")
                return json.loads(raw)
        except HTTPError as exc:
            self._update_rate_limit(exc.headers)
            detail = ""
            try:
                detail = exc.read().decode("utf-8")[:400]
            except Exception:  # noqa: BLE001 - detail is best-effort only
                detail = ""
            if exc.code == 401:
                raise ShipStationError(
                    "ShipStation authentication failed (401). Check .env key/secret."
                ) from exc
            if exc.code == 429:
                wait = self.rate_limit.reset_seconds
                suffix = f" Retry after about {wait}s." if wait is not None else ""
                raise ShipStationError(
                    f"ShipStation rate limit reached (429). Stopped; no auto-retry.{suffix}"
                ) from exc
            raise ShipStationError(
                f"ShipStation write failed with HTTP {exc.code}. {detail}"
            ) from exc
        except URLError as exc:
            raise ShipStationError(
                f"Could not connect to ShipStation: {exc.reason}"
            ) from exc
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ShipStationError("ShipStation returned an unreadable response.") from exc

    def list_stores(self, show_inactive: bool = False) -> list[dict[str, Any]]:
        """Read-only: list configured stores (to find the Manual store id)."""
        params = {"showInactive": "true" if show_inactive else "false"}
        payload = self._get("/stores", params)
        if isinstance(payload, list):
            return payload
        stores = payload.get("stores") if isinstance(payload, dict) else None
        return stores if isinstance(stores, list) else []

    def find_manual_store(self) -> dict[str, Any] | None:
        """Pick the Manual store (marketplace 'Manual' / name mentions manual)."""
        for store in self.list_stores():
            marketplace = str(store.get("marketplaceName") or "").strip().lower()
            name = str(store.get("storeName") or "").strip().lower()
            if marketplace == "manual" or "manual" in name:
                return store
        return None

    def update_order(self, order_payload: dict[str, Any]) -> dict[str, Any]:
        """Upsert one order via V1 createorder.

        V1 has no partial update, so the caller must pass the full order object
        it just read, with only the intended fields changed. ``orderKey`` is
        required here so ShipStation updates the existing order instead of
        creating a duplicate one.
        """
        if not str(order_payload.get("orderKey") or "").strip():
            raise ShipStationError(
                "Order has no orderKey; refusing to POST (could create a duplicate order)."
            )
        return self._post("/orders/createorder", order_payload)

    def create_new_order(
        self, order_payload: dict[str, Any], original_order_key: str
    ) -> dict[str, Any]:
        """Create a brand-new resend order. Refuses to reuse the original's key.

        A fresh, different ``orderKey`` guarantees ShipStation makes a NEW record
        instead of overwriting the original order.
        """
        new_key = str(order_payload.get("orderKey") or "").strip()
        if not new_key:
            raise ShipStationError("New order needs a fresh orderKey; refusing to POST.")
        if new_key == str(original_order_key or "").strip():
            raise ShipStationError(
                "New orderKey equals the original; refusing (would overwrite original)."
            )
        if order_payload.get("orderId") is not None:
            raise ShipStationError(
                "New order still carries an orderId; refusing (could hit the original)."
            )
        return self._post("/orders/createorder", order_payload)

    def search_by_order_number(self, order_number: str) -> list[dict[str, Any]]:
        """Read-only: every order whose number exactly matches (spacing-tolerant)."""
        requested = order_number.strip().lstrip("#").strip()
        if not requested:
            raise ShipStationError("Order ID is empty.")
        related = self.search_orders_related_to_number(requested)
        requested_norm = self._normalize_order_number(requested)
        return [
            order
            for order in related
            if self._normalize_order_number(str(order.get("orderNumber", "")))
            == requested_norm
        ]

    def search_orders_related_to_number(self, order_number: str) -> list[dict[str, Any]]:
        """All orders from ShipStation orderNumber filter (starts-with), paginated.

        Used for (Multiple) groups where the UI search id may not exact-match one row
        until we disambiguate by child order number and/or Old SKU.
        """
        requested = order_number.strip().lstrip("#").strip()
        if not requested:
            raise ShipStationError("Order ID is empty.")
        query_value = requested.split()[0] if requested.split() else requested
        collected: list[dict[str, Any]] = []
        page = 1
        while True:
            payload = self._get(
                "/orders",
                {"orderNumber": query_value, "page": str(page), "pageSize": "100"},
            )
            orders = payload.get("orders")
            if not isinstance(orders, list):
                raise ShipStationError("ShipStation response has no orders list.")
            collected.extend(orders)
            try:
                pages = int(payload.get("pages") or 1)
            except (TypeError, ValueError):
                pages = 1
            if page >= pages or not orders:
                break
            page += 1
        return collected

    def get_exact_order(self, order_number: str) -> dict[str, Any]:
        """
        ShipStation's orderNumber filter is starts-with, so require one exact
        client-side match. Never select a nearby/prefix order.
        """
        requested = order_number.strip().lstrip("#").strip()
        exact = self.search_by_order_number(requested)
        if not exact:
            raise OrderNotFoundError(
                f"Exact order not found in ShipStation: {requested}. No writes made."
            )
        if len(exact) > 1:
            ids = [str(order.get("orderId", "?")) for order in exact]
            raise AmbiguousOrderError(
                f"Multiple exact ShipStation orders found for {requested}: {ids}. "
                "Stopped; no writes made."
            )
        return exact[0]

    def list_orders_by_tag(
        self,
        tag_id: int,
        order_status: str,
        page: int = 1,
        page_size: int = 100,
    ) -> dict[str, Any]:
        """Read-only: orders that currently have this tag + status."""
        return self._get(
            "/orders/listbytag",
            {
                "tagId": str(tag_id),
                "orderStatus": order_status,
                "page": str(page),
                "pageSize": str(min(page_size, 500)),
            },
        )

    def list_all_orders_by_tag(
        self, tag_id: int, order_status: str, page_size: int = 100
    ) -> list[dict[str, Any]]:
        """Paginate listbytag until all matching orders are collected."""
        collected: list[dict[str, Any]] = []
        page = 1
        while True:
            payload = self.list_orders_by_tag(
                tag_id, order_status, page=page, page_size=page_size
            )
            orders = payload.get("orders")
            if not isinstance(orders, list):
                raise ShipStationError("ShipStation listbytag has no orders list.")
            collected.extend(orders)
            try:
                pages = int(payload.get("pages") or 1)
            except (TypeError, ValueError):
                pages = 1
            if page >= pages or not orders:
                break
            page += 1
        return collected

    def add_tag(self, order_id: int, tag_id: int) -> dict[str, Any]:
        """Add ONE tag to an order. Never deletes or strips other tags."""
        return self._post(
            "/orders/addtag",
            {"orderId": int(order_id), "tagId": int(tag_id)},
        )

    def remove_tag(self, order_id: int, tag_id: int) -> dict[str, Any]:
        """Remove ONE tag from an order. Never deletes the order or other tags."""
        return self._post(
            "/orders/removetag",
            {"orderId": int(order_id), "tagId": int(tag_id)},
        )


def summarize_order(order: dict[str, Any]) -> dict[str, Any]:
    """Return only fields needed for a safe read-only dry-run."""
    advanced = order.get("advancedOptions") or {}
    items = order.get("items") or []
    return {
        "order_id": order.get("orderId"),
        "order_number": order.get("orderNumber"),
        "order_key": order.get("orderKey"),
        "status": order.get("orderStatus"),
        "custom_field_1": advanced.get("customField1"),
        "items": [
            {
                "line_item_key": item.get("lineItemKey"),
                "sku": item.get("sku"),
                "name": item.get("name"),
                "quantity": item.get("quantity"),
            }
            for item in items
        ],
    }
