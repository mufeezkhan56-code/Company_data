from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_dotenv() -> None:
    """Load simple KEY=VALUE entries from .env without exposing secrets."""
    path = ROOT / ".env"
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("\"'")
        if key:
            os.environ.setdefault(key, value)


load_dotenv()


def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()


def reminder_csv_path() -> Path:
    override = _env("REMINDER_CSV_PATH")
    if override:
        path = Path(override)
        path = path if path.is_absolute() else ROOT / path
        if path.exists():
            return path

    candidates = [
        ROOT / "data" / "input" / "replacement-reminder.csv",
        ROOT / "02-Refund and Replacemnet Records(04s-Replacement Reminder).csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    return candidates[0]


def output_dir() -> Path:
    override = _env("OUTPUT_DIR")
    path = Path(override) if override else ROOT / "data" / "output"
    if not path.is_absolute():
        path = ROOT / path
    path.mkdir(parents=True, exist_ok=True)
    return path


def log_dir() -> Path:
    override = _env("LOG_DIR")
    path = Path(override) if override else ROOT / "logs"
    if not path.is_absolute():
        path = ROOT / path
    path.mkdir(parents=True, exist_ok=True)
    return path


def mapping_name() -> str:
    return _env("SHIPSTATION_MAPPING_NAME", "Zayn Manual")


def shipstation_api_key() -> str:
    return _env("SHIPSTATION_API_KEY")


def shipstation_api_secret() -> str:
    return _env("SHIPSTATION_API_SECRET")


def shipstation_base_url() -> str:
    return _env("SHIPSTATION_API_BASE_URL", "https://ssapi.shipstation.com").rstrip("/")


def shipstation_manual_store_id() -> str:
    """Optional: pin the Manual store id so we never guess the resend store."""
    return _env("SHIPSTATION_MANUAL_STORE_ID")


def shipstation_max_calls() -> int:
    """Per-run API soft cap (single default). Bulk uses shipstation_bulk_max_calls()."""
    raw = _env("SHIPSTATION_MAX_API_CALLS_PER_RUN", "5")
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError("SHIPSTATION_MAX_API_CALLS_PER_RUN must be an integer") from exc
    if value < 1 or value > 200:
        raise ValueError("SHIPSTATION_MAX_API_CALLS_PER_RUN must be between 1 and 200")
    return value


def shipstation_bulk_max_calls() -> int:
    """Higher cap for bulk (1017 list/remove/add + several creates)."""
    raw = _env("SHIPSTATION_BULK_MAX_API_CALLS_PER_RUN", "100")
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(
            "SHIPSTATION_BULK_MAX_API_CALLS_PER_RUN must be an integer"
        ) from exc
    if value < 10 or value > 200:
        raise ValueError(
            "SHIPSTATION_BULK_MAX_API_CALLS_PER_RUN must be between 10 and 200"
        )
    return value


def shipstation_tag_all_resend() -> int:
    """Final resend tag on the NEW order (1014-ALL-RESEND; account id default 17781)."""
    raw = _env("SHIPSTATION_TAG_ALL_RESEND", "17781")
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError("SHIPSTATION_TAG_ALL_RESEND must be an integer") from exc


def shipstation_tag_bulk_making() -> int:
    """Legacy bulk tag (deprecated — queue workflow does not use 1017)."""
    raw = _env("SHIPSTATION_TAG_BULK_MAKING", "32185")
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError("SHIPSTATION_TAG_BULK_MAKING must be an integer") from exc


def replacement_queue_path() -> Path:
    """Today's Ready rows written here before CREATE."""
    override = _env("REPLACEMENT_QUEUE_CSV")
    path = Path(override) if override else ROOT / "data" / "input" / "replacement-queue.csv"
    if not path.is_absolute():
        path = ROOT / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path
