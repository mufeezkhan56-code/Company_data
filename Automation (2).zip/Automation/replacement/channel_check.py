from __future__ import annotations

from replacement.sheet_reader import ReminderRow, is_zendesk_or_url


def assess_sku_pair(row: ReminderRow) -> dict:
    """
    SKU source of truth = Old SKU + New SKU (not CHANNEL).
    CHANNEL is notes only.
    Old == New means ready, no SKU rewrite (resend same item).
    """
    flags: list[str] = []
    order_id = row.order_id.strip()
    old_sku = (row.old_sku or "").strip()
    new_sku = (row.new_sku or "").strip()

    if is_zendesk_or_url(order_id):
        flags.append("manual: order id is Zendesk/URL — handle manually")

    if not order_id:
        flags.append("missing order id")

    if not old_sku:
        flags.append("missing Old SKU — cannot select which line to keep/change")
    if not new_sku:
        flags.append("missing New SKU — cannot know replacement value")

    if row.channel:
        flags.append("CHANNEL is notes only (not used for SKU replace)")

    same_sku = bool(old_sku and new_sku and old_sku.lower() == new_sku.lower())
    if same_sku:
        flags.append("Old SKU = New SKU — no SKU rewrite (keep same / resend same item)")
        sku_mode = "same_no_rewrite"
    elif old_sku and new_sku:
        sku_mode = "rewrite"
        flags.append(f"SKU rewrite: {old_sku} → {new_sku}")
    else:
        sku_mode = "blocked"

    ready = bool(order_id and old_sku and new_sku and not is_zendesk_or_url(order_id))

    if not ready:
        clarity = "blocked"
    else:
        clarity = "clear"

    return {
        "clarity": clarity,
        "old_sku": old_sku,
        "new_sku": new_sku,
        "sku_text": new_sku,
        "sku_mode": sku_mode,
        "flags": flags,
        "use_as_sku": ready,
    }


def assess_channel(row: ReminderRow) -> dict:
    return assess_sku_pair(row)
