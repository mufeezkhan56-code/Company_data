from __future__ import annotations

import logging
from datetime import datetime, timezone
from pathlib import Path

from replacement.config import log_dir


def setup_logger(name: str = "replacement") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s", "%Y-%m-%d %H:%M:%S")

    stream = logging.StreamHandler()
    stream.setFormatter(fmt)
    logger.addHandler(stream)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d")
    file_handler = logging.FileHandler(log_dir() / f"phase0-{stamp}.log", encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)
    return logger


def write_run_report(lines: list[str], prefix: str = "dry-run") -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    path = log_dir() / f"{prefix}-{stamp}.txt"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
