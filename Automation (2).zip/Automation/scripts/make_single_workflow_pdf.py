"""Generate a short Single Order Resend workflow PDF."""
from pathlib import Path

from fpdf import FPDF

OUT = Path(__file__).resolve().parent.parent / "SINGLE-ORDER-WORKFLOW.pdf"


class PDF(FPDF):
    def footer(self) -> None:
        self.set_y(-12)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(120, 120, 120)
        self.cell(0, 8, f"Page {self.page_no()}", align="C")


def heading(pdf: PDF, text: str) -> None:
    pdf.ln(3)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(20, 60, 110)
    pdf.cell(0, 7, text, new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(20, 60, 110)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(2)
    pdf.set_text_color(30, 30, 30)


def lines(pdf: PDF, items: list[str]) -> None:
    pdf.set_font("Helvetica", size=10)
    for item in items:
        pdf.set_x(12)
        pdf.multi_cell(0, 5.2, f"- {item}")
    pdf.ln(1)


def box(pdf: PDF, x, y, w, h, text: str, fill) -> None:
    pdf.set_fill_color(*fill)
    pdf.set_draw_color(40, 80, 140)
    pdf.rect(x, y, w, h, style="DF")
    pdf.set_xy(x + 1, y + (h / 2) - 2.5)
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_text_color(20, 40, 80)
    pdf.cell(w - 2, 5, text, align="C")


def main() -> None:
    pdf = PDF()
    pdf.set_auto_page_break(auto=True, margin=14)
    pdf.add_page()

    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(15, 45, 90)
    pdf.cell(0, 9, "Single Order Resend Workflow", new_x="LMARGIN", new_y="NEXT", align="C")
    pdf.set_font("Helvetica", size=10)
    pdf.set_text_color(80, 80, 80)
    pdf.cell(0, 6, "Customer Services - Replacement Automation", new_x="LMARGIN", new_y="NEXT", align="C")
    pdf.ln(3)

    heading(pdf, "What it does")
    lines(
        pdf,
        [
            "Original order stays the same.",
            "Creates one new Manual resend order.",
            "Same Order ID. New SKU from Reminder sheet.",
            "New order: resend + tag 1014.",
        ],
    )

    heading(pdf, "Flow")
    pdf.set_font("Helvetica", "I", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 5, "One Order ID only", new_x="LMARGIN", new_y="NEXT", align="C")
    pdf.set_text_color(30, 30, 30)
    pdf.ln(1)

    cx, bw, bh = 105, 95, 9
    y = pdf.get_y()
    flow = [
        ("1. Fill Reminder: Order ID + Old SKU + New SKU", (230, 240, 255)),
        ("2. Put updated Reminder CSV in Automation folder", (230, 240, 255)),
        ("3. Open run-resend.bat", (220, 245, 220)),
        ("4. Paste Order ID (not Product ID / SKU)", (220, 245, 220)),
        ("5. Check PREVIEW", (255, 248, 220)),
        ("6. Type CREATE  (or Enter to cancel)", (255, 248, 220)),
        ("7. Check ShipStation: original + 1 new order", (230, 240, 255)),
    ]
    for i, (label, color) in enumerate(flow):
        box(pdf, cx - bw / 2, y, bw, bh, label, color)
        y += bh
        if i < len(flow) - 1:
            pdf.set_draw_color(40, 80, 140)
            pdf.line(cx, y, cx, y + 4)
            pdf.line(cx, y + 4, cx - 1.5, y + 2.5)
            pdf.line(cx, y + 4, cx + 1.5, y + 2.5)
            y += 5
    pdf.set_y(y + 3)

    heading(pdf, "Before you start")
    lines(
        pdf,
        [
            "Reminder must have Order ID, Old SKU, New SKU.",
            "CSV in the Automation folder must be updated.",
            "First time on a PC: install Python, then setup.bat.",
            "Keep .env private (API keys).",
        ],
    )

    heading(pdf, "After CREATE")
    lines(
        pdf,
        [
            "Search Order ID in ShipStation.",
            "You should see 2 orders: original + new Manual.",
            "New order has correct SKU and awaiting shipment.",
        ],
    )

    heading(pdf, "If it fails")
    lines(
        pdf,
        [
            "Old SKU not found: fix Old SKU to match live Item SKU, update CSV, retry.",
            "Already processed: do not run again unless team says so.",
            "Python not found: install Python with PATH, then setup.bat.",
        ],
    )

    heading(pdf, "Rules")
    lines(
        pdf,
        [
            "One Order ID per run.",
            "Do not change the original order.",
            "Do not delete orders.",
            "Do not share API keys.",
        ],
    )

    pdf.output(str(OUT))
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
