@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title Automation - First-time setup
color 0B

echo.
echo ============================================
echo   FIRST-TIME SETUP (requirements)
echo ============================================
echo.
echo  Python must already be installed on this PC.
echo  Install from: https://www.python.org/downloads/
echo  Tick: Add python.exe to PATH
echo.
echo  This setup only installs packages from
echo  requirements.txt  (one-time per PC).
echo ============================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python not found on PATH.
  echo.
  echo 1. Install Python 3.10+ from python.org
  echo 2. Tick "Add python.exe to PATH"
  echo 3. Close ALL CMD windows and open a new one
  echo 4. Run this setup.bat again
  echo.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)

echo Found Python:
python --version
echo.

echo Upgrading pip...
python -m pip install --upgrade pip
if errorlevel 1 (
  echo.
  echo pip upgrade failed. Check internet / permissions.
  pause
  exit /b 1
)

echo.
echo Installing from requirements.txt ...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo requirements install failed.
  pause
  exit /b 1
)

echo.
echo Quick check...
python run.py --help
if errorlevel 1 (
  echo.
  echo Script check failed. Ask automation owner.
  pause
  exit /b 1
)

echo.
echo ============================================
echo   SETUP OK
echo ============================================
echo  Next: put your .env keys on this PC
echo  Then use: run-resend.bat  (daily work)
echo  You usually do NOT need setup.bat again
echo  unless requirements.txt changes.
echo ============================================
echo.
pause
exit /b 0
