@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title Replacement Queue - Date + Ready
color 0A

echo.
echo ============================================
echo   Replacement Queue (date + Ready)
echo ============================================
echo.
echo  1) Export live Reminder sheet to this folder first.
echo  2) Enter date (DD/MM/YYYY) - Ready rows become queue file.
echo  3) Preview - then type CREATE to build resends.
echo.
echo  No tag 1017. New orders get 1014 ALL-RESEND only.
echo ============================================
echo.

set /p RUN_DATE=Insert Date (from): 
if "%RUN_DATE%"=="" (
  echo No date entered. Closing.
  pause
  exit /b 1
)

set /p RUN_DATE_TO=Insert Date (to, or press Enter for same day): 

echo.
echo --- STEP 1: Build queue file from export (no ShipStation writes) ---
echo.

if "%RUN_DATE_TO%"=="" (
  python run.py build-queue --date "%RUN_DATE%"
) else (
  python run.py build-queue --date "%RUN_DATE%" --date-to "%RUN_DATE_TO%"
)
set BUILD_EXIT=%ERRORLEVEL%
if not "%BUILD_EXIT%"=="0" (
  echo.
  if "%BUILD_EXIT%"=="2" (
    echo No Ready rows for that date. Check export + Ready column.
  ) else (
    echo Build failed. Check date format DD/MM/YYYY and Reminder CSV path.
  )
  echo.
  pause
  exit /b %BUILD_EXIT%
)

echo.
echo Queue file: data\input\replacement-queue.csv
echo Open it to verify orders, then continue below.
echo.
echo --- STEP 2: Preview resends (still no creates) ---
echo.
python run.py run-queue
set PREVIEW_EXIT=%ERRORLEVEL%
if not "%PREVIEW_EXIT%"=="0" (
  echo Preview failed.
  pause
  exit /b %PREVIEW_EXIT%
)

echo.
echo ============================================
echo  Preview OK?
echo.
echo  Type exactly:  CREATE
echo  to build resends for every order in the queue file.
echo.
echo  Press Enter to cancel (no resends created).
echo ============================================
echo.
set /p CONFIRM=Type CREATE to continue: 

if /I not "%CONFIRM%"=="CREATE" (
  echo.
  echo Cancelled. Queue file kept; no resends created.
  echo.
  pause
  exit /b 0
)

echo.
echo --- CREATING resends from queue file ---
echo.
python run.py run-queue --confirm
set CREATE_EXIT=%ERRORLEVEL%

if "%CREATE_EXIT%"=="0" (
  echo.
  echo Done. Check ShipStation; mark Done on live sheet manually.
  echo.
  pause
  exit /b 0
)

echo.
echo Some orders failed or were blocked by ledger.
echo Type ALLOW-RERUN only if intentional (double ship risk).
echo.
set /p RERUN=Type ALLOW-RERUN or press Enter: 
if /I not "%RERUN%"=="ALLOW-RERUN" (
  pause
  exit /b %CREATE_EXIT%
)

python run.py run-queue --confirm --allow-rerun
set RERUN_EXIT=%ERRORLEVEL%
echo.
pause
exit /b %RERUN_EXIT%
