@echo off
cd /d "%~dp0"
echo Running MAS_Shipping.py ...
python MAS_Shipping.py --skip-csv-import --skip-shipping > _agent_run_log.txt 2>&1
type _agent_run_log.txt
echo.
echo Exit code: %ERRORLEVEL%
pause
