"""Run MAS_Shipping.py and save full CMD output to _agent_run_log.txt"""
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
LOG = BASE / "_agent_run_log.txt"
lines = ["=== Column A: shipping price calculator.xlsx ===", ""]

cmd_a = [
    sys.executable,
    "-c",
    (
        "from openpyxl import load_workbook\n"
        "wb = load_workbook('shipping price calculator.xlsx', read_only=True, data_only=True)\n"
        "ws = wb['Sheet1']\n"
        "for row in ws.iter_rows(values_only=True):\n"
        "    if row[0] is not None:\n"
        "        print(row[0])"
    ),
]

r1 = subprocess.run(cmd_a, cwd=str(BASE), capture_output=True, text=True, encoding="utf-8", errors="replace")
lines.append(r1.stdout or "")
if r1.stderr:
    lines.append(r1.stderr)
lines.append(f"(exit {r1.returncode})")
lines.append("")
lines.append("=== MAS_Shipping.py ===")
lines.append("")

r2 = subprocess.run(
    [sys.executable, "MAS_Shipping.py"],
    cwd=str(BASE),
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
)
lines.append(r2.stdout or "")
if r2.stderr:
    lines.append(r2.stderr)
lines.append(f"(exit {r2.returncode})")

LOG.write_text("\n".join(lines), encoding="utf-8")
print(f"Wrote {LOG}")
