"""
MAS Clothing — build MAS clothing YYYY orders.xlsx from CSV + shipping calculator.
Auto-detects CSV, calculator file, price dates, and services. Layout mirrors prior-year workbook.
"""
import argparse
import os
import re
import shutil
import sys
from dataclasses import dataclass

import openpyxl
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill

# --- static config ---
REFERENCE_WORKBOOK_PREFIX = "MAS clothing"
ORDERS_SHEET = "MAS clothing 2025 orders csv"
PRODUCTS_FILE = "01-Products Database.xlsx"
PRODUCTS_SHEET = "Custom Label Data"

SHIPPING_PRICE_SHEET = "Sheet1"
SHIPPING_DATE_ROW_INDEX = 2  # Excel row 3
SHIPPING_KEYWORDS = ["TRS", "TPS", "TRN", "TPN"]
CALCULATOR_NAME_KEYWORDS = ("price", "calculator", "shipping")
CALCULATOR_EXCLUDE_NAME_PARTS = ("orders", "products database")

# Set in main() before processing
CFG = None

# Fixed gender apparel unit costs (2026)
APPAREL_PRICES = {
    "KIDS-T-SHIRT": 1.33,
    "MENS-T-SHIRT": 1.90,
    "MENS-T-SHIRT-BIG": 1.88,
    "WOMENS-T-SHIRT": 1.88,
    "ONLY-DESIGN": 0.0,
}

EXPECTED = {
    "unique_orders": 1172,
    "line_items": 1271,
    "line_qty": 1326,
    "shipping_total": 2891.50,
    "shipping_orders": 1172,
    "apparel_qty": 1265,
    "apparel_total": 1485.91,
    "grand_total": 7165.52,
    "operations_cost": 2.20,
    "position_cost": 0.73,
}


@dataclass
class RunConfig:
    base_dir: str
    orders_csv_path: str
    orders_csv_name: str
    calculator_path: str
    calculator_name: str
    orders_workbook: str
    orders_workbook_path: str
    report_year: int
    report_start: pd.Timestamp
    report_end: pd.Timestamp
    orders_date_min: pd.Timestamp
    orders_date_max: pd.Timestamp


def _base_dir():
    return os.path.dirname(os.path.abspath(__file__))


def _require_cfg():
    if CFG is None:
        raise RuntimeError("RunConfig not initialised — call init_run_config() first")
    return CFG


def orders_workbook_path():
    """Absolute path to the output orders workbook for this run."""
    cfg = _require_cfg()
    os.chdir(cfg.base_dir)
    return cfg.orders_workbook_path


def find_newest_csv(base_dir):
    """Newest .csv in folder by modification time."""
    csvs = [
        f
        for f in os.listdir(base_dir)
        if f.lower().endswith(".csv") and os.path.isfile(os.path.join(base_dir, f))
    ]
    if not csvs:
        raise FileNotFoundError(f"No CSV files found in {base_dir}")
    csvs.sort(key=lambda f: os.path.getmtime(os.path.join(base_dir, f)), reverse=True)
    name = csvs[0]
    return os.path.join(base_dir, name), name


def find_shipping_calculator(base_dir):
    """Excel file whose name contains price, calculator, and/or shipping."""
    candidates = []
    for name in os.listdir(base_dir):
        if not name.lower().endswith(".xlsx"):
            continue
        low = name.lower()
        if any(ex in low for ex in CALCULATOR_EXCLUDE_NAME_PARTS):
            continue
        score = sum(1 for kw in CALCULATOR_NAME_KEYWORDS if kw in low)
        if score == 0:
            continue
        path = os.path.join(base_dir, name)
        candidates.append((score, os.path.getmtime(path), name, path))
    if not candidates:
        raise FileNotFoundError(
            "Shipping calculator not found. Expected an .xlsx file with "
            "'price', 'calculator', or 'shipping' in the filename."
        )
    candidates.sort(key=lambda x: (-x[0], -x[1]))
    return candidates[0][3], candidates[0][2]


def _reference_workbook_for_year(year):
    """Prior-year layout template if present."""
    prev = os.path.join(
        _base_dir(), f"{REFERENCE_WORKBOOK_PREFIX} {year - 1} orders.xlsx"
    )
    if os.path.isfile(prev):
        return prev
    legacy = os.path.join(_base_dir(), f"{REFERENCE_WORKBOOK_PREFIX} 2025 orders.xlsx")
    if os.path.isfile(legacy) and year != 2025:
        return legacy
    return prev if os.path.isfile(prev) else None


def init_run_config(base_dir=None, csv_path=None):
    """Detect CSV, report year/range, output workbook, and calculator."""
    global CFG
    base = base_dir or _base_dir()
    os.chdir(base)

    if csv_path:
        orders_csv_path = os.path.abspath(csv_path)
        orders_csv_name = os.path.basename(orders_csv_path)
    else:
        orders_csv_path, orders_csv_name = find_newest_csv(base)

    preview = pd.read_csv(orders_csv_path, encoding="utf-8-sig", nrows=0)
    if "Date - Order Date" not in preview.columns:
        raise ValueError(f"CSV missing 'Date - Order Date' column: {orders_csv_name}")

    dates = pd.to_datetime(
        pd.read_csv(
            orders_csv_path,
            encoding="utf-8-sig",
            usecols=["Date - Order Date"],
        )["Date - Order Date"],
        errors="coerce",
    )
    dates = dates.dropna()
    if dates.empty:
        raise ValueError(f"No valid order dates in CSV: {orders_csv_name}")

    report_year = int(dates.dt.year.mode().iloc[0])
    report_start = pd.Timestamp(report_year, 1, 1)
    max_d = dates.max()
    report_end = pd.Timestamp(max_d.year, max_d.month, 1) + pd.offsets.MonthBegin(1)
    if report_end <= max_d:
        report_end = max_d.normalize() + pd.Timedelta(days=1)

    orders_workbook = f"{REFERENCE_WORKBOOK_PREFIX} {report_year} orders.xlsx"
    calculator_path, calculator_name = find_shipping_calculator(base)

    CFG = RunConfig(
        base_dir=base,
        orders_csv_path=orders_csv_path,
        orders_csv_name=orders_csv_name,
        calculator_path=calculator_path,
        calculator_name=calculator_name,
        orders_workbook=orders_workbook,
        orders_workbook_path=os.path.join(base, orders_workbook),
        report_year=report_year,
        report_start=report_start,
        report_end=report_end,
        orders_date_min=dates.min(),
        orders_date_max=dates.max(),
    )
    return CFG


def _permission_error_help(out_path):
    cfg = _require_cfg()
    print("\n" + "=" * 60)
    print("PERMISSION DENIED — cannot write to Excel workbook")
    print("=" * 60)
    print(f"\nFile:\n  {out_path}\n")
    print(f"Close '{cfg.orders_workbook}' in Excel, then run again.")
    print("=" * 60 + "\n")


def assert_workbook_writable():
    cfg = _require_cfg()
    out_path = cfg.orders_workbook_path
    os.chdir(cfg.base_dir)
    if not os.path.isfile(out_path):
        return
    try:
        with open(out_path, "r+b"):
            pass
    except PermissionError:
        _permission_error_help(out_path)
        raise SystemExit(1)


def ensure_workbook_shell():
    """Seed output workbook from prior-year layout when possible."""
    cfg = _require_cfg()
    out_path = cfg.orders_workbook_path
    if os.path.isfile(out_path):
        return
    ref_path = _reference_workbook_for_year(cfg.report_year)
    if ref_path and os.path.isfile(ref_path):
        shutil.copy(ref_path, out_path)
        print(
            f"Created {cfg.orders_workbook} from {os.path.basename(ref_path)} "
            "(layout template)."
        )
    else:
        print(f"No reference workbook found; creating new {cfg.orders_workbook}.")


def import_orders_csv(skip_if_locked=False):
    cfg = _require_cfg()
    out_path = cfg.orders_workbook_path
    csv_path = cfg.orders_csv_path
    print(f"Using orders CSV: {cfg.orders_csv_name}")

    df = pd.read_csv(csv_path, encoding="utf-8-sig")
    n_orders = df["Order - Number"].nunique()
    print(
        f"CSV: {len(df)} line items, {n_orders} unique orders, "
        f"qty sum {int(df['Item - Qty'].sum())}"
    )

    ensure_workbook_shell()
    try:
        if os.path.isfile(out_path):
            with pd.ExcelWriter(
                out_path, engine="openpyxl", mode="a", if_sheet_exists="replace"
            ) as writer:
                df.to_excel(writer, sheet_name=ORDERS_SHEET, index=False)
        else:
            with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
                df.to_excel(writer, sheet_name=ORDERS_SHEET, index=False)
    except PermissionError:
        if skip_if_locked and os.path.isfile(out_path):
            print("WARNING: CSV import skipped (file locked). Using existing workbook.")
            return False
        _permission_error_help(out_path)
        raise SystemExit(1)

    print(f"Imported orders -> {cfg.orders_workbook} sheet '{ORDERS_SHEET}'")
    return True


def _parse_date_cells(row):
    date_cols = {}
    for i, val in enumerate(row):
        try:
            dt = pd.to_datetime(val)
            if pd.notnull(dt):
                date_cols[pd.Timestamp(dt)] = i
        except Exception:
            pass
    return date_cols


def _print_calculator_service_rows(service_cost_rows):
    print("  Calculator column A (rows with TRS, TRN, TPS, or TPN):")
    for name, idx in sorted(service_cost_rows.items(), key=lambda x: x[1]):
        if any(k in name for k in SHIPPING_KEYWORDS):
            print(f"    Excel row {idx + 1}: {name}")


def _find_row_by_rules(service_cost_rows, must_have, must_not_have=()):
    best_idx = None
    best_score = -1
    for name, idx in service_cost_rows.items():
        if any(bad in name for bad in must_not_have):
            continue
        if not all(token in name for token in must_have):
            continue
        score = sum(1 for token in must_have)
        if "LETTERBOX" in must_have:
            score += 1
        if score > best_score:
            best_score = score
            best_idx = idx
    return best_idx


def _fallback_keyword_row(keyword, service_cost_rows):
    for name, idx in service_cost_rows.items():
        if keyword in name:
            return idx
    return None


def _build_keyword_row_map(service_cost_rows):
    """Map TRS/TRN/TPS/TPN to calculator rows discovered from column A."""
    keyword_map = {kw: None for kw in SHIPPING_KEYWORDS}
    for kw in SHIPPING_KEYWORDS:
        matches = [(name, idx) for name, idx in service_cost_rows.items() if kw in name]
        if len(matches) == 1:
            keyword_map[kw] = matches[0][1]
        elif len(matches) > 1:
            keyword_map[kw] = matches[0][1]

    if keyword_map.get("TRS") is None:
        keyword_map["TRS"] = _find_row_by_rules(
            service_cost_rows,
            must_have=["48", "LETTERBOX"],
            must_not_have=["24", "TRN", "TPS", "TPN"],
        )
    if keyword_map.get("TRN") is None:
        keyword_map["TRN"] = _find_row_by_rules(
            service_cost_rows,
            must_have=["24", "LETTERBOX"],
            must_not_have=["48", "TRS", "TPS", "TPN"],
        )
    if keyword_map.get("TPS") is None:
        keyword_map["TPS"] = _find_row_by_rules(
            service_cost_rows,
            must_have=["48", "TPS"],
            must_not_have=["LETTERBOX", "24", "TRN", "TPN", "TRS"],
        )
    if keyword_map.get("TPN") is None:
        keyword_map["TPN"] = _find_row_by_rules(
            service_cost_rows,
            must_have=["24", "TPN"],
            must_not_have=["LETTERBOX", "48", "TRS", "TPS", "TRN"],
        )

    for kw in SHIPPING_KEYWORDS:
        if keyword_map.get(kw) is None:
            keyword_map[kw] = _fallback_keyword_row(kw, service_cost_rows)

    return keyword_map


def _resolve_shipping_cost_row(service_upper, service_cost_rows, keyword_row_map):
    if "RM T24 PARCEL" in service_upper:
        return keyword_row_map.get("TPN") or _fallback_keyword_row("TPN", service_cost_rows)
    if "LETTERBOX" in service_upper and "TRS" in service_upper:
        return keyword_row_map.get("TRS")
    if "LETTERBOX" in service_upper and "TRN" in service_upper:
        return keyword_row_map.get("TRN")
    if "TPS" in service_upper:
        return keyword_row_map.get("TPS")
    if "TPN" in service_upper:
        return keyword_row_map.get("TPN")
    for kw in SHIPPING_KEYWORDS:
        if kw in service_upper:
            return keyword_row_map.get(kw) or _fallback_keyword_row(kw, service_cost_rows)
    return None


def load_shipping_price_calculator():
    cfg = _require_cfg()
    path = cfg.calculator_path
    filename = cfg.calculator_name
    print(f"Using shipping calculator: {filename}")

    cost_df = pd.read_excel(path, sheet_name=SHIPPING_PRICE_SHEET, header=None)
    date_cols = _parse_date_cells(cost_df.iloc[SHIPPING_DATE_ROW_INDEX])
    if not date_cols:
        raise RuntimeError("No date columns in row 3 of calculator.")

    all_price_dates = sorted(dt for dt in date_cols if pd.notnull(dt))
    sorted_dates = [d for d in all_price_dates if d.year == cfg.report_year]
    if not sorted_dates:
        before_end = [d for d in all_price_dates if d < cfg.report_end]
        if before_end:
            sorted_dates = [before_end[-1]]
        else:
            raise RuntimeError(
                f"No price dates for report year {cfg.report_year} in calculator row 3."
            )

    service_cost_rows = {}
    for idx in range(SHIPPING_DATE_ROW_INDEX + 1, len(cost_df)):
        raw = str(cost_df.iloc[idx, 0]).strip()
        if not raw or raw.upper() in ("NAN", "NONE", "SERVICE", "CARRIER", "NAME"):
            continue
        service_cost_rows[" ".join(raw.upper().split())] = idx

    _print_calculator_service_rows(service_cost_rows)
    keyword_row_map = _build_keyword_row_map(service_cost_rows)

    return cost_df, service_cost_rows, {
        "file": filename,
        "all_price_dates": all_price_dates,
        "sorted_dates": sorted_dates,
        "date_cols": date_cols,
        "keyword_row_map": keyword_row_map,
    }


def _next_month_start(ts):
    return pd.Timestamp(ts.year, ts.month, 1) + pd.offsets.MonthBegin(1)


def _shipping_note_text(cfg, sorted_dates):
    date_bits = ", ".join(d.strftime("%d %b %Y") for d in sorted_dates)
    return (
        f"Note: Shipping rates from {cfg.calculator_name}. "
        f"{cfg.report_year} price change dates: {date_bits}. "
        f"Orders after the last listed date use the latest column's rates."
    )


def _unit_cost_from_col(cost_df, cost_row, col_idx):
    if cost_row is None:
        return 0.0
    try:
        val = cost_df.iloc[cost_row, col_idx]
        if pd.isna(val):
            return 0.0
        if isinstance(val, str):
            val = val.replace("£", "").replace(",", "").strip()
        return float(val)
    except Exception:
        return 0.0


def _pivot_label(start_d, is_may=False):
    if is_may:
        return "May"
    return start_d.strftime("%d-%b-%y")


def generate_shipping_summary():
    cfg = _require_cfg()
    try:
        cost_df, service_cost_rows, info = load_shipping_price_calculator()
    except Exception as e:
        print(f"Failed to load shipping calculator: {e}")
        return

    sorted_dates = info["sorted_dates"]
    date_cols = info["date_cols"]
    keyword_row_map = info["keyword_row_map"]
    report_start = cfg.report_start
    report_end = cfg.report_end

    print(f"  {cfg.report_year} price change dates (row 3):")
    for dt in sorted_dates:
        print(f"    - {dt.strftime('%A, %B %d, %Y')} (col {date_cols[dt]})")
    print("  Service row mapping:")
    for kw in SHIPPING_KEYWORDS:
        idx = keyword_row_map.get(kw)
        if idx is not None:
            name = str(cost_df.iloc[idx, 0]).strip()
            p = _unit_cost_from_col(cost_df, idx, date_cols[sorted_dates[0]])
            print(f"    {kw} -> row {idx + 1}: {name} | sample £{p:.2f}")
        else:
            print(f"    {kw} -> NOT FOUND")

    price_periods = []
    for i, start_d in enumerate(sorted_dates):
        end_d = sorted_dates[i + 1] if i + 1 < len(sorted_dates) else None
        price_periods.append((start_d, end_d, date_cols[start_d]))

    print("Loading orders for shipping...")
    try:
        orders_df = pd.read_excel(cfg.orders_workbook, sheet_name=ORDERS_SHEET)
        orders_df["Date - Order Date"] = pd.to_datetime(
            orders_df["Date - Order Date"], errors="coerce"
        )
        orders_in_range = orders_df[
            (orders_df["Date - Order Date"] >= report_start)
            & (orders_df["Date - Order Date"] < report_end)
        ].copy()
        unique_orders = orders_in_range.drop_duplicates(subset=["Order - Number"]).copy()
        print(
            f"  {report_start.date()} to {report_end.date()}: "
            f"{len(unique_orders)} unique orders, {len(orders_in_range)} line items"
        )
    except Exception as e:
        print(f"Error loading orders: {e}")
        return

    summary_list = []
    unique_services = unique_orders["Carrier - Service Selected"].dropna().unique()

    for service in unique_services:
        service_str = str(service).strip()
        service_upper = service_str.upper()
        cost_row = _resolve_shipping_cost_row(
            service_upper, service_cost_rows, keyword_row_map
        )
        if cost_row is None and "SPECIAL DELIVERY" not in service_upper:
            print(f"  WARNING: no calculator row for: {service_str}")

        service_orders = unique_orders[
            unique_orders["Carrier - Service Selected"].str.strip() == service_str
        ]

        for period_idx, (start_d, end_d, price_col) in enumerate(price_periods):
            if period_idx == 0:
                count_start = report_start
            else:
                count_start = start_d

            unit_cost = _unit_cost_from_col(cost_df, cost_row, price_col)

            # Last price period: use latest column; split pivot by calendar month.
            if end_d is None:
                first_month_end = min(_next_month_start(start_d), report_end)
                if first_month_end > count_start:
                    mask = (service_orders["Date - Order Date"] >= count_start) & (
                        service_orders["Date - Order Date"] < first_month_end
                    )
                    qty = len(service_orders[mask])
                    if qty > 0:
                        summary_list.append(
                            {
                                "Service": service_str,
                                "Start Date": start_d,
                                "End Date": None,
                                "PivotLabel": _pivot_label(start_d, is_may=False),
                                "Quantity": qty,
                                "Cost": round(unit_cost, 2),
                                "Total": round(qty * unit_cost, 2),
                            }
                        )
                month_cursor = first_month_end
                while month_cursor < report_end:
                    month_end = min(_next_month_start(month_cursor), report_end)
                    mask_m = (service_orders["Date - Order Date"] >= month_cursor) & (
                        service_orders["Date - Order Date"] < month_end
                    )
                    qty_m = len(service_orders[mask_m])
                    if qty_m > 0:
                        summary_list.append(
                            {
                                "Service": service_str,
                                "Start Date": start_d,
                                "End Date": None,
                                "PivotLabel": month_cursor.strftime("%B"),
                                "Quantity": qty_m,
                                "Cost": round(unit_cost, 2),
                                "Total": round(qty_m * unit_cost, 2),
                            }
                        )
                    month_cursor = month_end
                continue

            count_end = min(end_d, report_end)
            if count_end <= count_start:
                continue

            mask = (service_orders["Date - Order Date"] >= count_start) & (
                service_orders["Date - Order Date"] < count_end
            )
            qty = len(service_orders[mask])
            if qty <= 0:
                continue

            summary_list.append(
                {
                    "Service": service_str,
                    "Start Date": start_d,
                    "End Date": end_d,
                    "PivotLabel": _pivot_label(start_d),
                    "Quantity": qty,
                    "Cost": round(unit_cost, 2),
                    "Total": round(qty * unit_cost, 2),
                }
            )

    if not summary_list:
        print("No shipping rows generated.")
        return

    final_df = pd.DataFrame(summary_list)
    final_df = (
        final_df.groupby(
            ["Service", "Start Date", "End Date", "PivotLabel", "Cost"], dropna=False
        )
        .agg({"Quantity": "sum", "Total": "sum"})
        .reset_index()
    )
    final_df = final_df.sort_values(by=["Start Date", "Service"], ascending=[True, True])

    shipping_total = round(final_df["Total"].sum(), 2)
    shipping_qty = int(final_df["Quantity"].sum())
    total_orders = orders_in_range["Order - Number"].nunique()
    total_line_items = len(orders_in_range)
    total_line_items_qty = int(orders_in_range["Item - Qty"].sum())

    if shipping_qty != total_orders:
        print(
            f"  WARNING: shipping qty {shipping_qty} != unique orders {total_orders}"
        )
    else:
        print(f"  All {shipping_qty} unique orders assigned to price periods.")

    print(f"  Shipping total: £{shipping_total:,.2f}")

    shipping_note = _shipping_note_text(cfg, sorted_dates)

    try:
        wb = openpyxl.load_workbook(cfg.orders_workbook)
        if "Shipping" in wb.sheetnames:
            wb.remove(wb["Shipping"])
        ws = wb.create_sheet("Shipping", 1)

        headers = [
            "Carrier - Service Selected",
            "Start Date",
            "End Date",
            "Quantity",
            "Cost",
            "Total",
        ]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = Font(bold=True)

        date_fill = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
        date_font = Font(color="000000", name="Calibri", size=11)

        for _, row in final_df.iterrows():
            start_str = row["Start Date"].strftime("%A, %B %d, %Y")
            end_str = (
                row["End Date"].strftime("%A, %B %d, %Y")
                if pd.notnull(row["End Date"])
                else ""
            )
            ws.append(
                [
                    row["Service"],
                    start_str,
                    end_str,
                    row["Quantity"],
                    row["Cost"],
                    row["Total"],
                ]
            )
            curr_row = ws.max_row
            for col_idx in (2, 3):
                c = ws.cell(row=curr_row, column=col_idx)
                c.fill = date_fill
                c.font = date_font
                c.alignment = Alignment(horizontal="center", vertical="center")

        ws.column_dimensions["A"].width = 30
        ws.column_dimensions["B"].width = 35
        ws.column_dimensions["C"].width = 35

        start_col = 8  # H

        ws.cell(row=1, column=start_col).value = "SHIPPING SERVICE SUMMARY"
        ws.cell(row=1, column=start_col).font = Font(bold=True, size=12, color="0000FF")
        headers_s = ["Service", "Total Qty", "Total Cost"]
        for i, h in enumerate(headers_s):
            cell = ws.cell(row=2, column=start_col + i)
            cell.value = h
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color="FFD9EAD3", end_color="FFD9EAD3", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")

        ship_summary = (
            final_df.groupby("Service").agg({"Quantity": "sum", "Total": "sum"}).reset_index()
        )
        ship_summary["Total"] = ship_summary["Total"].round(2)
        for r_idx, row_vals in enumerate(ship_summary.values, start=3):
            for c_idx, val in enumerate(row_vals):
                ws.cell(row=r_idx, column=start_col + c_idx).value = val

        last_row = 3 + len(ship_summary)
        ws.cell(row=last_row, column=start_col).value = "Total"
        ws.cell(row=last_row, column=start_col).font = Font(bold=True)
        ws.cell(row=last_row, column=start_col + 1).value = int(
            ship_summary["Quantity"].sum()
        )
        ws.cell(row=last_row, column=start_col + 1).font = Font(bold=True)
        ws.cell(row=last_row, column=start_col + 2).value = round(
            ship_summary["Total"].sum(), 2
        )
        ws.cell(row=last_row, column=start_col + 2).font = Font(bold=True)

        extra_labels = [
            lbl
            for lbl in final_df["PivotLabel"].unique()
            if lbl not in {_pivot_label(d) for d in sorted_dates}
        ]
        month_order = {
            name: i
            for i, name in enumerate(
                [
                    "January",
                    "February",
                    "March",
                    "April",
                    "May",
                    "June",
                    "July",
                    "August",
                    "September",
                    "October",
                    "November",
                    "December",
                ]
            )
        }
        extra_labels.sort(
            key=lambda lbl: (
                month_order.get(lbl, 99),
                lbl,
            )
        )
        pivot_cols = [_pivot_label(d) for d in sorted_dates] + extra_labels
        pivot_ship = pd.pivot_table(
            final_df,
            values="Quantity",
            index="Service",
            columns="PivotLabel",
            aggfunc="sum",
            fill_value=0,
        )
        pivot_ship = pivot_ship.reindex(columns=[c for c in pivot_cols if c in pivot_ship.columns])

        pivot_row = len(ship_summary) + 6
        ws.cell(row=pivot_row, column=start_col).value = "SHIPPING BY DATE (QTY)"
        ws.cell(row=pivot_row, column=start_col).font = Font(bold=True, size=12, color="0000FF")
        ws.cell(row=pivot_row + 1, column=start_col).value = "Service"
        ws.cell(row=pivot_row + 1, column=start_col).font = Font(bold=True)
        for c_idx, col_name in enumerate(pivot_ship.columns, start=1):
            cell = ws.cell(row=pivot_row + 1, column=start_col + c_idx)
            cell.value = col_name
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color="FFF2DCDB", end_color="FFF2DCDB", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")

        for r_idx, (svc, row_data) in enumerate(pivot_ship.iterrows(), start=pivot_row + 2):
            ws.cell(row=r_idx, column=start_col).value = svc
            for c_idx, val in enumerate(row_data, start=1):
                ws.cell(row=r_idx, column=start_col + c_idx).value = val if val != 0 else ""

        stats_start_row = 20
        ws.cell(row=stats_start_row, column=start_col).value = "GENERAL SHIPPING STATS"
        ws.cell(row=stats_start_row, column=start_col).font = Font(
            bold=True, size=12, color="0000FF"
        )
        stats_data = [
            ["Total Orders", total_orders],
            ["Total Line Items", total_line_items],
            ["Total Line Items Qty", total_line_items_qty],
            ["Shipping Orders Counted", shipping_qty],
            ["Shipping Total Cost", shipping_total],
        ]
        for i, h in enumerate(["Metric", "Value"]):
            cell = ws.cell(row=stats_start_row + 1, column=start_col + i)
            cell.value = h
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color="FFCFE2F3", end_color="FFCFE2F3", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")
        for r_idx, row_vals in enumerate(stats_data, start=stats_start_row + 2):
            for c_idx, val in enumerate(row_vals):
                ws.cell(row=r_idx, column=start_col + c_idx).value = val

        ws.column_dimensions["H"].width = 30
        note_cell = ws.cell(row=28, column=1)
        note_cell.value = shipping_note
        note_cell.font = Font(italic=True, color="666666")

        wb.save(cfg.orders_workbook)
        print("Shipping sheet saved.")
    except Exception as e:
        print(f"Error writing Shipping sheet: {e}")


MENS_BIG_SIZE_TOKENS = frozenset({"3XL", "4XL", "5XL"})
SIZE_TOKEN_ORDER = (
    "5XL",
    "4XL",
    "3XL",
    "2XL",
    "XXL",
    "XL",
    "YXS",
    "YS",
    "YM",
    "YL",
    "XS",
    "S",
    "M",
    "L",
)


def _extract_size_token(size="", sku="", options=""):
    """
    Canonical size token from SKU suffix, Item - Options, or product Size.
    Uses whole-token matching (avoids '3XL' matching inside unrelated strings).
    """
    sku_u = str(sku).upper()
    for part in reversed(sku_u.split("-")):
        cleaned = re.sub(r"[^A-Z0-9]", "", part)
        if cleaned in SIZE_TOKEN_ORDER:
            return cleaned
        for token in SIZE_TOKEN_ORDER:
            if cleaned.endswith(token) and cleaned != token:
                return token
            if cleaned.startswith(token) and len(cleaned) > len(token):
                suffix = cleaned[len(token) :]
                if suffix in ("YES", "NO", "Y", "N") or len(suffix) <= 3:
                    return token

    opts = str(options).upper()
    m = re.search(r"SIZE:\s*([^,]+)", opts, re.I)
    if m:
        chunk = re.sub(r"[^A-Z0-9]", "", m.group(1).upper())
        for token in SIZE_TOKEN_ORDER:
            if chunk == token or chunk.endswith(token):
                return token

    size_u = re.sub(r"[^A-Z0-9]", "", str(size).upper())
    if size_u:
        for token in SIZE_TOKEN_ORDER:
            if size_u == token:
                return token
    return ""


def _is_mens_big_size(size="", sku="", options=""):
    return _extract_size_token(size, sku, options) in MENS_BIG_SIZE_TOKENS


def _apparel_unit_cost(gender_apparel, size, sku="", options=""):
    ga = str(gender_apparel).strip()
    if not ga or ga.lower() == "nan":
        return 0.0
    ga_u = ga.upper().replace(" ", "-")

    if "ONLY-DESIGN" in ga_u or ga == "Only-Design":
        return APPAREL_PRICES["ONLY-DESIGN"]
    if "KIDS" in ga_u:
        return APPAREL_PRICES["KIDS-T-SHIRT"]
    if "WOMEN" in ga_u:
        return APPAREL_PRICES["WOMENS-T-SHIRT"]
    if "MEN" in ga_u:
        if _is_mens_big_size(size, sku, options):
            return APPAREL_PRICES["MENS-T-SHIRT-BIG"]
        return APPAREL_PRICES["MENS-T-SHIRT"]
    return 0.0


def generate_gender_apparel_sheet():
    print("Generating Gender Apparel sheet...")
    orders_path = orders_workbook_path()
    print(f"  Source workbook: {orders_path}")
    print(f"  Orders sheet: {ORDERS_SHEET}")
    try:
        orders_df = pd.read_excel(orders_path, sheet_name=ORDERS_SHEET)
        products_db = pd.read_excel(
            os.path.join(os.path.dirname(orders_path), PRODUCTS_FILE),
            sheet_name=PRODUCTS_SHEET,
        )
        products_dict = products_db.set_index("Custom Label").to_dict("index")
        print(
            f"  Orders loaded: {len(orders_df)} line items, "
            f"{orders_df['Order - Number'].nunique()} unique orders, "
            f"qty {int(orders_df['Item - Qty'].sum())}"
        )
    except Exception as e:
        print(f"Error loading Gender Apparel inputs: {e}")
        return

    results = []
    for _, row in orders_df.iterrows():
        sku = str(row.get("Item - SKU", ""))
        if sku in ("", "nan"):
            continue

        parts = sku.split("-", 1)
        custom_label = parts[1] if len(parts) > 1 else sku
        prod = products_dict.get(custom_label, {})

        gender_apparel = prod.get("Gender Apparel", "")
        size = prod.get("Size", "")
        position = prod.get("Position", "")
        customize = prod.get("Customise", prod.get("Customize", ""))
        qty = row.get("Item - Qty", 1)
        if pd.isna(qty):
            qty = 1

        options = row.get("Item - Options", "")
        unit = _apparel_unit_cost(gender_apparel, size, sku=sku, options=options)
        results.append(
            {
                "Item-Sku": sku,
                "Custom Label": custom_label,
                "Gender Apparel": gender_apparel,
                "Size": size,
                "Position": position,
                "Customize": customize,
                "Item - Options": options,
                "Quantity": qty,
                "Cost": round(unit, 2),
                "Total": round(float(qty) * unit, 2),
            }
        )

    final_df = pd.DataFrame(results).fillna("")

    try:
        wb = openpyxl.load_workbook(orders_path)
        if "Gender Apparel" in wb.sheetnames:
            wb.remove(wb["Gender Apparel"])
        ws = wb.create_sheet("Gender Apparel", 2)

        export_cols = [c for c in final_df.columns if c != "Item - Options"]
        ws.append(export_cols)
        for cell in ws[1]:
            cell.font = Font(bold=True)
        for _, row in final_df.iterrows():
            ws.append(
                [
                    "" if pd.isna(v) or str(v).lower() == "nan" else v
                    for c, v in row.items()
                    if c != "Item - Options"
                ]
            )

        start_col = 13  # M
        total_orders = orders_df["Order - Number"].nunique()
        total_line_items = len(orders_df)
        total_line_items_qty = int(orders_df["Item - Qty"].sum())

        def summary_group(row):
            ga = str(row["Gender Apparel"])
            if "MENS-T-SHIRT" in ga.upper():
                if _is_mens_big_size(
                    row.get("Size", ""),
                    sku=str(row.get("Item-Sku", "")),
                    options=str(row.get("Item - Options", "")),
                ):
                    return "Mens-T-Shirt(3XL to 5XL)"
            return ga

        df_sum = final_df[final_df["Gender Apparel"].astype(str).str.strip() != ""].copy()
        df_sum["Summary Group"] = df_sum.apply(summary_group, axis=1)
        summary = (
            df_sum.groupby("Summary Group")
            .agg({"Quantity": "sum", "Total": "sum"})
            .reset_index()
        )
        summary["Cost Per Item"] = (summary["Total"] / summary["Quantity"]).round(2)
        summary["Total"] = summary["Total"].round(2)
        summary = summary[
            ["Summary Group", "Cost Per Item", "Quantity", "Total"]
        ]

        apparel_total = round(summary["Total"].sum(), 2)
        apparel_qty = int(summary["Quantity"].sum())
        print(f"  Gender Apparel: {apparel_qty} qty, £{apparel_total:,.2f}")

        ws.cell(row=1, column=start_col).value = "OVERALL SUMMARY"
        ws.cell(row=1, column=start_col).font = Font(bold=True, size=12, color="0000FF")
        for i, h in enumerate(
            ["Gender Apparel", "Cost Per Item", "Total Qty", "Total Cost"]
        ):
            cell = ws.cell(row=2, column=start_col + i)
            cell.value = h
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color="FFD9EAD3", end_color="FFD9EAD3", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")

        for r_idx, row_vals in enumerate(summary.values, start=3):
            for c_idx, val in enumerate(row_vals):
                ws.cell(row=r_idx, column=start_col + c_idx).value = val

        last_row = 3 + len(summary)
        ws.cell(row=last_row, column=start_col).value = "Total"
        ws.cell(row=last_row, column=start_col).font = Font(bold=True)
        ws.cell(row=last_row, column=start_col + 2).value = apparel_qty
        ws.cell(row=last_row, column=start_col + 2).font = Font(bold=True)
        ws.cell(row=last_row, column=start_col + 3).value = apparel_total
        ws.cell(row=last_row, column=start_col + 3).font = Font(bold=True)

        pivot_size = pd.pivot_table(
            final_df[final_df["Gender Apparel"].astype(str).str.strip() != ""],
            values="Quantity",
            index="Gender Apparel",
            columns="Size",
            aggfunc="sum",
            fill_value=0,
        )
        pivot_row = len(summary) + 6
        ws.cell(row=pivot_row, column=start_col).value = "SIZE BREAKDOWN (QTY)"
        ws.cell(row=pivot_row, column=start_col).font = Font(
            bold=True, size=12, color="0000FF"
        )
        ws.cell(row=pivot_row + 1, column=start_col).value = "Gender Apparel"
        ws.cell(row=pivot_row + 1, column=start_col).font = Font(bold=True)
        for c_idx, size_name in enumerate(pivot_size.columns, start=1):
            cell = ws.cell(row=pivot_row + 1, column=start_col + c_idx)
            cell.value = (
                ""
                if str(size_name).lower() in ("nan", "")
                else size_name
            )
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color="FFF2DCDB", end_color="FFF2DCDB", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")

        for r_idx, (name, row_data) in enumerate(
            pivot_size.iterrows(), start=pivot_row + 2
        ):
            ws.cell(row=r_idx, column=start_col).value = name
            for c_idx, val in enumerate(row_data, start=1):
                ws.cell(row=r_idx, column=start_col + c_idx).value = (
                    val if val != 0 else ""
                )

        stats_start_row = 16
        ws.cell(row=stats_start_row, column=start_col).value = "GENERAL APPAREL STATS"
        ws.cell(row=stats_start_row, column=start_col).font = Font(
            bold=True, size=12, color="0000FF"
        )
        for i, h in enumerate(["Metric", "Value"]):
            cell = ws.cell(row=stats_start_row + 1, column=start_col + i)
            cell.value = h
            cell.font = Font(bold=True)
            cell.fill = PatternFill(
                start_color="FFCFE2F3", end_color="FFCFE2F3", fill_type="solid"
            )
            cell.alignment = Alignment(horizontal="center")
        for r_idx, row_vals in enumerate(
            [
                ["Total Orders", total_orders],
                ["Total Line Items", total_line_items],
                ["Total Line Items Qty", total_line_items_qty],
            ],
            start=stats_start_row + 2,
        ):
            for c_idx, val in enumerate(row_vals):
                ws.cell(row=r_idx, column=start_col + c_idx).value = val

        ws.column_dimensions["M"].width = 25
        wb.save(orders_path)
        print(f"Gender Apparel sheet saved to {orders_path}")
    except Exception as e:
        print(f"Error writing Gender Apparel sheet: {e}")


def _read_shipping_total_from_workbook(orders_path):
    """Read Shipping Total Cost from the 2026 Shipping sheet stats table."""
    raw = pd.read_excel(orders_path, sheet_name="Shipping", header=None)
    for idx in range(len(raw)):
        for col in range(len(raw.columns)):
            val = raw.iloc[idx, col]
            if str(val).strip() == "Shipping Total Cost":
                if col + 1 < len(raw.columns):
                    return round(float(raw.iloc[idx, col + 1]), 2)
    ship_df = pd.read_excel(orders_path, sheet_name="Shipping")
    lines = ship_df[ship_df["Carrier - Service Selected"].notna()].copy()
    return round(pd.to_numeric(lines["Total"], errors="coerce").sum(), 2)


def _read_gender_summary_from_workbook(orders_path):
    """Read OVERALL SUMMARY Total row from the 2026 Gender Apparel sheet (col M)."""
    raw = pd.read_excel(orders_path, sheet_name="Gender Apparel", header=None)
    col_label = 12  # column M
    for idx in range(len(raw)):
        if str(raw.iloc[idx, col_label]).strip() == "Total":
            qty = raw.iloc[idx, col_label + 2]
            cost = raw.iloc[idx, col_label + 3]
            return int(qty), round(float(cost), 2)
    ga_df = pd.read_excel(orders_path, sheet_name="Gender Apparel")
    lines = ga_df[ga_df["Item-Sku"].notna()].copy()
    lines = lines[~lines["Item-Sku"].astype(str).str.upper().eq("ITEM-SKU")]
    return int(lines["Quantity"].sum()), round(
        pd.to_numeric(lines["Total"], errors="coerce").sum(), 2
    )


def generate_totals_sheet():
    print("Generating Totals sheet...")
    orders_path = orders_workbook_path()
    print(f"  Source workbook: {orders_path}")
    try:
        orders_df = pd.read_excel(orders_path, sheet_name=ORDERS_SHEET)
        products_db = pd.read_excel(
            os.path.join(os.path.dirname(orders_path), PRODUCTS_FILE),
            sheet_name=PRODUCTS_SHEET,
        )
        products_dict = products_db.set_index("Custom Label").to_dict("index")
    except Exception as e:
        print(f"Error loading Totals inputs: {e}")
        return

    def extra_positions(position_str):
        if not isinstance(position_str, str) or not position_str.strip():
            return 0
        parts = [p.strip() for p in position_str.split(",") if p.strip()]
        return max(0, len(parts) - 1)

    total_extra_positions = 0

    for _, row in orders_df.iterrows():
        sku = str(row.get("Item - SKU", ""))
        if sku in ("", "nan"):
            continue
        custom_label = sku.split("-", 1)[1] if "-" in sku else sku
        prod = products_dict.get(custom_label, {})
        position = str(prod.get("Position", ""))
        qty = row.get("Item - Qty", 0) or 0

        extra = extra_positions(position)
        if extra > 0:
            total_extra_positions += qty * extra

    try:
        shipping_total = _read_shipping_total_from_workbook(orders_path)
        total_apparel_qty, gender_total = _read_gender_summary_from_workbook(orders_path)
        print(
            f"  From workbook — Shipping: £{shipping_total:,.2f}, "
            f"Gender Apparel: £{gender_total:,.2f}, Qty: {total_apparel_qty}"
        )

        wb = openpyxl.load_workbook(orders_path)
        if "Totals" in wb.sheetnames:
            wb.remove(wb["Totals"])
        ws = wb.create_sheet("Totals", len(wb.sheetnames))

        ws.append(["Category", "Total Value"])
        header_fill = PatternFill(
            start_color="4F81BD", end_color="4F81BD", fill_type="solid"
        )
        header_font = Font(color="FFFFFF", bold=True)
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center")

        ws.append(["Shipping", shipping_total])
        ws.append(["Gender Apparel", gender_total])
        ws.append(["Positions", total_extra_positions])
        ws.append(["Operations Cost", EXPECTED["operations_cost"]])
        ws.append(["Position Cost", EXPECTED["position_cost"]])
        ws.append(["Gender Apparel Qty", total_apparel_qty])
        ws.cell(row=8, column=1, value="Grand Total")
        ws.cell(row=8, column=1).font = Font(bold=True)
        grand_cell = ws.cell(row=8, column=2)
        grand_cell.value = "=B2+B3+B4*B6+B7*B5"
        grand_cell.data_type = "f"
        grand_cell.number_format = "General"
        grand_cell.font = Font(bold=True)

        ws.column_dimensions["A"].width = 25
        ws.column_dimensions["B"].width = 20
        wb.save(orders_path)
        print(
            f"Totals sheet saved to {orders_path}. "
            f"Shipping £{shipping_total:,.2f}, Gender Apparel £{gender_total:,.2f}, "
            f"Qty {total_apparel_qty}"
        )
    except Exception as e:
        print(f"Error writing Totals sheet: {e}")


def apply_reference_layout():
    """Copy column widths from prior-year reference sheets when available."""
    cfg = _require_cfg()
    ref_path = _reference_workbook_for_year(cfg.report_year)
    if not ref_path or not os.path.isfile(ref_path):
        return
    try:
        ref_wb = openpyxl.load_workbook(ref_path)
        out_wb = openpyxl.load_workbook(cfg.orders_workbook)
        for name in ("Shipping", "Gender Apparel", "Totals", ORDERS_SHEET):
            if name not in ref_wb.sheetnames or name not in out_wb.sheetnames:
                continue
            ref_ws = ref_wb[name]
            out_ws = out_wb[name]
            for col, dim in ref_ws.column_dimensions.items():
                if dim.width:
                    out_ws.column_dimensions[col].width = dim.width
        out_wb.save(cfg.orders_workbook)
        ref_wb.close()
        print(f"Applied column widths from {os.path.basename(ref_path)}.")
    except Exception as e:
        print(f"Note: could not copy reference layout ({e}).")


def enforce_sheet_order():
    cfg = _require_cfg()
    target = [ORDERS_SHEET, "Shipping", "Gender Apparel", "Totals"]
    wb = openpyxl.load_workbook(cfg.orders_workbook)
    ordered = [wb[n] for n in target if n in wb.sheetnames]
    for n in wb.sheetnames:
        if n not in target:
            ordered.append(wb[n])
    wb._sheets = ordered
    wb.save(cfg.orders_workbook)
    print("Sheet order:", wb.sheetnames)


def validate_results():
    print("\n" + "=" * 60)
    print("VALIDATION")
    print("=" * 60)
    ok = True

    orders_path = orders_workbook_path()
    orders = pd.read_excel(orders_path, sheet_name=ORDERS_SHEET)
    n_lines = len(orders)
    n_orders = orders["Order - Number"].nunique()
    n_qty = int(orders["Item - Qty"].sum())

    checks = [
        ("Line items", n_lines, EXPECTED["line_items"]),
        ("Unique orders", n_orders, EXPECTED["unique_orders"]),
        ("Line items qty", n_qty, EXPECTED["line_qty"]),
    ]
    for label, got, want in checks:
        match = got == want
        ok = ok and match
        print(f"  {label}: {got} (expected {want}) {'OK' if match else 'MISMATCH'}")

    ship = pd.read_excel(orders_path, sheet_name="Shipping")
    ship_lines = ship[ship["Carrier - Service Selected"].notna()].copy()
    ship_total = round(pd.to_numeric(ship_lines["Total"], errors="coerce").sum(), 2)
    ship_qty = int(pd.to_numeric(ship_lines["Quantity"], errors="coerce").sum())
    match_ship = abs(ship_total - EXPECTED["shipping_total"]) < 0.02
    match_cnt = ship_qty == EXPECTED["shipping_orders"]
    ok = ok and match_ship and match_cnt
    print(
        f"  Shipping total: £{ship_total:,.2f} (expected £{EXPECTED['shipping_total']:,.2f}) "
        f"{'OK' if match_ship else 'MISMATCH'}"
    )
    print(
        f"  Shipping orders counted: {ship_qty} (expected {EXPECTED['shipping_orders']}) "
        f"{'OK' if match_cnt else 'MISMATCH'}"
    )

    ga_qty, ga_total = _read_gender_summary_from_workbook(orders_path)

    match_ga = abs(ga_total - EXPECTED["apparel_total"]) < 0.02
    match_gq = ga_qty == EXPECTED["apparel_qty"]
    ok = ok and match_ga and match_gq
    print(
        f"  Gender Apparel total: £{ga_total:,.2f} (expected £{EXPECTED['apparel_total']:,.2f}) "
        f"{'OK' if match_ga else 'MISMATCH'}"
    )
    print(
        f"  Gender Apparel summary qty: {ga_qty} (expected {EXPECTED['apparel_qty']}) "
        f"{'OK' if match_gq else 'MISMATCH'}"
    )

    totals = pd.read_excel(orders_path, sheet_name="Totals")
    print("  Totals sheet:")
    totals_map = {}
    for _, r in totals.iterrows():
        totals_map[str(r.iloc[0])] = r.iloc[1]
        print(f"    {r.iloc[0]}: {r.iloc[1]}")

    grand = round(
        float(totals_map.get("Shipping", ship_total))
        + float(totals_map.get("Gender Apparel", ga_total))
        + float(totals_map.get("Positions", 0)) * EXPECTED["position_cost"]
        + float(totals_map.get("Gender Apparel Qty", ga_qty)) * EXPECTED["operations_cost"],
        2,
    )
    match_grand = abs(grand - EXPECTED["grand_total"]) < 0.02
    ok = ok and match_grand
    print(
        f"  Grand Total (computed): £{grand:,.2f} "
        f"(expected £{EXPECTED['grand_total']:,.2f}) "
        f"{'OK' if match_grand else 'MISMATCH'}"
    )

    print("=" * 60)
    if ok:
        print("ALL CHECKS PASSED")
    else:
        print("SOME CHECKS FAILED — review output above")
    print("=" * 60 + "\n")
    return ok


def print_run_summary():
    """Final summary of files used and totals."""
    cfg = _require_cfg()
    orders_path = cfg.orders_workbook_path
    try:
        ship_total = _read_shipping_total_from_workbook(orders_path)
        ga_qty, ga_total = _read_gender_summary_from_workbook(orders_path)
        totals = pd.read_excel(orders_path, sheet_name="Totals")
        totals_map = {str(r.iloc[0]): r.iloc[1] for _, r in totals.iterrows()}
        positions = float(totals_map.get("Positions", 0))
        grand = round(
            ship_total
            + ga_total
            + positions * EXPECTED["position_cost"]
            + ga_qty * EXPECTED["operations_cost"],
            2,
        )
        n_orders = pd.read_excel(orders_path, sheet_name=ORDERS_SHEET)[
            "Order - Number"
        ].nunique()
    except Exception as e:
        print(f"Could not build run summary: {e}")
        return

    print("\n" + "=" * 60)
    print("RUN SUMMARY")
    print("=" * 60)
    print(f"  Orders CSV:        {cfg.orders_csv_name}")
    print(f"  Calculator file:   {cfg.calculator_name}")
    print(f"  Output workbook:   {cfg.orders_workbook}")
    print(
        f"  Order date range:  {cfg.orders_date_min.strftime('%Y-%m-%d')} "
        f"to {cfg.orders_date_max.strftime('%Y-%m-%d')}"
    )
    print(f"  Total orders:      {n_orders}")
    print(f"  Shipping total:    £{ship_total:,.2f}")
    print(f"  Gender Apparel:    £{ga_total:,.2f}")
    print(f"  Grand Total:       £{grand:,.2f}")
    print("=" * 60 + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skip-csv-import",
        action="store_true",
        help="Skip CSV import; refresh summary sheets only.",
    )
    parser.add_argument(
        "--skip-shipping",
        action="store_true",
        help="Do not regenerate Shipping sheet (Gender Apparel + Totals only).",
    )
    args = parser.parse_args()

    base = _base_dir()
    os.chdir(base)
    print(f"Working directory: {base}\n")

    init_run_config(base)
    cfg = _require_cfg()
    print(f"Auto-detected orders CSV: {cfg.orders_csv_name}")
    print(f"Auto-detected calculator: {cfg.calculator_name}")
    print(f"Output workbook: {cfg.orders_workbook} (year {cfg.report_year})\n")

    assert_workbook_writable()

    if args.skip_csv_import:
        if not os.path.isfile(cfg.orders_workbook_path):
            print(f"ERROR: {cfg.orders_workbook} not found.")
            raise SystemExit(1)
        print(f"Skipping CSV import; using existing {cfg.orders_workbook}")
    else:
        import_orders_csv()

    if not args.skip_shipping:
        generate_shipping_summary()
    else:
        print("Skipping Shipping sheet (--skip-shipping).")
    generate_gender_apparel_sheet()
    generate_totals_sheet()
    enforce_sheet_order()
    apply_reference_layout()
    validate_results()
    print_run_summary()


if __name__ == "__main__":
    main()
