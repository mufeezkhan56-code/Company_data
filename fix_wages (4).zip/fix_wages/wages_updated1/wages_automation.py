#!/usr/bin/env python3
"""WhatsApp attendance → UK Wages Excel automation (June 2026+)."""

# PERMANENT RULES — follow every time without exception:
#
# Script sirf yeh kare:
# - Nayi chat entries padhna
# - Sahi week mein sahi detail row par Time In aur Time Out likhna
# - Sahi day column link karna =U{detail_row}
# - Naya worker aaye to uski row add karna — existing workers ke baad, Total row se pehle
#
# Script kabhi yeh na kare:
# - Koi bhi existing employee row delete karna (remove_zero_hour_workers call mat karo)
# - Header, date, Employee Name ya Total rows par kuch likhna
# - Existing formulas ya formatting badalna
# - Layout ya structure change karna
#
# Additional rules:
# - Always backup the Excel file before any change
# - Never change existing formulas — only add where missing
# - Franklin always has empty Break Hours — never add break for him
# - Kennedy is a normal worker — same 5 min/hour break rule as everyone else
# - Break rule = 5 minutes per hour worked expressed as hh:mm:ss
# - No break rule — if worker says not break taken / no break / without break on
#   that day, add 5 min/hour break salary to Total Salary for that day only
# - If message does not mention break, assume break was taken (normal day)
# - Break is calculated per day — check each day separately, not the whole week as one block
# - New month sheets must copy exact format from previous month
# - Whenever any cell is written in a monthly sheet, copy number format and styling
#   from the corresponding cell in 05-May-26 so formatting never drifts
# - Never add duplicate entries — check before inserting
# - If anything is unclear — ask before changing anything

from __future__ import annotations

import calendar
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Optional

from copy import copy

import openpyxl
from openpyxl.cell.cell import MergedCell
from openpyxl.styles import Alignment, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

BASE_DIR = Path(__file__).resolve().parent
EXCEL_FILE = BASE_DIR / "03-UK Wages 2025 (2).xlsx"
BACKUP_FILE = BASE_DIR / "03-UK Wages 2025 (2) - backup.xlsx"
CHAT_FILE = BASE_DIR / "WhatsApp Chat with Daily check in and out.txt"
SKIPPED_FILE = BASE_DIR / "skipped_entries.txt"
NEW_WORKERS_FILE = BASE_DIR / "new_workers_added.txt"
TEMPLATE_SHEET = "05-May-26"
MONTH_TEMPLATE_SHEET = "00-Month-Template"
WORKERS_PER_WEEK = 20
DETAIL_SLOTS_PER_WEEK = 140
TEMPLATE_ROSTER: list[str] = [
    "Jeannine (D-02)",
    "Beatrice (D-01)",
    "Flamme (D-14)",
    "Franklin",
    "Mamakisi",
    "Felix",
    "Hanna(D-09)",
    "Jenifer",
    "Kennedy",
    "Chadrack(D-20)",
]
TEMPLATE_DETAIL_ROW = 2  # first detail-log row in May week 1 (cols P-AA)
TEMPLATE_NORMAL_EMPLOYEE_ROW = 6  # Jeannine — default style for new workers
TEMPLATE_FRANKLIN_ROW = 9
DETAIL_HEADER_ROW = 1
DETAIL_LOG_FIRST_COL = 16  # P
DETAIL_LOG_LAST_COL = 27  # AA
EMPLOYEE_GRID_LAST_COL = 15  # O — main worker grid ends here
FRANKLIN_NAME = "Franklin"
NO_FILL = PatternFill(fill_type=None)
WEEK_LABEL_COL = 28  # AB
WEEK_SUMMARY_AE_ROWS = [2, 3, 4, 6, 7]  # May layout for Week Colors / Salary Sent
WEEK_SUMMARY_AF_COL = 32  # AF
WEEK_SUMMARY_AE_COL = 31  # AE
CUTOFF_DATE = date(2026, 6, 1)

DAY_COLS = list(range(2, 9))  # B-H
DAY_HOURS_FORMAT = "h:mm:ss;@"
DETAIL_HOURS_FORMAT = "h:mm:ss;@"
DETAIL_COLS = {
    "date": 16,  # P
    "day": 17,  # Q
    "name": 18,  # R
    "time_in": 19,  # S
    "time_out": 20,  # T
    "total_hours": 21,  # U
    "break": 22,  # V
    "per_hour": 23,  # W
    "salary": 24,  # X
    "bonus": 25,  # Y
    "deduction": 26,  # Z
    "total_salary": 27,  # AA
}

IGNORE_SENDERS = {"Sandy", "Bright Uk"}
PHONE_SENDER_RE = re.compile(r"^\+?\d[\d\s-]{6,}$")
FLAMME_PHONE_RE = re.compile(r"\+?44\s*7947\s*333490")
SISTER_01_SENDER_RE = re.compile(r"sister\s*01", re.I)

MANAGER_SENDER_RE = re.compile(r"jeaninne|jeannine", re.I)

WORKER_ALIASES: dict[str, str] = {
    "chadrac": "Chadrack",
    "chadrack": "Chadrack",
    "janifer": "Jenifer",
    "jennifer": "Jenifer",
    "maman": "Maman",
    "esther": "Maman",
    "nwokeocha": "Maman",
    "mamakissi": "Mamakisi",
    "mamakisi": "Mamakisi",
    "mamakissitoure": "Mamakisi",
    "jeaninne": "Jeannine",
    "jeannine": "Jeannine",
    "flamme": "Flamme",
    "frank": "Franklin",
    "sister": "Beatrice",
    "sist": "Beatrice",
}

# Authoritative final map: every known spelling of a person -> ONE canonical short.
# Applied as the LAST step of canonical_worker_short so one person = one row/name
# everywhere (employee rows, detail rows, day-cell links, Employee_Master VLOOKUP).
CANONICAL_SHORTS: dict[str, str] = {
    "chadrac": "Chadrack",
    "chadrack": "Chadrack",
    "jennifer": "Jennifer",
    "jenifer": "Jennifer",
    "janifer": "Jennifer",
    "mamakissi": "Mamakisi",
    "mamakisi": "Mamakisi",
    "mamakissitoure": "Mamakisi",
    "maman": "Maman",
    "esther": "Maman",
    "nwokeocha": "Maman",
    "jeannine": "Jeannine",
    "jeaninne": "Jeannine",
    "frank": "Franklin",
    "franklin": "Franklin",
    "franklinob": "Franklin",
    "hanna": "Hanna",
    "hannah": "Hanna",
}


def apply_canonical_short(short: Optional[str]) -> Optional[str]:
    """Collapse any known spelling variant to its single canonical short name."""
    if not short:
        return short
    key = re.sub(r"[^a-z]", "", str(short).lower())
    return CANONICAL_SHORTS.get(key, short)

NAME_IGNORE_WORDS = {
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday",
    "January", "February", "March", "April", "May", "June", "July", "August",
    "September", "October", "November", "December",
    "Not", "Break", "Taken", "Complete", "Without", "Sister", "SiSter",
    "Out", "In", "Start", "Started", "Hours", "Minutes", "Jeaninne", "Jeannine",
    "You", "Taken", "Janice",
}

INVALID_WORKER_SHORTS = {
    "taken", "break", "not", "you", "pm", "am", "out", "in", "complete",
    "without", "sister", "sist", "international", "basit", "janice", "oit",
}

SYSTEM_MESSAGE_RE = re.compile(
    r"^You (?:added|removed|turned|deleted|created)|"
    r"^You're now|"
    r"Messages to this chat",
    re.I,
)

NO_BREAK_RE = re.compile(
    r"n[o0]t?\s*br[ae][ae]?k|no\s*break|without\s*break|complete\s*without\s*break|notbrak|brak\s*raken|break\s*tak",
    re.I,
)

MSG_RE = re.compile(
    r"^(\d{1,2}/\d{1,2}/\d{4}),\s*(\d{1,2}:\d{2})(?:\s*[\u202f\u00a0 ]*(am|pm))?\s*-\s*(.+?):\s*(.*)$",
    re.I,
)

MONTH_SHEET_RE = re.compile(r"^(\d{2})-([A-Za-z]+)-(\d{2})$")


@dataclass
class AttendanceRecord:
    worker: str  # short name
    work_date: date
    time_in: Optional[time] = None
    time_out: Optional[time] = None
    no_break: bool = False
    source: str = ""
    sender: str = ""
    date_explicit: bool = False
    message_time: Optional[datetime] = None


@dataclass
class WorkerProfile:
    excel_name: str
    short_name: str
    bank_name: Optional[str] = None
    hourly_rate: Optional[float] = None
    empty_break_hours: bool = False


@dataclass
class WorkerRegistry:
    short_to_excel: dict[str, str] = field(default_factory=dict)
    excel_to_short: dict[str, str] = field(default_factory=dict)
    profiles: dict[str, WorkerProfile] = field(default_factory=dict)

    def short_for(self, excel_name: str) -> str:
        return self.excel_to_short.get(excel_name, default_short_name(excel_name))

    def excel_for(self, short_name: str) -> Optional[str]:
        if short_name in self.short_to_excel:
            return self.short_to_excel[short_name]
        for known_short, excel_name in self.short_to_excel.items():
            if worker_names_match(short_name, known_short):
                return excel_name
        return None

    def profile_for(self, short_name: str) -> Optional[WorkerProfile]:
        excel_name = self.excel_for(short_name)
        if excel_name and excel_name in self.profiles:
            return self.profiles[excel_name]
        for profile in self.profiles.values():
            if worker_names_match(short_name, profile.short_name):
                return profile
        return None

    def short_names(self) -> list[str]:
        return list(self.short_to_excel.keys())

    def register(self, profile: WorkerProfile) -> None:
        self.profiles[profile.excel_name] = profile
        self.short_to_excel[profile.short_name] = profile.excel_name
        self.excel_to_short[profile.excel_name] = profile.short_name
        if profile.short_name != default_short_name(profile.excel_name):
            alt = default_short_name(profile.excel_name)
            self.short_to_excel.setdefault(alt, profile.excel_name)


@dataclass
class WeekSection:
    header_row: int
    end_row: int
    title: str
    date_row: int
    employee_header_row: int
    total_row: int
    employee_rows: dict[str, int]  # excel name -> row
    dates: dict[int, date]  # col -> date


@dataclass
class MonthStats:
    added: int = 0
    skipped: int = 0


@dataclass
class Stats:
    added: int = 0
    skipped: int = 0
    updated_sheets: set[str] = field(default_factory=set)
    created_sheets: set[str] = field(default_factory=set)
    skip_log: list[str] = field(default_factory=list)
    new_workers: list[str] = field(default_factory=list)
    auto_added_workers: set[str] = field(default_factory=set)
    month_stats: dict[tuple[int, int], MonthStats] = field(default_factory=dict)


@dataclass
class WeekLoad:
    start: date
    end: date
    entry_count: int
    worker_shorts: set[str] = field(default_factory=set)


@dataclass
class MonthLoad:
    year: int
    month: int
    weeks: list[WeekLoad] = field(default_factory=list)


DETAIL_SLOT_BUFFER = 2

SKIP_MONTH_WORK_DATE_RE = re.compile(r"\b\w[\w ]*\s+(20\d{2})-(\d{2})-\d{2}\b")
SKIP_MONTH_ANY_DATE_RE = re.compile(r"(20\d{2})-(\d{2})-\d{2}")


def month_stats_for(stats: Stats, year: int, month: int) -> MonthStats:
    key = (year, month)
    if key not in stats.month_stats:
        stats.month_stats[key] = MonthStats()
    return stats.month_stats[key]


def skip_month_key(text: str) -> Optional[tuple[int, int]]:
    """Prefer worker work-date; else first YYYY-MM-DD in skip context."""
    m = SKIP_MONTH_WORK_DATE_RE.search(text)
    if m:
        return int(m.group(1)), int(m.group(2))
    m = SKIP_MONTH_ANY_DATE_RE.search(text)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def log_skip(stats: Stats, reason: str, context: str = "") -> None:
    entry = f"{reason}"
    if context:
        entry += f" | {context}"
    stats.skip_log.append(entry)
    stats.skipped += 1
    month_key = skip_month_key(entry)
    if month_key:
        month_stats_for(stats, month_key[0], month_key[1]).skipped += 1


def sheet_name_for_date(d: date) -> str:
    month_names = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    ]
    return f"{d.month:02d}-{month_names[d.month - 1]}-{d.year % 100:02d}"


def parse_short_year(year: int) -> int:
    if year < 100:
        return 2000 + year if year < 50 else 1900 + year
    return year


def parse_date_from_text(text: str, fallback: date) -> Optional[date]:
    month_map = {m.lower(): i for i, m in enumerate(calendar.month_abbr) if m}
    month_map.update({m.lower(): i for i, m in enumerate(calendar.month_name) if m})

    comma = re.search(r"\b(\d{1,2}),(\d{1,2}),(\d{2,4})\b", text)
    if comma:
        day, month, yr = int(comma.group(1)), int(comma.group(2)), int(comma.group(3))
        year = parse_short_year(yr)
        try:
            return date(year, month, day)
        except ValueError:
            pass

    slash = re.search(r"\b(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{2,4})\b", text)
    if slash:
        a, b, yr = int(slash.group(1)), int(slash.group(2)), int(slash.group(3))
        year = parse_short_year(yr)
        for day, month in ((a, b), (b, a)):
            if 1 <= month <= 12 and 1 <= day <= 31:
                try:
                    return date(year, month, day)
                except ValueError:
                    continue

    named = re.search(
        r"\b(\d{1,2})(?:st|nd|rd|th)?[-\s]+([A-Za-z]+)[-\s]+(\d{2,4})\b",
        text,
        re.I,
    )
    if named:
        day = int(named.group(1))
        month = month_map.get(named.group(2)[:3].lower())
        year = parse_short_year(int(named.group(3)))
        if month:
            try:
                return date(year, month, day)
            except ValueError:
                pass

    named2 = re.search(
        r"\b(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)(?:,)?(?:\s+(\d{4}))?\b",
        text,
        re.I,
    )
    if named2:
        day = int(named2.group(1))
        month = month_map.get(named2.group(2)[:3].lower())
        year = int(named2.group(3)) if named2.group(3) else fallback.year
        if month:
            try:
                return date(year, month, day)
            except ValueError:
                pass

    ordinal = re.search(r"\b(\d{1,2})(?:st|nd|rd|th)\b", text, re.I)
    if ordinal:
        day = int(ordinal.group(1))
        try:
            return date(fallback.year, fallback.month, day)
        except ValueError:
            pass

    return None


def strip_dates_from_text(text: str) -> str:
    text = re.sub(r"\b\d{1,2},\d{1,2},\d{2,4}\b", " ", text)
    text = re.sub(r"\b\d{1,2}\s*/\s*\d{1,2}\s*/\s*\d{2,4}\b", " ", text)
    text = re.sub(r"\b\d{1,2}-\w+-\d{2,4}\b", " ", text)
    text = re.sub(
        r"\b\d{1,2}(?:st|nd|rd|th)?\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\b",
        " ",
        text,
        flags=re.I,
    )
    return text


def _split_hmm_time(match: re.Match[str]) -> str:
    digits = match.group(1)
    return f"{digits[0]}:{digits[1:]} {match.group(2)}"


def normalize_h_time_formats(text: str) -> str:
    """09h 00 → 09:00; 18h10, pm → 18:10 pm."""
    text = re.sub(
        r"\b(\d{1,2})h\s*(\d{2})\s*,\s*(am|pm)\b",
        r"\1:\2 \3",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"\b(\d{1,2})h\s*(\d{2})\s*(am|pm)?",
        r"\1:\2 \3",
        text,
        flags=re.I,
    )
    return text


def has_ambiguous_meridiem(text: str) -> bool:
    """Standalone m instead of am/pm, e.g. 2,30 m."""
    return bool(
        re.search(r"\b\d{1,2}\s*,\s*\d{1,2}\s+m\b", text, re.I)
        or re.search(r"\b\d{1,2}:\d{2}\s+m\b", text, re.I)
    )


def workers_mentioned_in_text(text: str, registry: WorkerRegistry) -> set[str]:
    """Count distinct workers; longer names win over prefix matches (Franklin vs Frank)."""
    mentioned: set[str] = set()
    used = [False] * len(text)
    for short in sorted(registry.short_names(), key=len, reverse=True):
        for match in re.finditer(rf"\b{re.escape(short)}\w*\b", text, re.I):
            start, end = match.span()
            if any(used[start:end]):
                continue
            for idx in range(start, end):
                used[idx] = True
            mentioned.add(short)
    return mentioned


def normalize_time_text(raw: str) -> str:
    s = raw.strip().lower()
    s = s.replace("½", "")
    s = normalize_attendance_typos(s)
    s = re.sub(r"\bt0\b", "to", s)
    # 18,,pm / 18,,,pm
    s = re.sub(r"(\d{1,2})\s*,(?:\s*,)+\s*(pm|am)\b", r"\1:00 \2", s)
    # 18,,30 pm
    s = re.sub(r"(\d{1,2})\s*,(?:\s*,)+\s*(\d{1,2})\s*(pm|am)\b", r"\1:\2 \3", s)
    s = re.sub(r"(\d{1,2}),,?\s*(pm|am)\b", r"\1:00 \2", s)
    s = re.sub(r"(\d{1,2}),(am|pm)\b", r"\1:00 \2", s)
    s = s.replace("wm", "am")
    s = re.sub(r"(\d)\s*½\s*(\d{2})", r"\2", s)
    s = re.sub(
        r"(?<![:\d])(\d{3})\s*(am|pm)\b",
        lambda m: f"{m.group(1)[0]}:{m.group(1)[1:]} {m.group(2)}",
        s,
    )
    s = re.sub(r"(?<![:\d])(\d{1,2})\s+(\d{2})\s*(pm|am)\b", r"\1:\2 \3", s)
    s = s.replace("noon", "12:00 pm").replace("midnight", "12:00 am")
    s = re.sub(r"(\d)\s*[''`]\s*(\d)", r"\1:\2", s)
    s = re.sub(r"(\d{1,2})h\s*(\d{2})\s*,\s*(am|pm)\b", r"\1:\2 \3", s)
    s = re.sub(r"(\d{1,2})h\s*(\d{2})\s*(am|pm)?", r"\1:\2 \3", s)
    s = re.sub(r"(\d{1,2})\s*[,]\s*(\d{1,2})\s*(am|pm)?", r"\1:\2 \3", s)
    s = re.sub(r"(\d{1,2})\s*[,]\s*(am|pm)\b", r"\1:00 \2", s)
    s = re.sub(r"(\d{1,2})\s+(\d{2})\s*(am|pm)", r"\1:\2 \3", s)
    s = re.sub(r"(?<![:\d])(\d{3})\s*(am|pm)\b", _split_hmm_time, s)
    s = re.sub(r"(?<![:\d])(\d{1,2})\s+(am|pm)\b", r"\1:00 \2", s)
    s = re.sub(r"(\d{1,2}):(\d{2})(am|pm)", r"\1:\2 \3", s)
    s = re.sub(r"(?<![:\d])(\d{1,2})(am|pm)", r"\1:00 \2", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def parse_time_token(token: str) -> Optional[time]:
    s = normalize_time_text(token)
    if not s or re.search(r"\b(?:sister|franklin|mistake|international)\b", s):
        return None

    m = re.match(r"^(\d{1,2}):(\d{2})\s*(am|pm)?$", s)
    if not m:
        m = re.match(r"^(\d{1,2})(?::(\d{2}))?\s*(am|pm)$", s.replace(" ", ""))
    if not m:
        return None

    hour = int(m.group(1))
    minute = int(m.group(2) or 0)
    ampm = (m.group(3) or "").lower()

    if hour >= 13 and ampm == "pm":
        ampm = ""
    if hour >= 24:
        hour -= 24
    if ampm == "pm" and hour < 12:
        hour += 12
    elif ampm == "am" and hour == 12:
        hour = 0

    if hour > 23 or minute > 59:
        return None
    return time(hour, minute)


TIME_PATTERN = (
    r"(?:\d{1,2}h\s*\d{2}\s*(?:am|pm)?|"
    r"\d{1,2}:\d{2}\s*(?:am|pm)?|"
    r"\d{1,2}\s*[,]\s*\d{1,2}\s*(?:am|pm)?|"
    r"\d{1,2}\s*[,]\s*(?:am|pm)|"
    r"\d{1,2}\s+\d{2}\s*(?:am|pm)|"
    r"\d{3}\s*(?:am|pm)|"
    r"\d{1,2}\s*(?:am|pm)|"
    r"\d{1,2}(?:am|pm))"
)


def normalize_comma_times(text: str) -> str:
    """WhatsApp comma typos: 12,45,pm / 18,,pm / to23,45 pm → standard times."""
    # 18,,pm or 18,,,pm → 18:00 pm
    text = re.sub(
        r"\b(\d{1,2})\s*,(?:\s*,)+\s*(am|pm)\b",
        r"\1:00 \2",
        text,
        flags=re.I,
    )
    # 18,,30 pm or 18,, 30 pm → 18:30 pm
    text = re.sub(
        r"\b(\d{1,2})\s*,(?:\s*,)+\s*(\d{1,2})\s*(am|pm)\b",
        r"\1:\2 \3",
        text,
        flags=re.I,
    )
    # 12,45,pm → 12:45 pm
    text = re.sub(
        r"\b(\d{1,2})\s*,\s*(\d{1,2})\s*,\s*(am|pm)\b",
        r"\1:\2 \3",
        text,
        flags=re.I,
    )
    # to23,45 pm → to 23:45 pm
    text = re.sub(
        r"\bto\s*(\d{1,2})\s*,\s*(\d{1,2})\s*(am|pm)?",
        r"to \1:\2 \3",
        text,
        flags=re.I,
    )
    # 12,45 pm → 12:45 pm
    text = re.sub(
        r"\b(\d{1,2})\s*,\s*(\d{1,2})\s*(am|pm)\b",
        r"\1:\2 \3",
        text,
        flags=re.I,
    )
    return text


def normalize_attendance_typos(text: str) -> str:
    """Common WhatsApp attendance typos before time parsing (safe, local fixes only)."""
    t = text
    # out / in misspellings
    t = re.sub(r"\boit\b", "out", t, flags=re.I)
    t = re.sub(r"\boutt\b", "out", t, flags=re.I)
    t = re.sub(r"\bouy\b", "out", t, flags=re.I)
    t = re.sub(r"\biin\b", "in", t, flags=re.I)
    # am/pm typos
    t = re.sub(r"\bwm\b", "am", t, flags=re.I)
    t = re.sub(r"\bp\.m\.?\b", "pm", t, flags=re.I)
    t = re.sub(r"\ba\.m\.?\b", "am", t, flags=re.I)
    # break-line typos (Nlt / takèn already partly handled elsewhere)
    t = re.sub(r"\bnlt\b", "not", t, flags=re.I)
    t = re.sub(r"\btak[eèé]n\b", "taken", t, flags=re.I)
    t = re.sub(r"\btanken\b", "taken", t, flags=re.I)
    t = re.sub(r"\bnotbrak\b", "not break", t, flags=re.I)
    # date typo: 20,/06/26 or 29,/06/26
    t = re.sub(
        r"\b(\d{1,2})\s*,\s*/\s*(\d{1,2})\s*/\s*(\d{2,4})\b",
        r"\1/\2/\3",
        t,
    )
    # glued tokens: 18pmout / to23
    t = re.sub(r"(?i)(am|pm)\s*out\b", r"\1 out", t)
    t = re.sub(r"(?i)(am|pm)out\b", r"\1 out", t)
    t = re.sub(r"(?i)\bto(\d{1,2})", r"to \1", t)
    # collapse 3+ commas to double then handled by comma normalizer
    t = re.sub(r",{3,}", ",,", t)
    return t


def extract_times(text: str) -> tuple[Optional[time], Optional[time], str]:
    """Return (time_in, time_out, entry_type). entry_type: full|in|out|none."""
    if has_ambiguous_meridiem(text):
        return None, None, "none"

    clean = text.replace("\n", " ")
    clean = normalize_attendance_typos(clean)
    clean = strip_dates_from_text(clean)
    clean = normalize_h_time_formats(clean)
    clean = normalize_comma_times(clean)
    clean = re.sub(
        r"(\d{1,2})\s*[,]\s*(\d{1,2})\s*(am|pm)?",
        r"\1:\2 \3",
        clean,
        flags=re.I,
    )
    clean = re.sub(
        r"(\d{1,2})\s*[,]\s*(am|pm)\b",
        r"\1:00 \2",
        clean,
        flags=re.I,
    )

    full_patterns = [
        rf"(?:started?\s+at\s+)?({TIME_PATTERN})\s+in\s+to\s+({TIME_PATTERN})\s+out",
        rf"({TIME_PATTERN})\s+in\s+to\s+({TIME_PATTERN})\s+out",
        rf"({TIME_PATTERN})\s+in\s+to\s+({TIME_PATTERN})",
        rf"({TIME_PATTERN})\s+to\s+({TIME_PATTERN})",
        rf"({TIME_PATTERN})\s+till?\s+({TIME_PATTERN})",
        rf"({TIME_PATTERN})\s+-\s+({TIME_PATTERN})",
    ]
    for pat in full_patterns:
        m = re.search(pat, clean, re.I)
        if m:
            raw_in, raw_out = m.group(1), m.group(2)
            time_in = parse_time_token(raw_in)
            time_out = parse_time_token(raw_out)
            if time_in and time_out and time_in >= time_out and "pm" in raw_in.lower():
                alt_in = parse_time_token(raw_in.replace("pm", "am"))
                if alt_in and alt_in < time_out:
                    time_in = alt_in
            if time_in and time_out:
                return time_in, time_out, "full"

    in_m = re.search(rf"({TIME_PATTERN})\s+in\b", clean, re.I)
    out_m = re.search(rf"({TIME_PATTERN})\s+out\b", clean, re.I)
    if in_m and out_m:
        time_in = parse_time_token(in_m.group(1))
        time_out = parse_time_token(out_m.group(1))
        if time_in and time_out:
            return time_in, time_out, "full"
    if in_m:
        time_in = parse_time_token(in_m.group(1))
        if time_in:
            return time_in, None, "in"
    if out_m:
        time_out = parse_time_token(out_m.group(1))
        if time_out:
            return None, time_out, "out"

    bare = re.findall(TIME_PATTERN, clean, re.I)
    if len(bare) == 1:
        t = parse_time_token(bare[0])
        if t:
            if re.search(r"\bout\b", clean, re.I):
                return None, t, "out"
            if re.search(r"\bin\b", clean, re.I):
                return t, None, "in"
            if t.hour >= 14:
                return None, t, "out"
            return t, None, "in"
    if len(bare) >= 2:
        parsed = [(b, parse_time_token(b)) for b in bare]
        valid = [(b, t) for b, t in parsed if t]
        if len(valid) >= 2:
            raw_in, t1 = valid[0]
            raw_out, t2 = valid[-1]
            if t1 >= t2 and "pm" in raw_in.lower():
                alt_in = parse_time_token(raw_in.replace("pm", "am"))
                if alt_in and alt_in < t2:
                    t1 = alt_in
            return t1, t2, "full"

    return None, None, "none"


def default_short_name(excel_name: str) -> str:
    match = re.match(r"^([^(]+)", str(excel_name).strip())
    return match.group(1).strip() if match else str(excel_name).strip()


PLACEHOLDER_BANKS = {"mr l kongolo"}


def normalize_bank(bank: Optional[str]) -> str:
    if not bank:
        return ""
    return re.sub(r"\s+", " ", str(bank).strip().lower())


def bank_is_unique_identifier(bank: Optional[str]) -> bool:
    key = normalize_bank(bank)
    return bool(key) and key not in PLACEHOLDER_BANKS


def _edit_distance(a: str, b: str) -> int:
    if len(a) < len(b):
        return _edit_distance(b, a)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i]
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            curr.append(min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost))
        prev = curr
    return prev[-1]


def worker_names_match(a: str, b: str) -> bool:
    a_norm = re.sub(r"[^a-z]", "", str(a).lower())
    b_norm = re.sub(r"[^a-z]", "", str(b).lower())
    if not a_norm or not b_norm:
        return False
    if a_norm == b_norm:
        return True
    shorter, longer = (a_norm, b_norm) if len(a_norm) <= len(b_norm) else (b_norm, a_norm)
    if longer.startswith(shorter) and len(shorter) >= 4:
        return True
    if shorter in longer:
        return len(longer) - len(shorter) <= 2
    max_len = max(len(a_norm), len(b_norm))
    if max_len <= 12:
        limit = 2 if max_len >= 6 else 1
        if _edit_distance(a_norm, b_norm) <= limit:
            return True
    return False


def is_system_message(sender: str, text: str) -> bool:
    sender_s = sender.strip()
    if re.match(r"^You\b", sender_s, re.I):
        return True
    if SYSTEM_MESSAGE_RE.search(text):
        return True
    if SYSTEM_MESSAGE_RE.search(sender_s):
        return True
    return False


def template_roster(wb: openpyxl.Workbook) -> set[str]:
    if TEMPLATE_SHEET not in wb.sheetnames:
        return set()
    ws = wb[TEMPLATE_SHEET]
    names: set[str] = set()
    for week in find_week_sections(ws):
        names.update(week.employee_rows.keys())
    return names


def merge_registry_by_bank(registry: WorkerRegistry) -> None:
    by_bank: dict[str, WorkerProfile] = {}
    for profile in list(registry.profiles.values()):
        key = normalize_bank(profile.bank_name)
        if not key or not bank_is_unique_identifier(key):
            continue
        if key in by_bank:
            canonical = by_bank[key]
            registry.register(
                WorkerProfile(
                    excel_name=canonical.excel_name,
                    short_name=profile.short_name,
                    bank_name=canonical.bank_name or profile.bank_name,
                    hourly_rate=canonical.hourly_rate or profile.hourly_rate,
                    empty_break_hours=canonical.empty_break_hours,
                )
            )
            registry.short_to_excel[profile.short_name] = canonical.excel_name
        else:
            by_bank[key] = profile


def find_historical_employee(
    wb: openpyxl.Workbook,
    registry: WorkerRegistry,
    short_name: str,
) -> tuple[Optional[str], Optional[str], Optional[float], bool]:
    excel_name = None
    bank_name = None
    hourly_rate = None
    empty_break_hours = False

    for sheet_name in reversed(month_sheet_names(wb)):
        ws = wb[sheet_name]
        for week in find_week_sections(ws):
            for ename, emp_row in week.employee_rows.items():
                known_short = registry.short_for(ename)
                if not (
                    worker_names_match(short_name, known_short)
                    or worker_names_match(short_name, ename)
                    or worker_names_match(short_name, default_short_name(ename))
                ):
                    continue
                excel_name = ename
                bank = ws.cell(emp_row, 9).value
                rate = ws.cell(emp_row, 10).value
                if bank:
                    bank_name = str(bank)
                if rate is not None:
                    hourly_rate = rate
                empty_break_hours = is_franklin_employee(ename)
                return excel_name, bank_name, hourly_rate, empty_break_hours

    return excel_name, bank_name, hourly_rate, empty_break_hours


def month_sheet_names(wb: openpyxl.Workbook) -> list[str]:
    names = [s for s in wb.sheetnames if MONTH_SHEET_RE.match(s)]
    return sorted(names, key=sheet_name_sort_key)


def sheet_name_sort_key(name: str) -> tuple[int, int]:
    match = MONTH_SHEET_RE.match(name)
    if not match:
        return (0, 0)
    month_num, _, year_short = match.groups()
    months = {m.lower(): i for i, m in enumerate(calendar.month_abbr) if m}
    return (parse_short_year(int(year_short)), months.get(month_num.lower()[:3], 0))


def build_worker_registry(wb: openpyxl.Workbook) -> WorkerRegistry:
    registry = WorkerRegistry()
    bank_by_excel: dict[str, str] = {}
    rate_by_excel: dict[str, float] = {}
    empty_break_by_excel: dict[str, bool] = {}
    dash_break_shorts: set[str] = set()

    for sheet_name in month_sheet_names(wb):
        ws = wb[sheet_name]
        for week in find_week_sections(ws):
            for excel_name, emp_row in week.employee_rows.items():
                short = default_short_name(excel_name)
                for col in DAY_COLS:
                    val = ws.cell(emp_row, col).value
                    if isinstance(val, str) and val.startswith("=U"):
                        ref_match = re.search(r"U(\d+)", val)
                        if ref_match:
                            detail_short = ws.cell(int(ref_match.group(1)), DETAIL_COLS["name"]).value
                            if detail_short:
                                short = str(detail_short)

                bank = ws.cell(emp_row, 9).value
                rate = ws.cell(emp_row, 10).value
                if bank:
                    bank_by_excel[excel_name] = str(bank)
                if rate is not None:
                    rate_by_excel[excel_name] = rate
                if ws.cell(emp_row, 12).value is None:
                    empty_break_by_excel[excel_name] = True

            for row in range(week.header_row, week.end_row + 1):
                detail_name = ws.cell(row, DETAIL_COLS["name"]).value
                detail_break = ws.cell(row, DETAIL_COLS["break"]).value
                if detail_name and detail_break == "-":
                    dash_break_shorts.add(str(detail_name))

    all_excel_names = set(bank_by_excel) | set(rate_by_excel) | set(empty_break_by_excel)
    for sheet_name in month_sheet_names(wb):
        ws = wb[sheet_name]
        for week in find_week_sections(ws):
            all_excel_names.update(week.employee_rows.keys())

    for excel_name in sorted(all_excel_names):
        short = default_short_name(excel_name)
        for sheet_name in reversed(month_sheet_names(wb)):
            ws = wb[sheet_name]
            for week in find_week_sections(ws):
                if excel_name not in week.employee_rows:
                    continue
                emp_row = week.employee_rows[excel_name]
                for col in DAY_COLS:
                    val = ws.cell(emp_row, col).value
                    if isinstance(val, str) and val.startswith("=U"):
                        ref_match = re.search(r"U(\d+)", val)
                        if ref_match:
                            detail_short = ws.cell(int(ref_match.group(1)), DETAIL_COLS["name"]).value
                            if detail_short:
                                short = str(detail_short)
                                break
                if short != default_short_name(excel_name):
                    break

        profile = WorkerProfile(
            excel_name=excel_name,
            short_name=short,
            bank_name=bank_by_excel.get(excel_name),
            hourly_rate=rate_by_excel.get(excel_name),
            empty_break_hours=is_franklin_employee(excel_name) or is_franklin_employee(short),
        )
        registry.register(profile)

    merge_registry_by_bank(registry)
    return registry


def canonical_employee_order(wb: openpyxl.Workbook) -> list[str]:
    for sheet_name in reversed(month_sheet_names(wb)):
        ws = wb[sheet_name]
        weeks = find_week_sections(ws)
        if not weeks:
            continue
        order = list(weeks[0].employee_rows.keys())
        if order:
            return order
    return []


def detect_unknown_name_in_text(text: str) -> Optional[str]:
    clean = strip_dates_from_text(text)
    for token in re.findall(r"\b([A-Z][A-Za-z]{2,})\b", clean):
        if token in NAME_IGNORE_WORDS:
            continue
        return token
    return None


def is_valid_worker_short(name: str) -> bool:
    if not name or not str(name).strip():
        return False
    key = re.sub(r"[^a-z]", "", str(name).lower())
    if len(key) < 2:
        return False
    return key not in INVALID_WORKER_SHORTS


def canonical_worker_short(name: str, registry: WorkerRegistry) -> Optional[str]:
    if not name or not str(name).strip():
        return None
    token = str(name).strip()
    key = re.sub(r"[^a-z]", "", token.lower())
    if key in WORKER_ALIASES:
        token = WORKER_ALIASES[key]
    result: Optional[str] = None
    for short in sorted(registry.short_names(), key=len, reverse=True):
        if worker_names_match(token, short):
            result = short
            break
    if result is None and key in WORKER_ALIASES:
        result = WORKER_ALIASES[key]
    if result is None:
        result = token if is_valid_worker_short(token) else None
    # Final authoritative collapse so one person always maps to one short.
    return apply_canonical_short(result)


def dedupe_records(
    records: list["AttendanceRecord"], registry: WorkerRegistry
) -> list["AttendanceRecord"]:
    """
    Remove duplicate attendance rows caused by alias spellings.

    Two records collapse only when they resolve to the SAME canonical worker AND
    have the same date + in/out time. Genuine split shifts (same person, same day,
    different times) are preserved.
    """
    seen: set[tuple] = set()
    out: list["AttendanceRecord"] = []
    for rec in sorted(
        records, key=lambda r: (r.work_date, str(r.worker), r.time_in or time(0))
    ):
        short = canonical_worker_short(rec.worker, registry) or rec.worker
        key = (str(short).lower(), rec.work_date, rec.time_in, rec.time_out)
        if key in seen:
            continue
        seen.add(key)
        out.append(rec)
    return out


def repair_self_referencing_sums(wb: openpyxl.Workbook) -> list[str]:
    """
    Fix circular-reference Total rows where a SUM includes its own cell,
    e.g. B45 == '=SUM(B37:B45)'. Shrinks the range end by one row so the
    Total no longer references itself. Returns a list of fixed cell addresses.
    """
    fixed: list[str] = []
    pat = re.compile(r"^=SUM\(([A-Z]{1,3})(\d+):([A-Z]{1,3})(\d+)\)$", re.I)
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if not isinstance(v, str) or not v.startswith("="):
                    continue
                m = pat.match(v.replace(" ", ""))
                if not m:
                    continue
                c1, r1, c2, r2 = m.group(1), int(m.group(2)), m.group(3), int(m.group(4))
                # self-reference: same column, and the SUM end row is this cell's row
                if c1.upper() == c2.upper() and cell.column_letter.upper() == c1.upper():
                    if r2 == cell.row and r1 < r2:
                        cell.value = f"=SUM({c1}{r1}:{c2}{r2 - 1})"
                        fixed.append(f"{ws.title}!{cell.column_letter}{cell.row}")
    return fixed


def register_template_aliases(registry: WorkerRegistry) -> None:
    alias_to_excel = {
        "Chadrack": "Chadrack(D-20)",
        "Chadrac": "Chadrack(D-20)",
        "Jenifer": "Jenifer",
        "Janifer": "Jenifer",
        "Jennifer": "Jenifer",
        "MamaKissi": "Mamakisi",
        "Maman": "Maman",
        "Jeannine": "Jeannine (D-02)",
        "Jeaninne": "Jeannine (D-02)",
        "Beatrice": "Beatrice (D-01)",
        "Flamme": "Flamme (D-14)",
        "Franklin": "Franklin",
        "Felix": "Felix",
        "Hanna": "Hanna(D-09)",
        "Kennedy": "Kennedy",
    }
    for short, excel_name in alias_to_excel.items():
        existing = registry.profile_for(short)
        if existing:
            registry.short_to_excel[short] = existing.excel_name
            continue
        profile = registry.profile_for(registry.short_for(excel_name)) if excel_name in registry.excel_to_short.values() else None
        if profile:
            registry.short_to_excel[short] = profile.excel_name
        else:
            registry.register(
                WorkerProfile(
                    excel_name=excel_name,
                    short_name=short,
                    empty_break_hours=is_franklin_employee(excel_name),
                )
            )


def extract_named_worker_from_text(text: str, registry: WorkerRegistry) -> Optional[str]:
    for short in sorted(registry.short_names(), key=len, reverse=True):
        if re.search(rf"\b{re.escape(short)}\w*\b", text, re.I):
            return short

    after_date = re.search(
        r"\b\d{1,2}/\d{1,2}/\d{2,4}\s+([A-Za-z][A-Za-z]+)\s+(?:\d|0)",
        text,
        re.I,
    )
    if after_date:
        found = canonical_worker_short(after_date.group(1), registry)
        if found:
            return found

    tail = re.search(
        r"(?:not\s*break\s*taken|without\s*break|no\s*break)\s+([A-Za-z][A-Za-z]+)\s*$",
        text,
        re.I,
    )
    if tail:
        found = canonical_worker_short(tail.group(1), registry)
        if found:
            return found

    tail = re.search(
        r"(?:not\s*break\s*taken|without\s*break|no\s*break)\s+([A-Za-z][A-Za-z]+)\s*$",
        text,
        re.I,
    )
    if tail:
        found = canonical_worker_short(tail.group(1), registry)
        if found:
            return found

    end_name = re.search(r"\b([A-Za-z][A-Za-z]{2,})\s*$", text.strip())
    if end_name and not re.search(r"not\s*break\s*taken|without\s*break", text, re.I):
        token = end_name.group(1)
        if token not in NAME_IGNORE_WORDS and is_valid_worker_short(token):
            found = canonical_worker_short(token, registry)
            if found and found.lower() not in {"am", "pm", "out", "in"}:
                return found
    return None


def is_manager_sender(sender: str) -> bool:
    return bool(MANAGER_SENDER_RE.search(sender.strip()))


def is_phone_sender(sender: str) -> bool:
    return bool(PHONE_SENDER_RE.match(sender.strip()))


def is_flamme_phone_sender(sender: str) -> bool:
    digits = re.sub(r"\D", "", sender)
    return digits.endswith("447947333490") or digits == "447947333490"


def is_sister_01_sender(sender: str) -> bool:
    return bool(SISTER_01_SENDER_RE.search(sender.strip()))


def detect_worker(sender: str, text: str, registry: WorkerRegistry) -> Optional[str]:
    if sender in IGNORE_SENDERS:
        return None
    if is_phone_sender(sender) and not is_flamme_phone_sender(sender):
        return None

    if is_flamme_phone_sender(sender):
        found = canonical_worker_short("Flamme", registry)
        if found:
            return found
        for short in registry.short_names():
            if "flamme" in short.lower():
                return short

    # New group aliases: sender identity first (before text scan)
    if is_sister_01_sender(sender):
        found = canonical_worker_short("Beatrice", registry)
        if found:
            return found
        for short, excel_name in registry.short_to_excel.items():
            if "beatrice" in excel_name.lower():
                return short

    if is_manager_sender(sender):
        named = extract_named_worker_from_text(text, registry)
        if named and "jeannine" not in named.lower() and "jeaninne" not in named.lower():
            return named
        _, _, entry_type = extract_times(text)
        if entry_type != "none":
            for short in registry.short_names():
                if "jeannine" in short.lower():
                    return short
            found = canonical_worker_short("Jeannine", registry)
            if found:
                return found
            return None

    named = extract_named_worker_from_text(text, registry)
    if named:
        return named

    for short in sorted(registry.short_names(), key=len, reverse=True):
        if short.lower() in sender.lower():
            return short

    if re.search(r"sister|sist", text, re.I) and sender.lower().startswith("beatrice"):
        for short, excel_name in registry.short_to_excel.items():
            if "beatrice" in excel_name.lower():
                return short

    _, _, entry_type = extract_times(text)
    if entry_type != "none":
        unknown = detect_unknown_name_in_text(text)
        if unknown:
            found = canonical_worker_short(unknown, registry)
            if found:
                return found

    return None


def has_no_break(text: str) -> bool:
    return bool(NO_BREAK_RE.search(normalize_attendance_typos(text)))


def read_chat_messages(path: Path) -> list[tuple[datetime, str, str]]:
    messages: list[tuple[datetime, str, str]] = []
    current_ts: Optional[datetime] = None
    current_sender = ""
    current_lines: list[str] = []

    def flush() -> None:
        nonlocal current_ts, current_sender, current_lines
        if current_ts and current_sender:
            text = "\n".join(current_lines).strip()
            if text and "end-to-end encrypted" not in text.lower():
                if "omitted>" not in text and "deleted" not in text.lower():
                    messages.append((current_ts, current_sender, text))
        current_lines = []

    with path.open(encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n\r")
            line = line.replace("\ufeff", "").replace("takèn", "taken").replace("tanken", "taken")
            m = MSG_RE.match(line)
            if m:
                flush()
                d_str, t_str, ampm, sender, body = m.groups()
                day, month, year = map(int, d_str.split("/"))
                hour, minute = map(int, t_str.split(":"))
                ap = (ampm or "").lower()
                if ap == "pm" and hour < 12:
                    hour += 12
                elif ap == "am" and hour == 12:
                    hour = 0
                current_ts = datetime(year, month, day, hour, minute)
                current_sender = sender.strip()
                current_lines = [body.strip()] if body.strip() else []
            elif line.strip() and current_ts:
                current_lines.append(line.strip())
    flush()
    return messages


def parse_records(
    messages: list[tuple[datetime, str, str]],
    stats: Stats,
    registry: WorkerRegistry,
) -> list[AttendanceRecord]:
    partials: list[AttendanceRecord] = []

    for ts, sender, text in messages:
        if ts.date() < CUTOFF_DATE:
            continue

        if is_system_message(sender, text):
            continue

        if re.search(r"\bYou (?:added|removed|turned|deleted)\b", text, re.I):
            continue

        text_clean = normalize_attendance_typos(text)

        if is_phone_sender(sender) and not is_flamme_phone_sender(sender):
            log_skip(stats, "Phone-number sender skipped", f"{ts} | {sender}: {text[:120]}")
            continue

        worker = detect_worker(sender, text_clean, registry)
        if not worker or not is_valid_worker_short(worker) or worker.strip().lower() == "you":
            if is_manager_sender(sender) and extract_times(text_clean)[2] != "none":
                log_skip(stats, "Manager message without worker name", f"{ts} | {sender}: {text[:120]}")
            continue

        if len(workers_mentioned_in_text(text_clean, registry)) > 1:
            log_skip(stats, "Multiple workers in one message", f"{ts} | {sender}: {text[:120]}")
            continue

        explicit_date = parse_date_from_text(text_clean, ts.date())
        work_date = explicit_date or ts.date()
        if work_date < CUTOFF_DATE:
            continue

        no_break = has_no_break(text_clean)
        time_in, time_out, entry_type = extract_times(text_clean)

        if entry_type == "none":
            log_skip(stats, "Unparseable times", f"{ts} | {sender}: {text[:120]}")
            continue

        partials.append(
            AttendanceRecord(
                worker=worker,
                work_date=work_date,
                time_in=time_in,
                time_out=time_out,
                no_break=no_break,
                source=f"{ts} | {sender}: {text[:200]}",
                sender=sender,
                date_explicit=explicit_date is not None,
                message_time=ts,
            )
        )

    partials = resolve_checkout_dates(partials, stats)
    return merge_partials(partials, stats)


def resolve_checkout_dates(partials: list[AttendanceRecord], stats: Stats) -> list[AttendanceRecord]:
    """Attach checkout-only messages to the most recent open check-in."""
    pending: dict[str, list[AttendanceRecord]] = defaultdict(list)
    resolved: list[AttendanceRecord] = []

    for rec in partials:
        if rec.time_in and not rec.time_out:
            pending[rec.worker].append(rec)
            continue

        if rec.time_out and not rec.time_in and not rec.date_explicit:
            match = None
            for cand in reversed(pending.get(rec.worker, [])):
                if cand.work_date == rec.work_date:
                    match = cand
                    break
            if not match:
                for cand in reversed(pending.get(rec.worker, [])):
                    if cand.work_date == rec.work_date - timedelta(days=1):
                        match = cand
                        break
            if match:
                pending[rec.worker].remove(match)
                # Clean split: both sides already parsed — merge into one attendance day
                resolved.append(
                    AttendanceRecord(
                        worker=rec.worker,
                        work_date=match.work_date,
                        time_in=match.time_in,
                        time_out=rec.time_out,
                        no_break=rec.no_break or match.no_break,
                        source=f"{match.source} | {rec.source}",
                        date_explicit=True,
                        message_time=rec.message_time,
                    )
                )
                continue

        if rec.time_in and rec.time_out:
            pending[rec.worker] = [
                p for p in pending[rec.worker] if p.work_date != rec.work_date
            ]
        resolved.append(rec)

    for items in pending.values():
        resolved.extend(items)
    return resolved


def merge_partials(partials: list[AttendanceRecord], stats: Stats) -> list[AttendanceRecord]:
    groups: dict[tuple[str, date], list[AttendanceRecord]] = defaultdict(list)
    for rec in partials:
        groups[(rec.worker, rec.work_date)].append(rec)

    merged: list[AttendanceRecord] = []
    for (worker, work_date), items in sorted(groups.items()):
        dated_items = items
        if any(i.message_time for i in items):
            dated_items = sorted(
                items,
                key=lambda i: i.message_time or datetime.min,
            )
        full_entries = [i for i in dated_items if i.time_in and i.time_out]
        if len(full_entries) > 1:
            signatures = {(f.time_in, f.time_out) for f in full_entries}
            if len(signatures) > 1:
                sources = " || ".join(i.source for i in full_entries)
                log_skip(
                    stats,
                    "Conflicting times same worker/day",
                    f"{worker} {work_date} | {sources}",
                )
                continue
            full = full_entries[-1]
        elif len(full_entries) == 1:
            full = full_entries[0]
        else:
            ins = [i.time_in for i in items if i.time_in]
            outs = [i.time_out for i in items if i.time_out]
            if len(set(ins)) > 1 or len(set(outs)) > 1:
                sources = " || ".join(i.source for i in items)
                log_skip(
                    stats,
                    "Conflicting partial times same worker/day",
                    f"{worker} {work_date} | {sources}",
                )
                continue
            if len(ins) == 1 and len(outs) == 1:
                full = AttendanceRecord(
                    worker=worker,
                    work_date=work_date,
                    time_in=ins[0],
                    time_out=outs[0],
                    no_break=any(i.no_break for i in items),
                    source=" | ".join(i.source for i in items),
                )
            else:
                sources = " || ".join(i.source for i in items)
                log_skip(
                    stats,
                    "Incomplete attendance (missing in or out)",
                    f"{worker} {work_date} | {sources}",
                )
                continue

        if full.time_out <= full.time_in:
            # overnight shift
            pass
        merged.append(
            AttendanceRecord(
                worker=full.worker,
                work_date=full.work_date,
                time_in=full.time_in,
                time_out=full.time_out,
                no_break=any(i.no_break for i in items),
                source=full.source,
            )
        )
    return merged


def time_to_excel_duration(t_in: time, t_out: time) -> time:
    d0 = datetime.combine(date.min, t_in)
    d1 = datetime.combine(date.min, t_out)
    if d1 <= d0:
        d1 += timedelta(days=1)
    delta = d1 - d0
    total_seconds = int(delta.total_seconds())
    hours, rem = divmod(total_seconds, 3600)
    minutes, seconds = divmod(rem, 60)
    return time(hours % 24, minutes, seconds)


def duration_to_hours(td: time) -> float:
    return td.hour + td.minute / 60 + td.second / 3600


def hours_to_time(hours: float) -> time:
    total_minutes = round(hours * 60)
    h, m = divmod(total_minutes, 60)
    return time(h % 24, m, 0)


def parse_week_title(title: str) -> tuple[date, date]:
    m = re.match(
        r"(\d{1,2})-([A-Za-z]+)-(\d{4})\s+To\s+(\d{1,2})-([A-Za-z]+)-(\d{4})",
        title,
    )
    if not m:
        raise ValueError(f"Bad week title: {title}")
    months = {m.lower(): i for i, m in enumerate(calendar.month_name) if m}
    months.update({m.lower(): i for i, m in enumerate(calendar.month_abbr) if m})

    def to_date(day_s: str, mon_s: str, year_s: str) -> date:
        return date(int(year_s), months[mon_s.lower()], int(day_s))

    return to_date(m.group(1), m.group(2), m.group(3)), to_date(
        m.group(4), m.group(5), m.group(6)
    )


def find_week_sections(ws: Worksheet) -> list[WeekSection]:
    weeks: list[WeekSection] = []
    r = 1
    while r <= ws.max_row:
        val = ws.cell(r, 1).value
        if val and " To " in str(val):
            header_row = r
            employee_header_row = None
            total_row = None
            employee_rows: dict[str, int] = {}
            date_row = None
            rr = r + 1
            while rr <= ws.max_row:
                a_val = ws.cell(rr, 1).value
                if a_val == "Employee Name":
                    employee_header_row = rr
                    for cand in (rr - 1, rr - 2):
                        if cand >= r and isinstance(ws.cell(cand, 2).value, datetime):
                            date_row = cand
                            break
                if (
                    employee_header_row
                    and a_val
                    and a_val not in ("Employee Name", "Total")
                    and " To " not in str(a_val)
                ):
                    employee_rows[str(a_val)] = rr
                if a_val == "Total" and employee_header_row and rr > employee_header_row:
                    total_row = rr
                    break
                rr += 1
            end_row = rr
            while end_row < ws.max_row:
                nxt = ws.cell(end_row + 1, 1).value
                if nxt and " To " in str(nxt):
                    break
                end_row += 1

            dates: dict[int, date] = {}
            if date_row:
                for col in DAY_COLS:
                    cell_val = ws.cell(date_row, col).value
                    if isinstance(cell_val, datetime):
                        dates[col] = cell_val.date()

            weeks.append(
                WeekSection(
                    header_row=header_row,
                    end_row=end_row,
                    title=str(val),
                    date_row=date_row or r + 2,
                    employee_header_row=employee_header_row or r + 3,
                    total_row=total_row or r + 8,
                    employee_rows=employee_rows,
                    dates=dates,
                )
            )
            r = end_row + 1
        else:
            r += 1
    return weeks


def month_week_ranges(year: int, month: int) -> list[tuple[date, date]]:
    last_day = calendar.monthrange(year, month)[1]
    ranges: list[tuple[date, date]] = []
    start = date(year, month, 1)
    while start.month == month:
        end = min(start + timedelta(days=6), date(year, month, last_day))
        ranges.append((start, end))
        start = end + timedelta(days=1)
    return ranges


def format_week_title(start: date, end: date) -> str:
    month_name = calendar.month_name[start.month]
    return (
        f"{start.day:02d}-{month_name}-{start.year} To "
        f"{end.day:02d}-{month_name}-{end.year}"
    )


def clear_week_attendance(ws: Worksheet, week: WeekSection) -> None:
    for row in range(week.header_row, week.end_row + 1):
        for col in range(DETAIL_COLS["date"], DETAIL_LOG_LAST_COL + 1):
            if row == 1:
                continue
            ws.cell(row, col).value = None

    for excel_name, row in week.employee_rows.items():
        for col in DAY_COLS:
            ws.cell(row, col).value = time(0, 0)
        if is_franklin_employee(excel_name):
            ws.cell(row, 12).value = None
        else:
            ws.cell(row, 12).value = time(0, 0)
        ws.cell(row, 13).value = f"=L{row}*J{row}*24"


def update_week_dates(ws: Worksheet, week: WeekSection, start: date, end: date) -> None:
    ws.cell(week.header_row, 1).value = format_week_title(start, end)
    date_row = week.date_row
    emp_hdr = week.employee_header_row

    for idx, col in enumerate(DAY_COLS):
        current = start + timedelta(days=idx)
        if current <= end:
            ws.cell(date_row, col).value = datetime.combine(current, time.min)
            day_name = calendar.day_name[current.weekday()]
            ws.cell(emp_hdr, col).value = day_name
            week.dates[col] = current
        else:
            ws.cell(date_row, col).value = None
            ws.cell(emp_hdr, col).value = None
            week.dates.pop(col, None)


def guard_not_template(ws: Worksheet) -> None:
    if ws.title == TEMPLATE_SHEET:
        raise RuntimeError(
            f"PERMANENT RULE VIOLATION: sheet {TEMPLATE_SHEET} is read-only and must never be written to"
        )


def copy_cell_style(
    src: openpyxl.cell.cell.Cell,
    dst: openpyxl.cell.cell.Cell,
    *,
    skip_fill: bool = False,
) -> None:
    if src.font:
        dst.font = copy(src.font)
    if src.border:
        dst.border = copy(src.border)
    if src.fill and not skip_fill:
        dst.fill = copy(src.fill)
    if src.number_format:
        dst.number_format = src.number_format
    if src.protection:
        dst.protection = copy(src.protection)
    if src.alignment:
        dst.alignment = copy(src.alignment)


def is_detail_entry_row(ws: Worksheet, row: int) -> bool:
    val = ws.cell(row, DETAIL_COLS["date"]).value
    return isinstance(val, datetime)


def is_franklin_employee(name: str) -> bool:
    n = str(name).strip()
    if not n:
        return False
    if n.lower() == FRANKLIN_NAME.lower():
        return True
    if n.lower().startswith("frank") and worker_names_match(n, FRANKLIN_NAME):
        return True
    return False


def is_kennedy_worker(name: str) -> bool:
    return "kennedy" in str(name).strip().lower()


def template_normal_employee_rows(template_ws: Worksheet, template_week: WeekSection) -> list[int]:
    rows = sorted(template_week.employee_rows.values())
    return [
        row
        for row in rows
        if not is_franklin_employee(str(template_ws.cell(row, 1).value or ""))
    ]


def resolve_template_employee_row(
    template_ws: Worksheet,
    template_week: WeekSection,
    week: WeekSection,
    row: int,
    excel_name: str,
) -> int:
    if is_franklin_employee(excel_name):
        return TEMPLATE_FRANKLIN_ROW
    emp_index = row - week.employee_header_row - 1
    normal_rows = template_normal_employee_rows(template_ws, template_week)
    if not normal_rows:
        return TEMPLATE_NORMAL_EMPLOYEE_ROW
    return normal_rows[min(emp_index, len(normal_rows) - 1)]


def template_style_cell(
    template_ws: Worksheet,
    row: int,
    col: int,
    week: Optional[WeekSection] = None,
    template_week: Optional[WeekSection] = None,
    target_ws: Optional[Worksheet] = None,
) -> openpyxl.cell.cell.Cell:
    if col >= WEEK_LABEL_COL:
        if row <= template_ws.max_row:
            return template_ws.cell(row, col)
        return template_ws.cell(1, col)
    if col >= DETAIL_COLS["date"]:
        if row == DETAIL_HEADER_ROW:
            return template_ws.cell(DETAIL_HEADER_ROW, col)
        return template_ws.cell(TEMPLATE_DETAIL_ROW, col)
    if week and template_week:
        if week.employee_header_row and week.total_row and week.employee_header_row < row < week.total_row:
            excel_name = ""
            if target_ws is not None:
                excel_name = str(target_ws.cell(row, 1).value or "")
            ref_row = resolve_template_employee_row(
                template_ws, template_week, week, row, excel_name
            )
            return template_ws.cell(ref_row, col)
        if row == week.total_row and template_week.total_row:
            return template_ws.cell(template_week.total_row, col)
        if row == week.employee_header_row and template_week.employee_header_row:
            return template_ws.cell(template_week.employee_header_row, col)
        if row == week.date_row and template_week.date_row:
            return template_ws.cell(template_week.date_row, col)
        if row == week.header_row and template_week.header_row:
            return template_ws.cell(template_week.header_row, col)
    if row <= template_ws.max_row and col <= template_ws.max_column:
        return template_ws.cell(row, col)
    return template_ws.cell(6, col)


def apply_cell_template_style(
    ws: Worksheet,
    template_ws: Worksheet,
    row: int,
    col: int,
    week: Optional[WeekSection] = None,
    template_week: Optional[WeekSection] = None,
) -> None:
    src = template_style_cell(template_ws, row, col, week, template_week, target_ws=ws)
    dst = ws.cell(row, col)
    copy_cell_style(src, dst)
    if DETAIL_LOG_FIRST_COL <= col <= DETAIL_LOG_LAST_COL:
        dst.fill = NO_FILL


def write_cell(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    row: int,
    col: int,
    value,
    week: Optional[WeekSection] = None,
    template_week: Optional[WeekSection] = None,
) -> None:
    guard_not_template(ws)
    cell = ws.cell(row, col)
    prev_fill = copy(cell.fill) if cell.fill else None
    cell.value = value
    if ws.title == TEMPLATE_SHEET:
        return
    template_ws = wb[TEMPLATE_SHEET]
    apply_cell_template_style(ws, template_ws, row, col, week, template_week)
    # Day hours must always be time format — never General/d-mmm (shows decimals / 0-Jan)
    if col in DAY_COLS:
        cell.number_format = DAY_HOURS_FORMAT
        # Keep the employee row fill (only Franklin is yellow)
        if prev_fill is not None:
            cell.fill = prev_fill


def apply_sheet_layout_from_template(
    target_ws: Worksheet,
    template_ws: Worksheet,
    *,
    include_merges: bool = True,
) -> None:
    for col_letter, dim in template_ws.column_dimensions.items():
        target_dim = target_ws.column_dimensions[col_letter]
        if dim.width is not None:
            target_dim.width = dim.width
        target_dim.hidden = dim.hidden

    for row_num, dim in template_ws.row_dimensions.items():
        target_dim = target_ws.row_dimensions[row_num]
        if dim.height is not None:
            target_dim.height = dim.height
        target_dim.hidden = dim.hidden

    target_ws.sheet_format = copy(template_ws.sheet_format)
    target_ws.sheet_properties = copy(template_ws.sheet_properties)
    target_ws.page_setup = copy(template_ws.page_setup)
    target_ws.print_options = copy(template_ws.print_options)

    if not include_merges:
        return

    for merged_range in list(target_ws.merged_cells.ranges):
        target_ws.unmerge_cells(str(merged_range))
    for merged_range in list(template_ws.merged_cells.ranges):
        target_ws.merge_cells(str(merged_range))


def apply_month_sheet_formatting(
    wb: openpyxl.Workbook,
    sheet_name: str,
    *,
    include_merges: bool = True,
    realign_layout: bool = False,
) -> None:
    if sheet_name == TEMPLATE_SHEET:
        return
    if sheet_name not in wb.sheetnames or TEMPLATE_SHEET not in wb.sheetnames:
        return
    target_ws = wb[sheet_name]
    template_ws = wb[TEMPLATE_SHEET]
    apply_sheet_layout_from_template(target_ws, template_ws, include_merges=include_merges)

    template_weeks = find_week_sections(template_ws)
    target_weeks = find_week_sections(target_ws)
    max_row = max(target_ws.max_row, template_ws.max_row)
    max_col = max(target_ws.max_column, template_ws.max_column)

    for row in range(1, max_row + 1):
        week = None
        template_week = None
        for idx, tw in enumerate(target_weeks):
            if tw.header_row <= row <= tw.end_row:
                week = tw
                template_week = template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
                break
        is_detail = is_detail_entry_row(target_ws, row)
        if not is_empty_left_grid_row(target_ws, row):
            for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
                apply_cell_template_style(target_ws, template_ws, row, col, week, template_week)
        if row == DETAIL_HEADER_ROW or is_detail:
            for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                apply_cell_template_style(target_ws, template_ws, row, col, week, template_week)

    restore_detail_log_headers(target_ws, template_ws)
    clear_detail_log_fill(target_ws)
    apply_employee_grid_styles(target_ws, template_ws)
    restore_week_label_column(target_ws, template_ws)
    fix_detail_log_formulas(target_ws)
    clear_separator_row_fills(target_ws)

    if realign_layout:
        realign_sheet_layout(target_ws, template_ws)


def restore_detail_log_headers(ws: Worksheet, template_ws: Worksheet) -> None:
    for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
        src = template_ws.cell(DETAIL_HEADER_ROW, col)
        dst = ws.cell(DETAIL_HEADER_ROW, col)
        dst.value = src.value
        copy_cell_style(src, dst, skip_fill=True)
        dst.fill = NO_FILL


def clear_detail_log_fill(ws: Worksheet) -> None:
    for row in range(1, ws.max_row + 1):
        for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
            ws.cell(row, col).fill = NO_FILL


def apply_employee_grid_styles(ws: Worksheet, template_ws: Worksheet) -> None:
    """Copy exact per-cell styling from May for employee rows, totals, and week headers."""
    template_weeks = find_week_sections(template_ws)
    for idx, week in enumerate(find_week_sections(ws)):
        template_week = template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
        for excel_name, row in week.employee_rows.items():
            ref_row = (
                TEMPLATE_FRANKLIN_ROW
                if is_franklin_employee(excel_name)
                else TEMPLATE_NORMAL_EMPLOYEE_ROW
            )
            for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
                copy_cell_style(template_ws.cell(ref_row, col), ws.cell(row, col))
                if col in DAY_COLS:
                    ws.cell(row, col).number_format = DAY_HOURS_FORMAT
        if week.total_row and template_week.total_row:
            for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
                copy_cell_style(
                    template_ws.cell(template_week.total_row, col),
                    ws.cell(week.total_row, col),
                )
        # Week header bar (both merged rows) — May yellow/green/theme by week index
        for offset in (0, 1):
            target_row = week.header_row + offset
            template_row = template_week.header_row
            for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
                copy_cell_style(
                    template_ws.cell(template_row, col),
                    ws.cell(target_row, col),
                )
        for target_row, template_row in (
            (week.date_row, template_week.date_row),
            (week.employee_header_row, template_week.employee_header_row),
        ):
            if not target_row or not template_row:
                continue
            for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
                copy_cell_style(
                    template_ws.cell(template_row, col),
                    ws.cell(target_row, col),
                )


STANDARD_WEEK_LABELS = ["1st Week", "2nd Week", "3rd Week", "4th Week", "5th Week"]


def restore_week_label_column(ws: Worksheet, template_ws: Worksheet) -> None:
    """Restore AB week labels — delegates to live week-block merges."""
    src_header = template_ws.cell(1, WEEK_LABEL_COL)
    dst_header = ws.cell(1, WEEK_LABEL_COL)
    dst_header.value = src_header.value
    copy_cell_style(src_header, dst_header)
    restore_week_ab_merges(ws, template_ws)


def apply_new_employee_row_formatting(
    ws: Worksheet,
    template_ws: Worksheet,
    row: int,
    week: Optional[WeekSection] = None,
    template_week: Optional[WeekSection] = None,
    excel_name: str = "",
) -> None:
    # Only Franklin gets yellow row style; everyone else uses normal employee style.
    if is_franklin_employee(excel_name):
        ref_row = TEMPLATE_FRANKLIN_ROW
    else:
        ref_row = TEMPLATE_NORMAL_EMPLOYEE_ROW
    for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
        copy_cell_style(template_ws.cell(ref_row, col), ws.cell(row, col))
        if col in DAY_COLS:
            ws.cell(row, col).number_format = DAY_HOURS_FORMAT
    for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
        ws.cell(row, col).fill = NO_FILL


def apply_detail_row_formatting(ws: Worksheet, template_ws: Worksheet, row: int) -> None:
    if not is_detail_entry_row(ws, row):
        return
    for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
        copy_cell_style(template_ws.cell(TEMPLATE_DETAIL_ROW, col), ws.cell(row, col), skip_fill=True)
        ws.cell(row, col).fill = NO_FILL


def fix_detail_log_formulas(ws: Worksheet) -> int:
    fixed = 0
    for row in range(1, ws.max_row + 1):
        if not is_detail_entry_row(ws, row):
            continue
        expected_u = f"=T{row}-S{row}"
        expected_x = f"=U{row}*W{row}*24"
        expected_aa = f"=X{row}+Y{row}-Z{row}"
        if ws.cell(row, DETAIL_COLS["total_hours"]).value != expected_u:
            ws.cell(row, DETAIL_COLS["total_hours"]).value = expected_u
            fixed += 1
        if ws.cell(row, DETAIL_COLS["salary"]).value != expected_x:
            ws.cell(row, DETAIL_COLS["salary"]).value = expected_x
            fixed += 1
        if ws.cell(row, DETAIL_COLS["total_salary"]).value != expected_aa:
            ws.cell(row, DETAIL_COLS["total_salary"]).value = expected_aa
            fixed += 1
    return fixed


def find_ghost_rows(ws: Worksheet) -> list[int]:
    ghosts: set[int] = set()
    for row in range(1, ws.max_row + 1):
        label = ws.cell(row, 1).value
        b_val = ws.cell(row, 2).value
        b_fmt = ws.cell(row, 2).number_format
        if (
            label in (None, "")
            and isinstance(b_val, str)
            and b_val.startswith("=SUM(B")
            and b_fmt == "General"
        ):
            ghosts.add(row)

    for week in find_week_sections(ws):
        if not week.employee_rows or not week.total_row:
            continue
        emp_rows = set(week.employee_rows.values())
        for row in range(min(emp_rows), week.total_row):
            if row in emp_rows:
                continue
            if ws.cell(row, 1).value:
                continue
            if ws.cell(row, 11).value or ws.cell(row, 15).value:
                ghosts.add(row)
    return sorted(ghosts, reverse=True)


def remove_ghost_rows(ws: Worksheet) -> list[int]:
    removed: list[int] = []
    for row in find_ghost_rows(ws):
        ws.delete_rows(row, 1)
        removed.append(row)
    return removed


def unmerge_all_cells(ws: Worksheet) -> None:
    for merged_range in list(ws.merged_cells.ranges):
        try:
            ws.unmerge_cells(str(merged_range))
        except KeyError:
            pass
    for key, cell in list(ws._cells.items()):
        if isinstance(cell, MergedCell):
            del ws._cells[key]


def set_cell_value(ws: Worksheet, row: int, col: int, value) -> None:
    write_row, write_col = row, col
    for merged_range in list(ws.merged_cells.ranges):
        min_col, min_row, max_col, max_row = merged_range.bounds
        if min_row <= row <= max_row and min_col <= col <= max_col:
            write_row, write_col = min_row, min_col
            break

    cell = ws.cell(row=write_row, column=write_col)
    if isinstance(cell, MergedCell):
        for merged_range in list(ws.merged_cells.ranges):
            min_col, min_row, max_col, max_row = merged_range.bounds
            if min_row <= write_row <= max_row and min_col <= write_col <= max_col:
                try:
                    ws.unmerge_cells(str(merged_range))
                except KeyError:
                    pass
        stale = [
            key
            for key, existing in list(ws._cells.items())
            if isinstance(existing, MergedCell)
            and existing.row == write_row
            and existing.column == write_col
        ]
        for key in stale:
            del ws._cells[key]
        cell = ws.cell(row=write_row, column=write_col)
    cell.value = value


def realign_sheet_layout(ws: Worksheet, template_ws: Worksheet) -> None:
    template_weeks = find_week_sections(template_ws)
    target_weeks = find_week_sections(ws)
    if len(template_weeks) != len(target_weeks):
        return

    for merged in list(ws.merged_cells.ranges):
        try:
            ws.unmerge_cells(str(merged))
        except KeyError:
            pass
    unmerge_all_cells(ws)

    week_labels = ["1st Week", "2nd Week", "3rd Week", "4th Week", "5th Week"]
    label_rows: list[int] = [2, 22]
    for week in target_weeks[2:]:
        label_rows.append(week.header_row)

    for idx, label_row in enumerate(label_rows):
        if idx < len(week_labels):
            set_cell_value(ws, label_row, WEEK_LABEL_COL, week_labels[idx])

    ws.merge_cells("A1:O1")
    ws.merge_cells("A2:O3")
    ws.merge_cells("A22:O23")
    ws.merge_cells("AB2:AB21")
    ws.merge_cells("AB22:AB42")

    for idx, week in enumerate(target_weeks):
        header = week.header_row
        ws.merge_cells(f"A{header}:O{header + 1}")
        if idx >= 2:
            if idx + 1 < len(target_weeks):
                ab_end = target_weeks[idx + 1].header_row - 1
            else:
                ab_end = max(week.end_row, header + 10)
            ws.merge_cells(f"AB{header}:AB{ab_end}")

    if template_ws.sheet_view.topLeftCell:
        ws.sheet_view.topLeftCell = template_ws.sheet_view.topLeftCell


def repair_month_sheet_structure(wb: openpyxl.Workbook, sheet_name: str) -> None:
    guard_not_template(wb[sheet_name])
    ws = wb[sheet_name]
    template_ws = wb[TEMPLATE_SHEET]
    registry = build_worker_registry(wb)

    removed = remove_ghost_rows(ws)
    if removed:
        print(f"  Removed ghost rows: {removed}")

    fix_detail_log_formulas(ws)
    relink_employee_day_formulas(ws, registry)
    fix_all_employee_formulas(ws)

    for row in range(1, ws.max_row + 1):
        if is_detail_entry_row(ws, row):
            apply_detail_row_formatting(ws, template_ws, row)

    apply_month_sheet_formatting(wb, sheet_name, include_merges=False, realign_layout=True)

    fix_detail_log_formulas(ws)
    relink_employee_day_formulas(ws, registry)
    fix_all_employee_formulas(ws)

    for row in range(1, ws.max_row + 1):
        if is_detail_entry_row(ws, row):
            apply_detail_row_formatting(ws, template_ws, row)


def week_detail_last_row(weeks: list[WeekSection], week_index: int) -> int:
    if week_index + 1 < len(weeks):
        return weeks[week_index + 1].header_row
    return weeks[week_index].end_row


def find_detail_row_for_worker_date(
    ws: Worksheet,
    week: WeekSection,
    worker_short: str,
    work_date: date,
    stop_row: Optional[int] = None,
) -> Optional[int]:
    """Detail row for worker+date inside week band (scan stops before next week header)."""
    weeks = find_week_sections(ws)
    stop = stop_row if stop_row is not None else next_week_header_row(weeks, week)
    for row_idx in range(week.header_row, stop):
        name = ws.cell(row_idx, DETAIL_COLS["name"]).value
        dt = ws.cell(row_idx, DETAIL_COLS["date"]).value
        if not name or not isinstance(dt, datetime):
            continue
        if dt.date() != work_date:
            continue
        if not worker_names_match(worker_short, str(name)):
            continue
        if ws.cell(row_idx, DETAIL_COLS["time_in"]).value and ws.cell(
            row_idx, DETAIL_COLS["time_out"]
        ).value:
            return row_idx
    return None


def relink_employee_day_formulas(
    ws: Worksheet,
    registry: WorkerRegistry,
    wb: Optional[openpyxl.Workbook] = None,
) -> None:
    weeks = find_week_sections(ws)
    for week_index, week in enumerate(weeks):
        stop = next_week_header_row(weeks, week)
        for excel_name, employee_row in week.employee_rows.items():
            short_name = registry.short_for(excel_name)
            for col, work_date in week.dates.items():
                detail_row = find_detail_row_for_worker_date(
                    ws, week, short_name, work_date, stop_row=stop
                )
                if not detail_row:
                    ws.cell(employee_row, col).value = time(0, 0)
                    continue
                t_in = ws.cell(detail_row, DETAIL_COLS["time_in"]).value
                t_out = ws.cell(detail_row, DETAIL_COLS["time_out"]).value
                if not (t_in and t_out):
                    ws.cell(employee_row, col).value = time(0, 0)
                    continue
                if wb is not None:
                    link_employee_day_to_detail(
                        ws, wb, employee_row, col, detail_row, week, t_in, t_out
                    )
                elif detail_row == employee_row:
                    ws.cell(employee_row, col).value = time_to_excel_duration(t_in, t_out)
                    ws.cell(employee_row, col).number_format = DAY_HOURS_FORMAT
                else:
                    ws.cell(employee_row, col).value = f"=U{detail_row}"


def initialize_month_sheet(ws: Worksheet, year: int, month: int) -> None:
    month_name = calendar.month_name[month]
    ws.cell(1, 1).value = f"{month_name} Attendence {year}"
    weeks = find_week_sections(ws)
    target_ranges = month_week_ranges(year, month)

    for week, (start, end) in zip(weeks, target_ranges):
        clear_week_attendance(ws, week)
        update_week_dates(ws, week, start, end)

    # Clear leftover detail rows below last week
    if weeks:
        last = weeks[-1]
        for row in range(last.end_row + 1, ws.max_row + 1):
            for col in range(DETAIL_COLS["date"], DETAIL_LOG_LAST_COL + 1):
                ws.cell(row, col).value = None


def get_employee_names(ws: Worksheet) -> dict[str, str]:
    names: dict[str, str] = {}
    for week in find_week_sections(ws):
        names.update(week.employee_rows)
    return names


def find_week_for_date(weeks: list[WeekSection], d: date) -> Optional[WeekSection]:
    for week in weeks:
        if week.dates:
            week_dates = week.dates.values()
            if min(week_dates) <= d <= max(week_dates):
                return week
    return None


def find_day_col(week: WeekSection, d: date) -> Optional[int]:
    for col, wd in week.dates.items():
        if wd == d:
            return col
    return None


def cell_is_filled(ws: Worksheet, row: int, col: int) -> bool:
    val = ws.cell(row, col).value
    if isinstance(val, str) and val.startswith("=U"):
        ref_row = int(re.search(r"U(\d+)", val).group(1))
        ref_date = ws.cell(ref_row, DETAIL_COLS["date"]).value
        return ref_date is not None
    if isinstance(val, time):
        return val != time(0, 0)
    if isinstance(val, timedelta):
        return val.total_seconds() > 0
    return val is not None


def existing_detail_entries(ws: Worksheet) -> set[tuple[str, date, time, time]]:
    entries: set[tuple[str, date, time, time]] = set()
    for row in range(1, ws.max_row + 1):
        name = ws.cell(row, DETAIL_COLS["name"]).value
        dt = ws.cell(row, DETAIL_COLS["date"]).value
        t_in = ws.cell(row, DETAIL_COLS["time_in"]).value
        t_out = ws.cell(row, DETAIL_COLS["time_out"]).value
        if name and name != "Name" and isinstance(dt, datetime) and t_in and t_out:
            entries.add((str(name), dt.date(), t_in, t_out))
    return entries


def is_duplicate_detail_entry(
    ws: Worksheet,
    worker: str,
    work_date: date,
    t_in: time,
    t_out: time,
) -> bool:
    for name, dt, existing_in, existing_out in existing_detail_entries(ws):
        if not worker_names_match(worker, name):
            continue
        if dt == work_date and existing_in == t_in and existing_out == t_out:
            return True
    return False


def is_week_header_row(ws: Worksheet, row: int) -> bool:
    val = ws.cell(row, 1).value
    return bool(val and " To " in str(val))


def is_empty_left_grid_row(ws: Worksheet, row: int) -> bool:
    for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
        if ws.cell(row, col).value not in (None, ""):
            return False
    return True


def next_week_header_row(weeks: list[WeekSection], week: WeekSection) -> int:
    for w in weeks:
        if w.header_row > week.header_row:
            return w.header_row
    return weeks[-1].end_row + 1


def reserved_detail_rows(ws: Worksheet, week: WeekSection) -> set[int]:
    # April/May overlap model: detail may live on header, date, employee, or separator rows.
    return set()


def fix_detail_row_formulas(ws: Worksheet, row: int) -> None:
    if not is_detail_entry_row(ws, row):
        return
    ws.cell(row, DETAIL_COLS["time_in"]).number_format = DAY_HOURS_FORMAT
    ws.cell(row, DETAIL_COLS["time_out"]).number_format = DAY_HOURS_FORMAT
    ws.cell(row, DETAIL_COLS["total_hours"]).value = f"=T{row}-S{row}"
    ws.cell(row, DETAIL_COLS["total_hours"]).number_format = DETAIL_HOURS_FORMAT
    ws.cell(row, DETAIL_COLS["salary"]).value = f"=U{row}*W{row}*24"
    ws.cell(row, DETAIL_COLS["total_salary"]).value = f"=X{row}+Y{row}-Z{row}"


def reset_week_employee_formulas(ws: Worksheet, week: WeekSection) -> None:
    for excel_name, row in week.employee_rows.items():
        ws.cell(row, 11).value = f"=O{row}*J{row}*24"
        if is_franklin_employee(excel_name):
            ws.cell(row, 12).value = None
        elif ws.cell(row, 12).value is None:
            ws.cell(row, 12).value = time(0, 0)
        ws.cell(row, 13).value = f"=L{row}*J{row}*24"
        ws.cell(row, 14).value = f"=K{row}+M{row}"
        ws.cell(row, 15).value = f"=SUM(B{row}:H{row})"
    recalculate_week_totals(ws, week)


def reset_month_employee_formulas(ws: Worksheet) -> None:
    guard_not_template(ws)
    for week in find_week_sections(ws):
        reset_week_employee_formulas(ws, week)


def validate_detail_row(ws: Worksheet, row: int, week: WeekSection) -> bool:
    if not is_detail_entry_row(ws, row):
        return False
    t_in = ws.cell(row, DETAIL_COLS["time_in"]).value
    t_out = ws.cell(row, DETAIL_COLS["time_out"]).value
    return t_in is not None and t_out is not None


def repair_bad_day_links(
    ws: Worksheet,
    registry: WorkerRegistry,
    wb: Optional[openpyxl.Workbook] = None,
) -> int:
    """Fix self =U links, broken refs, and links pointing at another worker's detail row."""
    guard_not_template(ws)
    relink_employee_day_formulas(ws, registry, wb)
    fixed = 0
    weeks = find_week_sections(ws)
    for week in weeks:
        stop = next_week_header_row(weeks, week)
        for excel_name, erow in week.employee_rows.items():
            short_name = registry.short_for(excel_name)
            for col, work_date in week.dates.items():
                val = ws.cell(erow, col).value
                if not isinstance(val, str) or not val.startswith("=U"):
                    continue
                ref = int(re.search(r"U(\d+)", val).group(1))
                correct = find_detail_row_for_worker_date(
                    ws, week, short_name, work_date, stop_row=stop
                )
                if correct and correct != ref:
                    t_in = ws.cell(correct, DETAIL_COLS["time_in"]).value
                    t_out = ws.cell(correct, DETAIL_COLS["time_out"]).value
                    if t_in and t_out:
                        if wb is not None:
                            link_employee_day_to_detail(
                                ws, wb, erow, col, correct, week, t_in, t_out
                            )
                        elif correct == erow:
                            ws.cell(erow, col).value = time_to_excel_duration(t_in, t_out)
                        else:
                            ws.cell(erow, col).value = f"=U{correct}"
                        fixed += 1
                        continue
                detail_name = ws.cell(ref, DETAIL_COLS["name"]).value
                t_in = ws.cell(ref, DETAIL_COLS["time_in"]).value
                t_out = ws.cell(ref, DETAIL_COLS["time_out"]).value
                if ref == erow or (
                    detail_name
                    and not worker_names_match(short_name, str(detail_name))
                ):
                    if correct:
                        t_in = ws.cell(correct, DETAIL_COLS["time_in"]).value
                        t_out = ws.cell(correct, DETAIL_COLS["time_out"]).value
                    if correct and t_in and t_out:
                        if wb is not None:
                            link_employee_day_to_detail(
                                ws, wb, erow, col, correct, week, t_in, t_out
                            )
                        elif correct == erow:
                            ws.cell(erow, col).value = time_to_excel_duration(t_in, t_out)
                        else:
                            ws.cell(erow, col).value = f"=U{correct}"
                    else:
                        ws.cell(erow, col).value = time(0, 0)
                    fixed += 1
                elif t_in is None or t_out is None:
                    ws.cell(erow, col).value = time(0, 0)
                    fixed += 1
    return fixed


def validate_month_sheet(ws: Worksheet) -> list[str]:
    guard_not_template(ws)
    issues: list[str] = []
    weeks = find_week_sections(ws)

    if len(weeks) != 5:
        issues.append(f"{ws.title}: expected 5 week sections, found {len(weeks)}")

    for week in weeks:
        title = ws.cell(week.header_row, 1).value
        if not title or " To " not in str(title):
            issues.append(f"{ws.title} week header row {week.header_row}: bad title {title!r}")

    for week in weeks:
        for excel_name, erow in week.employee_rows.items():
            o_val = ws.cell(erow, 15).value
            expected_o = f"=SUM(B{erow}:H{erow})"
            if o_val != expected_o:
                issues.append(f"{ws.title} {excel_name} row {erow} col O: {o_val!r}")

            for col in DAY_COLS:
                val = ws.cell(erow, col).value
                if not isinstance(val, str) or not val.startswith("=U"):
                    continue
                ref = int(re.search(r"U(\d+)", val).group(1))
                if ref == erow:
                    issues.append(
                        f"{ws.title} {excel_name} row {erow} col {col}: self =U{ref} link"
                    )
                t_in = ws.cell(ref, DETAIL_COLS["time_in"]).value
                t_out = ws.cell(ref, DETAIL_COLS["time_out"]).value
                if t_in is None or t_out is None:
                    issues.append(
                        f"{ws.title} {excel_name} col {col} =U{ref} has no S/T on detail row"
                    )

    for row in range(1, ws.max_row + 1):
        if not is_detail_entry_row(ws, row):
            continue
        u_val = ws.cell(row, DETAIL_COLS["total_hours"]).value
        expected_u = f"=T{row}-S{row}"
        if u_val != expected_u:
            name = ws.cell(row, DETAIL_COLS["name"]).value
            issues.append(f"{ws.title} detail row {row} ({name}) U formula: {u_val!r}")

    return issues


def clear_separator_row_fills(ws: Worksheet) -> list[int]:
    """Remove grey/color fill from empty rows immediately above week headers."""
    cleared: list[int] = []
    weeks = find_week_sections(ws)
    for week in weeks:
        for row in range(max(1, week.header_row - 3), week.header_row):
            if not is_empty_left_grid_row(ws, row):
                continue
            for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
                ws.cell(row, col).fill = NO_FILL
            cleared.append(row)
    return cleared


def insert_row_before(ws: Worksheet, row: int) -> int:
    ws.insert_rows(row)
    return row


def insert_detail_row_after_total(ws: Worksheet, week: WeekSection) -> int:
    """Insert a detail row after Total, inside the current week — never before next week header."""
    if week.total_row:
        insert_at = week.total_row + 1
    elif week.employee_rows:
        insert_at = max(week.employee_rows.values()) + 1
    else:
        insert_at = week.header_row + 1
    ws.insert_rows(insert_at)
    return insert_at


def insert_detail_row_before_header(ws: Worksheet, header_row: int) -> int:
    """Insert a detail row immediately before a week header, preserving the header merge."""
    title = ws.cell(header_row, 1).value
    unmerge_at(ws, header_row, 1)
    insert_row_before(ws, header_row)
    new_header_row = header_row + 1
    if title:
        ws.cell(new_header_row, 1).value = title
        ws.merge_cells(f"A{new_header_row}:O{new_header_row + 1}")
    return header_row


def clear_week_label_merges(ws: Worksheet) -> None:
    """Remove merges touching column AB — tolerate corrupt merge metadata."""
    for merged in list(ws.merged_cells.ranges):
        if merged.min_col <= WEEK_LABEL_COL <= merged.max_col:
            try:
                ws.unmerge_cells(str(merged))
            except KeyError:
                try:
                    ws.merged_cells.ranges.remove(merged)
                except (KeyError, ValueError, AttributeError):
                    pass


def ensure_writable_cell(ws: Worksheet, row: int, col: int):
    from openpyxl.cell.cell import Cell, MergedCell

    cell = ws.cell(row, col)
    if isinstance(cell, MergedCell):
        unmerge_at(ws, row, col)
        cell = ws.cell(row, col)
    if isinstance(cell, MergedCell):
        ws._cells[(row, col)] = Cell(ws, row=row, column=col)
    return ws.cell(row, col)


def unmerge_at(ws: Worksheet, row: int, col: int) -> None:
    for merged in list(ws.merged_cells.ranges):
        if merged.min_row <= row <= merged.max_row and merged.min_col <= col <= merged.max_col:
            try:
                ws.unmerge_cells(str(merged))
            except KeyError:
                pass


def find_free_detail_row(
    ws: Worksheet,
    week: WeekSection,
    employee_row: Optional[int] = None,
) -> Optional[int]:
    """Free detail row in week band — March/May order: top-down from header."""
    weeks = find_week_sections(ws)
    stop = next_week_header_row(weeks, week)
    reserved = detail_reserved_rows(week)
    emp_rows = set(week.employee_rows.values())
    other_emp_rows = {r for r in emp_rows if employee_row is None or r != employee_row}

    def is_free(row: int) -> bool:
        if row in reserved:
            return False
        return ws.cell(row, DETAIL_COLS["date"]).value is None

    # Prefer non-employee free rows (header/date/gaps), then own employee row, then after Total
    for row in range(week.header_row, stop):
        if row in other_emp_rows:
            continue
        if row in emp_rows and (employee_row is None or row != employee_row):
            continue
        if is_free(row):
            return row
    return None


def relocate_misplaced_detail_entries(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    registry: WorkerRegistry,
) -> int:
    """Move detail off another worker's employee row — keeps May overlap layout."""
    guard_not_template(ws)
    moved = 0
    for week in find_week_sections(ws):
        for excel_name, erow in list(week.employee_rows.items()):
            if not is_detail_entry_row(ws, erow):
                continue
            detail_name = str(ws.cell(erow, DETAIL_COLS["name"]).value or "")
            short = registry.short_for(excel_name)
            if worker_names_match(short, detail_name):
                continue

            dt = ws.cell(erow, DETAIL_COLS["date"]).value
            t_in = ws.cell(erow, DETAIL_COLS["time_in"]).value
            t_out = ws.cell(erow, DETAIL_COLS["time_out"]).value
            if not isinstance(dt, datetime) or not (t_in and t_out):
                continue

            work_date = dt.date()
            worker_short = canonical_worker_short(detail_name, registry)
            if not worker_short:
                continue
            profile = lookup_worker_profile(wb, registry, worker_short, worker_short)
            weeks = find_week_sections(ws)
            stop = next_week_header_row(weeks, week)
            existing = find_detail_row_for_worker_date(
                ws, week, worker_short, work_date, stop_row=stop
            )
            if existing and existing != erow:
                for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                    ws.cell(erow, col).value = None
                moved += 1
                continue

            worker_row = resolve_employee_row(ws, week, registry, profile)
            target_row = find_free_detail_row(ws, week, employee_row=worker_row)
            if target_row is None:
                grow_week_detail_slots(ws, wb, week, 1)
                weeks = find_week_sections(ws)
                week = week_by_header(ws, week.header_row)
                if week is None:
                    continue
                worker_row = resolve_employee_row(ws, week, registry, profile)
                target_row = find_free_detail_row(ws, week, employee_row=worker_row)
            if target_row is None or target_row == erow:
                continue

            empty_break = profile.empty_break_hours
            for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                ws.cell(erow, col).value = None

            write_detail_entry(
                ws,
                target_row,
                profile.short_name,
                work_date,
                t_in,
                t_out,
                empty_break,
                wb,
                week,
                profile.hourly_rate,
                worker_row,
            )
            if worker_row:
                day_col = find_day_col(week, work_date)
                if day_col:
                    link_employee_day_to_detail(
                        ws, wb, worker_row, day_col, target_row, week, t_in, t_out
                    )
            moved += 1
    return moved


def relocate_misplaced_detail_entries(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    registry: WorkerRegistry,
) -> int:
    """Move detail off another worker's employee row — keeps May overlap layout."""
    guard_not_template(ws)
    moved = 0
    for week in find_week_sections(ws):
        for excel_name, erow in list(week.employee_rows.items()):
            if not is_detail_entry_row(ws, erow):
                continue
            detail_name = str(ws.cell(erow, DETAIL_COLS["name"]).value or "")
            short = registry.short_for(excel_name)
            if worker_names_match(short, detail_name):
                continue

            dt = ws.cell(erow, DETAIL_COLS["date"]).value
            t_in = ws.cell(erow, DETAIL_COLS["time_in"]).value
            t_out = ws.cell(erow, DETAIL_COLS["time_out"]).value
            if not isinstance(dt, datetime) or not (t_in and t_out):
                continue

            profile = lookup_worker_profile(wb, registry, detail_name, detail_name)
            target_row = find_free_detail_row(
                ws, week, employee_row=resolve_employee_row(ws, week, registry, profile)
            )
            if target_row is None or target_row == erow:
                grow_week_detail_slots(ws, wb, week, 1)
                weeks = find_week_sections(ws)
                week = week_by_header(ws, week.header_row)
                if week is None:
                    break
                target_row = find_free_detail_row(
                    ws, week, employee_row=resolve_employee_row(ws, week, registry, profile)
                )
            if target_row is None or target_row == erow:
                continue

            for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                ws.cell(target_row, col).value = ws.cell(erow, col).value
                ws.cell(erow, col).value = None
            fix_detail_row_formulas(ws, target_row)
            moved += 1
    return moved


def grow_week_detail_slots(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    week: WeekSection,
    count: int,
) -> int:
    """Insert detail buffer rows before next week header — keeps overlap band tight."""
    if count <= 0:
        return 0
    weeks = find_week_sections(ws)
    stop = next_week_header_row(weeks, week)
    template_ws = wb[TEMPLATE_SHEET]
    ws.insert_rows(stop, count)
    if week.end_row >= stop:
        week.end_row += count
    for row in range(stop, stop + count):
        prepare_detail_buffer_row(ws, template_ws, row)
    return count


def ensure_week_ready_for_writes(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    week: WeekSection,
    week_load: WeekLoad,
    registry: WorkerRegistry,
    stats: Stats,
) -> None:
    """Left table: add missing workers. Right band: grow detail slots if chat needs more."""
    header = week.header_row
    for short in sorted(week_load.worker_shorts):
        if not is_valid_worker_short(short):
            continue
        profile = lookup_worker_profile(wb, registry, short, short)
        if resolve_existing_worker_row(ws, week, registry, profile) is not None:
            continue
        if profile.excel_name in week.employee_rows:
            continue
        ensure_worker_in_week(wb, ws, week, short, short, registry, stats)

    weeks = find_week_sections(ws)
    week = week_by_header(ws, header)
    if week is None:
        return
    stop = next_week_header_row(weeks, week)
    free = free_detail_slot_count(ws, week, stop)
    needed = week_load.entry_count + DETAIL_SLOT_BUFFER
    if free < needed:
        grow_week_detail_slots(ws, wb, week, needed - free)
    restore_all_week_header_merges(ws)


def link_employee_day_to_detail(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    employee_row: int,
    day_col: int,
    detail_row: int,
    week: WeekSection,
    t_in: time,
    t_out: time,
) -> None:
    """Link day column to detail hours — never =U on same row (avoids circular ref)."""
    if detail_row == employee_row:
        write_cell(
            ws,
            wb,
            employee_row,
            day_col,
            time_to_excel_duration(t_in, t_out),
            week,
            None,
        )
    else:
        write_cell(ws, wb, employee_row, day_col, f"=U{detail_row}", week, None)


def move_detail_off_header_rows(ws: Worksheet, wb: openpyxl.Workbook) -> list[str]:
    """Move detail-log entries on week headers when the date is outside that week's range."""
    actions: list[str] = []
    registry = build_worker_registry(wb)

    while True:
        weeks = find_week_sections(ws)
        moved = False
        for week in weeks:
            header = week.header_row
            dt = ws.cell(header, DETAIL_COLS["date"]).value
            if not isinstance(dt, datetime):
                continue
            work_date = dt.date()
            if work_date in week.dates.values():
                continue

            name = ws.cell(header, DETAIL_COLS["name"]).value
            t_in = ws.cell(header, DETAIL_COLS["time_in"]).value
            t_out = ws.cell(header, DETAIL_COLS["time_out"]).value
            if not (name and t_in and t_out):
                continue

            target_week = find_week_for_date(weeks, work_date)
            if not target_week:
                continue

            for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                ws.cell(header, col).value = None

            detail_row = find_free_detail_row(ws, target_week, employee_row=None)
            if detail_row is None:
                break
            weeks = find_week_sections(ws)
            target_week = find_week_for_date(weeks, work_date)
            if not target_week:
                break

            empty_break = False
            profile_for_link: Optional[WorkerProfile] = None
            for excel_name, profile in registry.profiles.items():
                if worker_names_match(registry.short_for(excel_name), str(name)):
                    empty_break = profile.empty_break_hours
                    profile_for_link = profile
                    break

            write_detail_entry(
                ws,
                detail_row,
                str(name),
                work_date,
                t_in,
                t_out,
                empty_break,
                wb,
                target_week,
            )

            if profile_for_link:
                erow = resolve_employee_row(ws, target_week, registry, profile_for_link)
                day_col = find_day_col(target_week, work_date)
                if erow and day_col:
                    link_employee_day_to_detail(
                        ws, wb, erow, day_col, detail_row, target_week, t_in, t_out
                    )

            actions.append(
                f"Moved {work_date} {name} from header row {header} to detail row {detail_row}"
            )
            moved = True
            break
        if not moved:
            break

    return actions


def fix_month_sheet_structure(wb: openpyxl.Workbook, sheet_name: str) -> list[str]:
    """Structural repairs: separator fills, header detail rows, formulas."""
    guard_not_template(wb[sheet_name])
    ws = wb[sheet_name]
    registry = build_worker_registry(wb)
    log: list[str] = []

    removed = remove_ghost_rows(ws)
    if removed:
        log.append(f"Removed ghost rows: {removed}")

    moved = move_detail_off_header_rows(ws, wb)
    log.extend(moved)

    cleared = clear_separator_row_fills(ws)
    if cleared:
        log.append(f"Cleared separator fills on rows: {cleared}")

    fix_detail_log_formulas(ws)
    relink_employee_day_formulas(ws, registry)
    fix_all_employee_formulas(ws)
    apply_month_sheet_formatting(wb, sheet_name, include_merges=False)
    clear_separator_row_fills(ws)
    fix_detail_log_formulas(ws)
    relink_employee_day_formulas(ws, registry)
    fix_all_employee_formulas(ws)
    return log


def write_detail_entry(
    ws: Worksheet,
    row: int,
    worker_short: str,
    work_date: date,
    t_in: time,
    t_out: time,
    empty_break_hours: bool,
    wb: Optional[openpyxl.Workbook] = None,
    week: Optional[WeekSection] = None,
    hourly_rate: Optional[float] = None,
    employee_row: Optional[int] = None,
) -> None:
    entries = {
        DETAIL_COLS["date"]: datetime.combine(work_date, time.min),
        DETAIL_COLS["day"]: calendar.day_name[work_date.weekday()],
        DETAIL_COLS["name"]: worker_short,
        DETAIL_COLS["time_in"]: t_in,
        DETAIL_COLS["time_out"]: t_out,
        DETAIL_COLS["total_hours"]: f"=T{row}-S{row}",
        DETAIL_COLS["break"]: "-" if is_franklin_employee(worker_short) else "No",
        DETAIL_COLS["salary"]: f"=U{row}*W{row}*24",
        DETAIL_COLS["total_salary"]: f"=X{row}+Y{row}-Z{row}",
    }
    if not is_franklin_employee(worker_short):
        if employee_row:
            j_val = ws.cell(employee_row, 10).value if employee_row else None
            if j_val is not None:
                entries[DETAIL_COLS["per_hour"]] = f"=J{employee_row}"
            elif hourly_rate is not None:
                entries[DETAIL_COLS["per_hour"]] = hourly_rate
        elif hourly_rate is not None:
            entries[DETAIL_COLS["per_hour"]] = hourly_rate
    template_week = None
    if wb and week:
        template_weeks = find_week_sections(wb[TEMPLATE_SHEET])
        target_weeks = find_week_sections(ws)
        for idx, tw in enumerate(target_weeks):
            if tw.header_row == week.header_row:
                template_week = template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
                break
    guard_not_template(ws)
    for col, value in entries.items():
        ws.cell(row, col).value = value
    if wb and week and template_week:
        template_ws = wb[TEMPLATE_SHEET]
        for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
            apply_cell_template_style(ws, template_ws, row, col, week, template_week)
    elif wb:
        apply_detail_row_formatting(ws, wb[TEMPLATE_SHEET], row)
    fix_detail_row_formulas(ws, row)


def recalculate_employee_week(
    ws: Worksheet,
    week: WeekSection,
    employee_row: int,
    worker_short: str,
    day_break_flags: dict[date, bool],
    empty_break_hours: bool,
) -> None:
    actual_name = str(ws.cell(employee_row, 1).value or worker_short)
    franklin = is_franklin_employee(actual_name) or is_franklin_employee(worker_short)
    total_break_hours = 0.0

    for col in DAY_COLS:
        val = ws.cell(employee_row, col).value
        day_hours = 0.0
        if isinstance(val, str) and val.startswith("=U"):
            ref = int(re.search(r"U(\d+)", val).group(1))
            t_in = ws.cell(ref, DETAIL_COLS["time_in"]).value
            t_out = ws.cell(ref, DETAIL_COLS["time_out"]).value
            if t_in and t_out:
                day_hours = duration_to_hours(time_to_excel_duration(t_in, t_out))
        elif isinstance(val, time) and val != time(0, 0):
            day_hours = duration_to_hours(val)

        work_d = week.dates.get(col)
        if (
            work_d
            and day_hours > 0
            and not franklin
            and day_break_flags.get(work_d, False)
        ):
            total_break_hours += day_hours * (5 / 60)

    if franklin:
        ws.cell(employee_row, 12).value = None
    else:
        ws.cell(employee_row, 12).value = hours_to_time(total_break_hours)


def recalculate_week_totals(ws: Worksheet, week: WeekSection) -> None:
    if not week.total_row or not week.employee_rows:
        return
    tr = week.total_row
    first = min(week.employee_rows.values())
    last = max(week.employee_rows.values())
    for col in DAY_COLS:
        ws.cell(tr, col).value = f"=SUM({get_column_letter(col)}{first}:{get_column_letter(col)}{last})"
    for col, col_letter in [(11, "K"), (12, "L"), (13, "M"), (14, "N"), (15, "O")]:
        ws.cell(tr, col).value = (
            f"=SUM({col_letter}{first}:{col_letter}{last})"
        )


def analyze_month_load(
    records: list[AttendanceRecord],
    year: int,
    month: int,
) -> MonthLoad:
    """Exact per-week entry counts and workers from parsed chat records."""
    ranges = month_week_ranges(year, month)
    weeks: list[WeekLoad] = []
    for start, end in ranges:
        week_recs = [
            r
            for r in records
            if r.work_date.year == year
            and r.work_date.month == month
            and start <= r.work_date <= end
        ]
        weeks.append(
            WeekLoad(
                start=start,
                end=end,
                entry_count=len(week_recs),
                worker_shorts={
                    r.worker for r in week_recs if is_valid_worker_short(r.worker)
                },
            )
        )
    return MonthLoad(year=year, month=month, weeks=weeks)


def detail_reserved_rows(week: WeekSection) -> set[int]:
    """Only Total row is off-limits — May overlap puts detail on employee rows too."""
    reserved: set[int] = set()
    if week.total_row:
        reserved.add(week.total_row)
    return reserved


def resolve_profile_hourly_rate(
    wb: openpyxl.Workbook,
    registry: WorkerRegistry,
    profile: WorkerProfile,
) -> Optional[float]:
    if profile.hourly_rate is not None:
        return profile.hourly_rate
    _, _, rate, _ = find_historical_employee(wb, registry, profile.short_name)
    if rate is not None:
        return rate
    if TEMPLATE_SHEET in wb.sheetnames:
        template_ws = wb[TEMPLATE_SHEET]
        for week in find_week_sections(template_ws):
            for ename, erow in week.employee_rows.items():
                if worker_names_match(profile.excel_name, ename) or worker_names_match(
                    profile.short_name, registry.short_for(ename)
                ):
                    rate = template_ws.cell(erow, 10).value
                    if rate is not None:
                        return rate
    return None


def sync_employee_hourly_rates(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    registry: WorkerRegistry,
) -> None:
    guard_not_template(ws)
    for week in find_week_sections(ws):
        for excel_name, erow in week.employee_rows.items():
            if ws.cell(erow, 10).value is not None:
                continue
            profile = registry.profile_for(registry.short_for(excel_name))
            if not profile:
                profile = WorkerProfile(
                    excel_name=excel_name,
                    short_name=registry.short_for(excel_name),
                )
            rate = resolve_profile_hourly_rate(wb, registry, profile)
            if rate is not None:
                ws.cell(erow, 10).value = rate


def restore_week_salary_summary(ws: Worksheet, wb: openpyxl.Workbook) -> None:
    """Point AF Week Colors formulas at live Total row N — not May-fixed row numbers."""
    guard_not_template(ws)
    if TEMPLATE_SHEET not in wb.sheetnames:
        return
    template_ws = wb[TEMPLATE_SHEET]
    weeks = find_week_sections(ws)

    for idx, ae_row in enumerate(WEEK_SUMMARY_AE_ROWS):
        if idx >= len(weeks):
            break
        week = weeks[idx]
        may_ae = template_ws.cell(WEEK_SUMMARY_AE_ROWS[idx], WEEK_SUMMARY_AE_COL)
        may_af = template_ws.cell(WEEK_SUMMARY_AE_ROWS[idx], WEEK_SUMMARY_AF_COL)
        dst_ae = ws.cell(ae_row, WEEK_SUMMARY_AE_COL)
        dst_af = ws.cell(ae_row, WEEK_SUMMARY_AF_COL)
        dst_ae.value = may_ae.value
        copy_cell_style(may_ae, dst_ae)
        if week.total_row:
            dst_af.value = f"=N{week.total_row}"
        copy_cell_style(may_af, dst_af)

    ws.cell(8, WEEK_SUMMARY_AE_COL).value = "Total Salary Send"
    ws.cell(8, WEEK_SUMMARY_AF_COL).value = "=SUM(AF2:AF7)"


def restore_week_ab_merges(ws: Worksheet, template_ws: Worksheet) -> None:
    """AB week labels: merge AB{header}:AB{end_row} with May vertical style."""
    guard_not_template(ws)
    clear_week_label_merges(ws)

    template_weeks = find_week_sections(template_ws)
    for idx, week in enumerate(find_week_sections(ws)):
        template_week = (
            template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
        )
        ab_end = week.end_row
        header = week.header_row
        label = (
            STANDARD_WEEK_LABELS[idx]
            if idx < len(STANDARD_WEEK_LABELS)
            else f"{idx + 1}th Week"
        )
        cell = ensure_writable_cell(ws, header, WEEK_LABEL_COL)
        cell.value = label
        ws.merge_cells(f"AB{header}:AB{ab_end}")
        src = template_ws.cell(template_week.header_row, WEEK_LABEL_COL)
        copy_cell_style(src, cell)
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            textRotation=255,
            wrap_text=src.alignment.wrap_text if src.alignment else False,
        )


def last_detail_row_in_week(ws: Worksheet, week: WeekSection, stop: int) -> Optional[int]:
    last = None
    for row in range(week.header_row, stop):
        if is_detail_entry_row(ws, row):
            last = row
    return last


def sanitize_orphan_day_links(ws: Worksheet) -> int:
    """Clear =U day links that point at rows with no detail S/T (e.g. after row shifts)."""
    guard_not_template(ws)
    fixed = 0
    for week in find_week_sections(ws):
        for erow in week.employee_rows.values():
            for col in DAY_COLS:
                val = ws.cell(erow, col).value
                if not isinstance(val, str) or not val.startswith("=U"):
                    continue
                ref = int(re.search(r"U(\d+)", val).group(1))
                t_in = ws.cell(ref, DETAIL_COLS["time_in"]).value
                t_out = ws.cell(ref, DETAIL_COLS["time_out"]).value
                if t_in is None or t_out is None:
                    ws.cell(erow, col).value = time(0, 0)
                    ws.cell(erow, col).number_format = DAY_HOURS_FORMAT
                    fixed += 1
    return fixed


def seat_week_roster_from_chat(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    week: WeekSection,
    week_load: WeekLoad,
    registry: WorkerRegistry,
    stats: Stats,
) -> None:
    """Creation-only: left grid = only this week's chat workers + Total."""
    guard_not_template(ws)
    if week.total_row is None:
        return

    shorts = sorted(s for s in week_load.worker_shorts if is_valid_worker_short(s))
    header = week.header_row
    template_ws = wb[TEMPLATE_SHEET]

    for erow in sorted(week.employee_rows.values(), reverse=True):
        ws.delete_rows(erow, 1)
        if week.total_row and erow < week.total_row:
            week.total_row -= 1
        week.end_row -= 1
    week.employee_rows.clear()

    weeks = find_week_sections(ws)
    week = week_by_header(ws, header)
    if week is None or not week.total_row:
        return

    if not shorts:
        reset_week_employee_formulas(ws, week)
        return

    insert_at = week.total_row
    for short in shorts:
        profile = lookup_worker_profile(wb, registry, short, short)
        if profile.excel_name in week.employee_rows:
            continue
        ws.insert_rows(insert_at)
        if week.total_row and insert_at <= week.total_row:
            week.total_row += 1
        week.end_row += 1
        for ename, erow in list(week.employee_rows.items()):
            if erow >= insert_at:
                week.employee_rows[ename] = erow + 1
        populate_employee_row(ws, insert_at, profile, wb, week, registry)
        week.employee_rows[profile.excel_name] = insert_at
        template_week = matching_template_week(wb, ws, week)
        apply_new_employee_row_formatting(
            ws, template_ws, insert_at, week, template_week, profile.excel_name
        )
        fix_employee_row_formulas(ws, insert_at)
        stats.auto_added_workers.add(profile.excel_name)
        stats.new_workers.append(
            f"{ws.title} | chat roster | added {profile.excel_name} at row {insert_at}"
        )
        insert_at += 1

    weeks = find_week_sections(ws)
    week = week_by_header(ws, header)
    if week:
        reset_week_employee_formulas(ws, week)


def trim_week_empty_tails(ws: Worksheet) -> int:
    """Delete empty rows after max(Total, last detail) so next week starts May-tight."""
    guard_not_template(ws)
    removed = 0
    # Walk weeks bottom-up so row deletes do not invalidate earlier headers
    for week_idx in range(len(find_week_sections(ws)) - 1, -1, -1):
        weeks = find_week_sections(ws)
        if week_idx >= len(weeks):
            continue
        week = weeks[week_idx]
        stop = next_week_header_row(weeks, week)
        last_detail = last_detail_row_in_week(ws, week, stop)
        keep_through = week.total_row or week.header_row
        if last_detail:
            keep_through = max(keep_through, last_detail)
        # May leaves a tiny tail (~1–2 empty) — keep DETAIL_SLOT_BUFFER max
        keep_through = min(stop - 1, keep_through + DETAIL_SLOT_BUFFER)
        delete_from = keep_through + 1
        delete_count = stop - delete_from
        if delete_count <= 0:
            continue
        ws.delete_rows(delete_from, delete_count)
        removed += delete_count
    restore_all_week_header_merges(ws)
    return removed


def apply_week_detail_log_fills(ws: Worksheet, wb: openpyxl.Workbook) -> None:
    """Yellow/green detail-log background per week — matches May header bar color."""
    guard_not_template(ws)
    if TEMPLATE_SHEET not in wb.sheetnames:
        return
    template_ws = wb[TEMPLATE_SHEET]
    template_weeks = find_week_sections(template_ws)
    weeks = find_week_sections(ws)

    for idx, week in enumerate(weeks):
        template_week = (
            template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
        )
        src = template_ws.cell(template_week.header_row, DETAIL_COLS["date"])
        week_fill = copy(src.fill) if src.fill else None
        stop = (
            weeks[idx + 1].header_row
            if idx + 1 < len(weeks)
            else week.end_row + 1
        )
        for row in range(week.header_row, stop):
            if row == week.total_row:
                continue
            # Empty buffer below Total: white (March/May — no pink placeholder band)
            if week.total_row and row > week.total_row and not is_detail_entry_row(ws, row):
                for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                    ws.cell(row, col).fill = NO_FILL
                continue
            for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                cell = ws.cell(row, col)
                if week_fill:
                    cell.fill = copy(week_fill)
                if is_detail_entry_row(ws, row):
                    copy_cell_style(
                        template_ws.cell(TEMPLATE_DETAIL_ROW, col),
                        cell,
                        skip_fill=True,
                    )
                    if week_fill:
                        cell.fill = copy(week_fill)


def free_detail_slot_count(ws: Worksheet, week: WeekSection, stop: int) -> int:
    reserved = detail_reserved_rows(week)
    count = 0
    for row in range(week.header_row, stop):
        if row in reserved:
            continue
        if ws.cell(row, DETAIL_COLS["date"]).value is None:
            count += 1
    return count


def prepare_detail_buffer_row(ws: Worksheet, template_ws: Worksheet, row: int) -> None:
    for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
        cell = ws.cell(row, col)
        copy_cell_style(template_ws.cell(TEMPLATE_DETAIL_ROW, col), cell, skip_fill=True)
        cell.fill = NO_FILL
        cell.value = None


def restore_week_header_merge(
    ws: Worksheet,
    week: WeekSection,
    title: Optional[str] = None,
) -> None:
    """Re-apply May-style merge at the live header row (never May absolute rows)."""
    header = week.header_row
    unmerge_at(ws, header, 1)
    if header + 1 <= ws.max_row:
        unmerge_at(ws, header + 1, 1)
    text = title or ws.cell(header, 1).value or week.title
    ws.merge_cells(f"A{header}:O{header + 1}")
    if text:
        ws.cell(header, 1).value = text


def restore_all_week_header_merges(
    ws: Worksheet,
    month_load: Optional[MonthLoad] = None,
) -> None:
    """Remove ghost A:O merges; ensure 5 week titles + merges at live headers."""
    if month_load is not None:
        ensure_week_headers_from_load(ws, month_load)

    weeks = find_week_sections(ws)
    live_headers = {w.header_row for w in weeks}

    for merged in list(ws.merged_cells.ranges):
        if merged.min_col != 1 or merged.max_col != EMPLOYEE_GRID_LAST_COL:
            continue
        if merged.min_row == 1 or merged.min_row in live_headers:
            continue
        try:
            ws.unmerge_cells(str(merged))
        except KeyError:
            pass

    month_title = ws.cell(1, 1).value
    if month_title:
        unmerge_at(ws, 1, 1)
        ws.merge_cells("A1:O1")
        ws.cell(1, 1).value = month_title

    for idx, week in enumerate(weeks):
        title = None
        if month_load and idx < len(month_load.weeks):
            wl = month_load.weeks[idx]
            title = format_week_title(wl.start, wl.end)
        restore_week_header_merge(ws, week, title=title)


def remove_spurious_week_headers(ws: Worksheet) -> None:
    """Clear duplicate or in-block col-A week titles left after presize shifts."""
    weeks = find_week_sections(ws)
    valid_headers = {w.header_row for w in weeks}
    for row in range(1, ws.max_row + 1):
        val = ws.cell(row, 1).value
        if val and " To " in str(val) and row not in valid_headers:
            unmerge_at(ws, row, 1)
            if row + 1 <= ws.max_row:
                unmerge_at(ws, row + 1, 1)
            ws.cell(row, 1).value = None


def ensure_week_headers_from_load(ws: Worksheet, month_load: MonthLoad) -> None:
    """Re-write week titles on live week header rows only."""
    remove_spurious_week_headers(ws)
    weeks = find_week_sections(ws)
    for idx, week in enumerate(weeks):
        if idx >= len(month_load.weeks):
            break
        load = month_load.weeks[idx]
        title = format_week_title(load.start, load.end)
        header_row = week.header_row
        unmerge_at(ws, header_row, 1)
        if header_row + 1 <= ws.max_row:
            unmerge_at(ws, header_row + 1, 1)
        ws.cell(header_row, 1).value = title


def normalize_employee_day_cells(ws: Worksheet) -> None:
    """Force B-H time format and replace blank day cells with 0:00 (no decimals / 0-Jan)."""
    guard_not_template(ws)
    for week in find_week_sections(ws):
        for erow in week.employee_rows.values():
            for col in DAY_COLS:
                cell = ws.cell(erow, col)
                if cell.value in (0, 0.0):
                    cell.value = time(0, 0)
                if cell.value is None:
                    cell.value = time(0, 0)
                cell.number_format = DAY_HOURS_FORMAT
            o_cell = ws.cell(erow, 15)
            if o_cell.value is None:
                o_cell.value = f"=SUM(B{erow}:H{erow})"
            o_cell.number_format = "[h]:mm:ss;@"


def normalize_detail_hours_formats(ws: Worksheet) -> None:
    guard_not_template(ws)
    for row in range(1, ws.max_row + 1):
        if not is_detail_entry_row(ws, row):
            continue
        ws.cell(row, DETAIL_COLS["time_in"]).number_format = DAY_HOURS_FORMAT
        ws.cell(row, DETAIL_COLS["time_out"]).number_format = DAY_HOURS_FORMAT
        ws.cell(row, DETAIL_COLS["total_hours"]).number_format = DETAIL_HOURS_FORMAT


def count_configured_weeks(ws: Worksheet, month_load: MonthLoad) -> int:
    """Count week blocks with correct titles at live header rows."""
    remove_spurious_week_headers(ws)
    weeks = find_week_sections(ws)
    count = 0
    for idx, wl in enumerate(month_load.weeks):
        if idx >= len(weeks):
            break
        title = format_week_title(wl.start, wl.end)
        if ws.cell(weeks[idx].header_row, 1).value == title:
            count += 1
    return count


MIN_NEXT_WEEK_BLOCK_ROWS = 22


def strip_trailing_week_blocks(ws: Worksheet, keep_count: int) -> None:
    """Drop template tail weeks so presize can expand without swallowing them."""
    if keep_count < 1:
        return
    weeks = find_week_sections(ws)
    while len(weeks) > keep_count:
        last = weeks[-1]
        block = last.end_row - last.header_row + 1
        ws.delete_rows(last.header_row, block)
        weeks = find_week_sections(ws)


def append_missing_weeks_from_template(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    month_load: MonthLoad,
    registry: WorkerRegistry,
    stats: Stats,
) -> None:
    """If presize swallowed later week blocks, append them from May template."""
    guard_not_template(ws)
    template_ws = wb[TEMPLATE_SHEET]
    template_weeks = find_week_sections(template_ws)

    while len(find_week_sections(ws)) < len(month_load.weeks):
        idx = len(find_week_sections(ws))
        if idx >= len(template_weeks) or idx >= len(month_load.weeks):
            break
        tw = template_weeks[idx]
        wl = month_load.weeks[idx]
        block = tw.end_row - tw.header_row + 1
        dest = ws.max_row + 1
        ws.insert_rows(dest, block)
        for r_off in range(block):
            src = tw.header_row + r_off
            dst = dest + r_off
            for col in range(1, DETAIL_LOG_LAST_COL + 1):
                s = template_ws.cell(src, col)
                d = ws.cell(dst, col)
                d.value = s.value
                copy_cell_style(s, d)
        remove_spurious_week_headers(ws)
        weeks = find_week_sections(ws)
        week = weeks[-1] if idx >= len(weeks) else weeks[idx]
        clear_week_attendance(ws, week)
        update_week_dates(ws, week, wl.start, wl.end)
        all_shorts: set[str] = set()
        for wload in month_load.weeks:
            all_shorts |= wload.worker_shorts
        for short in sorted(all_shorts):
            profile = lookup_worker_profile(wb, registry, short, short)
            if profile.excel_name in week.employee_rows:
                continue
            if resolve_existing_worker_row(ws, week, registry, profile) is not None:
                continue
            insert_row = week.total_row if week.total_row else max(week.employee_rows.values()) + 1
            ws.insert_rows(insert_row)
            if week.total_row and insert_row <= week.total_row:
                week.total_row += 1
            for ename, erow in list(week.employee_rows.items()):
                if erow >= insert_row:
                    week.employee_rows[ename] = erow + 1
            populate_employee_row(ws, insert_row, profile, wb, week, registry)
            week.employee_rows[profile.excel_name] = insert_row
            template_week = matching_template_week(wb, ws, week)
            apply_new_employee_row_formatting(
                ws, template_ws, insert_row, week, template_week, profile.excel_name
            )
            fix_employee_row_formulas(ws, insert_row)


def presize_month_sheet(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    month_load: MonthLoad,
    registry: WorkerRegistry,
    stats: Stats,
) -> None:
    """Expand each week for workers + detail slots before any attendance writes."""
    guard_not_template(ws)
    template_ws = wb[TEMPLATE_SHEET]

    for week_idx in range(len(month_load.weeks) - 1, -1, -1):
        weeks = find_week_sections(ws)
        if week_idx >= len(weeks):
            continue
        week = weeks[week_idx]
        load = month_load.weeks[week_idx]

        seat_week_roster_from_chat(wb, ws, week, load, registry, stats)

        weeks = find_week_sections(ws)
        if week_idx >= len(weeks):
            continue
        week = weeks[week_idx]
        stop = next_week_header_row(weeks, week)
        # May overlap: detail uses header→Total band too — count ALL free slots in week
        free = free_detail_slot_count(ws, week, stop)
        needed = load.entry_count + DETAIL_SLOT_BUFFER
        if free < needed:
            insert_count = needed - free
            insert_at = (week.total_row + 1) if week.total_row else (week.end_row + 1)
            # insert_rows pushes the next week down — safe at creation/presize time
            ws.insert_rows(insert_at, insert_count)
            for row in range(insert_at, insert_at + insert_count):
                prepare_detail_buffer_row(ws, template_ws, row)

    strip_trailing_week_blocks(ws, len(month_load.weeks) - 1)
    append_missing_weeks_from_template(wb, ws, month_load, registry, stats)
    ensure_week_headers_from_load(ws, month_load)
    restore_all_week_header_merges(ws, month_load)
    for week in find_week_sections(ws):
        reset_week_employee_formulas(ws, week)
    trim_week_empty_tails(ws)


def is_expanded_week(week: WeekSection) -> bool:
    if not week.total_row:
        return False
    return week.end_row - week.total_row >= 50


def week_by_header(ws: Worksheet, header_row: int) -> Optional[WeekSection]:
    for week in find_week_sections(ws):
        if week.header_row == header_row:
            return week
    return None


def template_is_valid(ws: Worksheet) -> bool:
    weeks = find_week_sections(ws)
    if len(weeks) != 5:
        return False
    return all(is_expanded_week(w) for w in weeks)


def expand_week_to_fixed_size(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    week: WeekSection,
) -> None:
    if week is None or not week.total_row:
        return
    header_row = week.header_row

    emps_needed = WORKERS_PER_WEEK - len(week.employee_rows)
    if emps_needed > 0:
        ws.insert_rows(week.total_row, emps_needed)

    week = week_by_header(ws, header_row)
    if week is None or not week.total_row:
        return

    detail_after_total = week.end_row - week.total_row
    detail_needed = DETAIL_SLOTS_PER_WEEK - detail_after_total
    if detail_needed > 0:
        insert_at = week.total_row + 1
        ws.insert_rows(insert_at, detail_needed)

    week = week_by_header(ws, header_row)
    if week is None:
        return

    template_ws = wb[TEMPLATE_SHEET]
    for row in range(week.total_row + 1, week.end_row + 1):
        prepare_detail_buffer_row(ws, template_ws, row)
        for col in range(1, EMPLOYEE_GRID_LAST_COL + 1):
            ws.cell(row, col).value = None


def seat_week_roster(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    week: WeekSection,
    registry: WorkerRegistry,
) -> None:
    template_ws = wb[TEMPLATE_SHEET]
    template_weeks = find_week_sections(template_ws)
    template_week = template_weeks[0]
    first_row = week.employee_header_row + 1
    week.employee_rows.clear()

    for idx in range(WORKERS_PER_WEEK):
        row = first_row + idx
        if idx < len(TEMPLATE_ROSTER):
            excel_name = TEMPLATE_ROSTER[idx]
            short = default_short_name(excel_name)
            profile = registry.profile_for(short)
            if not profile:
                hist_excel, bank, rate, empty_break = find_historical_employee(
                    wb, registry, short
                )
                profile = WorkerProfile(
                    excel_name=hist_excel or excel_name,
                    short_name=short,
                    bank_name=bank,
                    hourly_rate=rate,
                    empty_break_hours=empty_break or is_franklin_employee(excel_name),
                )
                registry.register(profile)
            populate_employee_row(ws, row, profile, wb, week, registry)
            apply_new_employee_row_formatting(
                ws, template_ws, row, week, template_week, profile.excel_name
            )
            week.employee_rows[profile.excel_name] = row
        else:
            ws.cell(row, 1).value = None
            apply_new_employee_row_formatting(ws, template_ws, row, week, template_week)
            for col in DAY_COLS:
                ws.cell(row, col).value = time(0, 0)
                ws.cell(row, col).number_format = DAY_HOURS_FORMAT
            ws.cell(row, 11).value = f"=O{row}*J{row}*24"
            ws.cell(row, 12).value = time(0, 0)
            ws.cell(row, 13).value = f"=L{row}*J{row}*24"
            ws.cell(row, 14).value = f"=K{row}+M{row}"
            ws.cell(row, 15).value = f"=SUM(B{row}:H{row})"
            for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
                ws.cell(row, col).fill = NO_FILL

    recalculate_week_totals(ws, week)


def build_month_template(wb: openpyxl.Workbook, registry: WorkerRegistry) -> Worksheet:
    if MONTH_TEMPLATE_SHEET in wb.sheetnames:
        del wb[MONTH_TEMPLATE_SHEET]

    template = wb[TEMPLATE_SHEET]
    ws = wb.copy_worksheet(template)
    ws.title = MONTH_TEMPLATE_SHEET
    ws.cell(1, 1).value = "Month Template (Do Not Edit)"

    weeks = find_week_sections(ws)
    for week_idx in range(len(weeks)):
        weeks = find_week_sections(ws)
        if week_idx >= len(weeks):
            continue
        expand_week_to_fixed_size(ws, wb, weeks[week_idx])

    for week in find_week_sections(ws):
        seat_week_roster(ws, wb, week, registry)
        reset_week_employee_formulas(ws, week)

    month_load = MonthLoad(
        year=2026,
        month=6,
        weeks=[
            WeekLoad(start=s, end=e, entry_count=0, worker_shorts=set())
            for s, e in month_week_ranges(2026, 6)
        ],
    )
    restore_all_week_header_merges(ws, month_load)
    apply_employee_grid_styles(ws, wb[TEMPLATE_SHEET])
    sync_employee_hourly_rates(ws, wb, registry)
    fix_detail_log_formulas(ws)
    restore_week_salary_summary(ws, wb)
    restore_week_ab_merges(ws, wb[TEMPLATE_SHEET])
    apply_week_detail_log_fills(ws, wb)
    return ws


def ensure_month_template(wb: openpyxl.Workbook, registry: WorkerRegistry) -> Worksheet:
    if MONTH_TEMPLATE_SHEET in wb.sheetnames:
        if template_is_valid(wb[MONTH_TEMPLATE_SHEET]):
            return wb[MONTH_TEMPLATE_SHEET]
        del wb[MONTH_TEMPLATE_SHEET]
    return build_month_template(wb, registry)


def ensure_month_sheet(
    wb: openpyxl.Workbook,
    year: int,
    month: int,
    stats: Stats,
    registry: Optional[WorkerRegistry] = None,
    month_load: Optional[MonthLoad] = None,
) -> Worksheet:
    name = sheet_name_for_date(date(year, month, 1))
    if date(year, month, 1) < date(CUTOFF_DATE.year, CUTOFF_DATE.month, 1):
        raise RuntimeError(f"Refusing to create/write pre-cutoff sheet {name}")
    if name == TEMPLATE_SHEET:
        raise RuntimeError(f"PERMANENT RULE VIOLATION: cannot create/write {TEMPLATE_SHEET}")
    if name in wb.sheetnames:
        return wb[name]

    template = wb[TEMPLATE_SHEET]
    ws = wb.copy_worksheet(template)
    ws.title = name
    initialize_month_sheet(ws, year, month)

    if registry is not None:
        if month_load is None:
            month_load = MonthLoad(
                year=year,
                month=month,
                weeks=[
                    WeekLoad(start=s, end=e, entry_count=0, worker_shorts=set())
                    for s, e in month_week_ranges(year, month)
                ],
            )
        presize_month_sheet(wb, ws, month_load, registry, stats)

    if registry is not None and month_load is not None:
        append_missing_weeks_from_template(wb, ws, month_load, registry, stats)
        ensure_week_headers_from_load(ws, month_load)

    restore_all_week_header_merges(ws, month_load)
    reset_month_employee_formulas(ws)
    apply_month_sheet_formatting(wb, name, include_merges=False)
    restore_all_week_header_merges(ws, month_load)
    apply_employee_grid_styles(ws, wb[TEMPLATE_SHEET])
    if registry is not None:
        sync_employee_hourly_rates(ws, wb, registry)
    fix_detail_log_formulas(ws)
    normalize_employee_day_cells(ws)
    normalize_detail_hours_formats(ws)
    restore_week_salary_summary(ws, wb)
    restore_week_ab_merges(ws, wb[TEMPLATE_SHEET])
    # Do not paint empty yellow detail bands at creation — Option 1 styles filled rows only
    stats.created_sheets.add(name)
    return ws


def worker_has_week_data(
    ws: Worksheet,
    week: WeekSection,
    excel_name: str,
    short_name: str,
) -> bool:
    row = week.employee_rows.get(excel_name)
    if row is None:
        for ename, erow in week.employee_rows.items():
            if worker_names_match(short_name, ename) or worker_names_match(excel_name, ename):
                row = erow
                break
    if row is None:
        return False
    for col in DAY_COLS:
        if cell_is_filled(ws, row, col):
            return True

    week_dates = set(week.dates.values())
    for row_idx in range(week.header_row, week.end_row + 1):
        name = ws.cell(row_idx, DETAIL_COLS["name"]).value
        dt = ws.cell(row_idx, DETAIL_COLS["date"]).value
        if not isinstance(dt, datetime) or not name:
            continue
        if not worker_names_match(short_name, str(name)):
            continue
        if dt.date() not in week_dates:
            continue
        if ws.cell(row_idx, DETAIL_COLS["time_in"]).value or ws.cell(
            row_idx, DETAIL_COLS["time_out"]
        ).value:
            return True
    return False


def populate_employee_row(
    ws: Worksheet,
    row: int,
    profile: WorkerProfile,
    wb: Optional[openpyxl.Workbook] = None,
    week: Optional[WeekSection] = None,
    registry: Optional[WorkerRegistry] = None,
) -> None:
    template_week = None
    if wb and week:
        template_weeks = find_week_sections(wb[TEMPLATE_SHEET])
        target_weeks = find_week_sections(ws)
        for idx, tw in enumerate(target_weeks):
            if tw.header_row == week.header_row:
                template_week = template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
                break

    hourly_rate = profile.hourly_rate
    if hourly_rate is None and wb and registry:
        hourly_rate = resolve_profile_hourly_rate(wb, registry, profile)

    def put(col: int, value) -> None:
        if wb:
            write_cell(ws, wb, row, col, value, week, template_week)
        else:
            ws.cell(row, col).value = value

    put(1, profile.excel_name)
    put(9, profile.bank_name)
    put(10, hourly_rate)
    for col in DAY_COLS:
        put(col, time(0, 0))
    put(11, f"=O{row}*J{row}*24")
    put(12, None if profile.empty_break_hours else time(0, 0))
    put(13, f"=L{row}*J{row}*24")
    put(14, f"=K{row}+M{row}")
    put(15, f"=SUM(B{row}:H{row})")


def find_insert_row(
    week: WeekSection,
    excel_name: str,
    canonical_order: list[str],
) -> int:
    if excel_name not in canonical_order:
        return max(week.employee_rows.values()) + 1

    new_idx = canonical_order.index(excel_name)
    best_row = None
    best_idx = -1
    for ename, erow in week.employee_rows.items():
        if ename not in canonical_order:
            continue
        idx = canonical_order.index(ename)
        if idx < new_idx and idx > best_idx:
            best_idx = idx
            best_row = erow

    if best_row is None:
        return min(week.employee_rows.values())
    return best_row + 1


def fix_employee_row_formulas(ws: Worksheet, row: int) -> None:
    ws.cell(row, 11).value = f"=O{row}*J{row}*24"
    ws.cell(row, 13).value = f"=L{row}*J{row}*24"
    ws.cell(row, 14).value = f"=K{row}+M{row}"
    ws.cell(row, 15).value = f"=SUM(B{row}:H{row})"


def fix_all_employee_formulas(ws: Worksheet) -> None:
    for week in find_week_sections(ws):
        for row in week.employee_rows.values():
            fix_employee_row_formulas(ws, row)
        recalculate_week_totals(ws, week)


def restore_missing_week5_employees(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    registry: WorkerRegistry,
) -> None:
    weeks = find_week_sections(ws)
    if len(weeks) < 5:
        return
    week = weeks[4]
    if week.employee_rows:
        return

    template_ws = wb[TEMPLATE_SHEET]
    template_week = find_week_sections(template_ws)[4]
    insert_at = week.total_row
    count = len(template_week.employee_rows)
    ws.insert_rows(insert_at, count)

    for excel_name, template_row in sorted(template_week.employee_rows.items(), key=lambda item: item[1]):
        row = insert_at + (template_row - min(template_week.employee_rows.values()))
        profile = registry.profile_for(registry.short_for(excel_name))
        if not profile:
            profile = WorkerProfile(
                excel_name=excel_name,
                short_name=registry.short_for(excel_name),
                bank_name=template_ws.cell(template_row, 9).value,
                hourly_rate=template_ws.cell(template_row, 10).value,
                empty_break_hours=template_ws.cell(template_row, 12).value is None,
            )
        else:
            profile = WorkerProfile(
                excel_name=excel_name,
                short_name=profile.short_name,
                bank_name=profile.bank_name or template_ws.cell(template_row, 9).value,
                hourly_rate=profile.hourly_rate or template_ws.cell(template_row, 10).value,
                empty_break_hours=profile.empty_break_hours,
            )
        populate_employee_row(ws, row, profile, wb, week, registry)
        apply_new_employee_row_formatting(ws, template_ws, row)
        for col in range(DETAIL_LOG_FIRST_COL, DETAIL_LOG_LAST_COL + 1):
            ws.cell(row, col).fill = NO_FILL

    week = find_week_sections(ws)[4]
    recalculate_week_totals(ws, week)
    relink_employee_day_formulas(ws, registry)
    for erow in week.employee_rows.values():
        fix_employee_row_formulas(ws, erow)


def lookup_worker_profile(
    wb: openpyxl.Workbook,
    registry: WorkerRegistry,
    short_name: str,
    sender: str,
) -> WorkerProfile:
    existing = registry.profile_for(short_name)
    if existing:
        return existing

    excel_name, bank_name, hourly_rate, empty_break_hours = find_historical_employee(
        wb, registry, short_name
    )
    if not excel_name:
        excel_name = registry.excel_for(short_name) or short_name.strip()
    if not excel_name or not str(excel_name).strip() or not is_valid_worker_short(short_name):
        excel_name = short_name.strip()

    profile = WorkerProfile(
        excel_name=excel_name,
        short_name=short_name,
        bank_name=bank_name,
        hourly_rate=hourly_rate,
        empty_break_hours=empty_break_hours,
    )
    registry.register(profile)
    merge_registry_by_bank(registry)
    return profile


def sync_profile_from_row(
    ws: Worksheet,
    row: int,
    profile: WorkerProfile,
    registry: WorkerRegistry,
) -> WorkerProfile:
    actual_name = ws.cell(row, 1).value
    if not actual_name:
        return profile
    actual_name = str(actual_name).strip()
    if worker_names_match(profile.excel_name, actual_name):
        if profile.excel_name != actual_name:
            profile = WorkerProfile(
                excel_name=actual_name,
                short_name=profile.short_name,
                bank_name=profile.bank_name,
                hourly_rate=profile.hourly_rate,
                empty_break_hours=profile.empty_break_hours,
            )
            registry.register(profile)
        return profile
    return profile


def resolve_employee_row(
    ws: Worksheet,
    week: WeekSection,
    registry: WorkerRegistry,
    profile: WorkerProfile,
) -> Optional[int]:
    row = resolve_existing_worker_row(ws, week, registry, profile)
    if row is not None:
        return row
    return week.employee_rows.get(profile.excel_name)


def resolve_existing_worker_row(
    ws: Worksheet,
    week: WeekSection,
    registry: WorkerRegistry,
    profile: WorkerProfile,
) -> Optional[int]:
    if profile.excel_name in week.employee_rows:
        return week.employee_rows[profile.excel_name]

    bank_key = normalize_bank(profile.bank_name)
    for ename, row in week.employee_rows.items():
        if worker_names_match(profile.short_name, registry.short_for(ename)):
            return row
        if worker_names_match(profile.excel_name, ename):
            return row
        if bank_key:
            cell_bank = normalize_bank(ws.cell(row, 9).value)
            if cell_bank and cell_bank == bank_key and bank_is_unique_identifier(bank_key):
                return row
    return None


def matching_template_week(
    wb: openpyxl.Workbook, ws: Worksheet, week: WeekSection
) -> WeekSection:
    template_weeks = find_week_sections(wb[TEMPLATE_SHEET])
    target_weeks = find_week_sections(ws)
    for idx, tw in enumerate(target_weeks):
        if tw.header_row == week.header_row:
            return template_weeks[idx] if idx < len(template_weeks) else template_weeks[-1]
    return template_weeks[0]


def first_empty_employee_row(ws: Worksheet, week: WeekSection) -> Optional[int]:
    if not week.total_row:
        return None
    first = week.employee_header_row + 1
    last = week.total_row - 1
    for row in range(first, last + 1):
        val = ws.cell(row, 1).value
        if val is None or str(val).strip() == "":
            return row
    return None


def ensure_worker_in_week(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    week: WeekSection,
    short_name: str,
    sender: str,
    registry: WorkerRegistry,
    stats: Stats,
) -> int:
    profile = lookup_worker_profile(wb, registry, short_name, sender)
    excel_name = profile.excel_name

    existing_row = resolve_existing_worker_row(ws, week, registry, profile)
    if existing_row is not None:
        actual_name = ws.cell(existing_row, 1).value
        if actual_name:
            profile.excel_name = str(actual_name).strip()
            registry.register(profile)
        return existing_row

    if excel_name in week.employee_rows:
        return week.employee_rows[excel_name]

    insert_row = week.total_row if week.total_row else max(week.employee_rows.values()) + 1
    ws.insert_rows(insert_row)
    if week.total_row and insert_row <= week.total_row:
        week.total_row += 1
    week.end_row += 1
    for ename, erow in list(week.employee_rows.items()):
        if erow >= insert_row:
            week.employee_rows[ename] = erow + 1

    populate_employee_row(ws, insert_row, profile, wb, week, registry)
    week.employee_rows[profile.excel_name] = insert_row
    template_ws = wb[TEMPLATE_SHEET]
    template_week = matching_template_week(wb, ws, week)
    apply_new_employee_row_formatting(
        ws, template_ws, insert_row, week, template_week, excel_name
    )
    fix_employee_row_formulas(ws, insert_row)
    stats.auto_added_workers.add(excel_name)
    stats.new_workers.append(
        f"{ws.title} | {week.title} | added {excel_name} at row {insert_row}"
    )
    weeks = find_week_sections(ws)
    for w in weeks:
        if w.header_row == week.header_row:
            reset_week_employee_formulas(ws, w)
            break
    restore_all_week_header_merges(ws)
    fix_detail_log_formulas(ws)
    return insert_row


def remove_zero_hour_workers(
    ws: Worksheet,
    week: WeekSection,
    registry: WorkerRegistry,
    auto_added: set[str],
) -> None:
    removed = False
    for excel_name, row in list(week.employee_rows.items()):
        if excel_name not in auto_added:
            continue
        short_name = registry.short_for(excel_name)
        if worker_has_week_data(ws, week, excel_name, short_name):
            continue
        ws.delete_rows(row, 1)
        del week.employee_rows[excel_name]
        if week.total_row and row < week.total_row:
            week.total_row -= 1
        week.end_row -= 1
        for ename, erow in list(week.employee_rows.items()):
            if erow > row:
                week.employee_rows[ename] = erow - 1
        removed = True
        break

    if removed:
        if week.employee_rows:
            recalculate_week_totals(ws, week)
        remove_zero_hour_workers(ws, week, registry, auto_added)


def apply_record(
    wb: openpyxl.Workbook,
    rec: AttendanceRecord,
    stats: Stats,
    day_break_flags: dict[str, dict[date, bool]],
    registry: WorkerRegistry,
) -> None:
    profile = lookup_worker_profile(wb, registry, rec.worker, rec.sender)
    if not is_valid_worker_short(profile.short_name):
        log_skip(stats, "Invalid worker name", rec.source)
        return
    excel_name = profile.excel_name

    ws = ensure_month_sheet(wb, rec.work_date.year, rec.work_date.month, stats)
    weeks = find_week_sections(ws)
    week = find_week_for_date(weeks, rec.work_date)
    if not week:
        log_skip(stats, "No week section for date", rec.source)
        return

    if excel_name not in week.employee_rows:
        if resolve_existing_worker_row(ws, week, registry, profile) is None:
            ensure_worker_in_week(wb, ws, week, rec.worker, rec.sender, registry, stats)
        weeks = find_week_sections(ws)
        week = find_week_for_date(weeks, rec.work_date)
        if not week:
            log_skip(stats, "Could not add worker to week", f"{excel_name} | {rec.source}")
            return
        profile = lookup_worker_profile(wb, registry, rec.worker, rec.sender)

    employee_row = resolve_employee_row(ws, week, registry, profile)
    if employee_row is None:
        log_skip(stats, "Could not add worker to week", f"{excel_name} | {rec.source}")
        return
    profile = sync_profile_from_row(ws, employee_row, profile, registry)

    day_col = find_day_col(week, rec.work_date)
    if not day_col:
        log_skip(stats, "Date not in week columns", rec.source)
        return

    if is_duplicate_detail_entry(ws, rec.worker, rec.work_date, rec.time_in, rec.time_out):
        log_skip(stats, "Duplicate entry", rec.source)
        return

    if cell_is_filled(ws, employee_row, day_col):
        log_skip(stats, "Cell already has data", rec.source)
        return

    detail_row = find_free_detail_row(ws, week, employee_row=employee_row)
    if detail_row is None:
        grow_week_detail_slots(ws, wb, week, 1)
        weeks = find_week_sections(ws)
        week = find_week_for_date(weeks, rec.work_date)
        if not week:
            log_skip(stats, "Week lost after detail grow", rec.source)
            return
        employee_row = resolve_employee_row(ws, week, registry, profile)
        if employee_row is None:
            log_skip(stats, "Could not resolve employee row", f"{excel_name} | {rec.source}")
            return
        detail_row = find_free_detail_row(ws, week, employee_row=employee_row)
    if detail_row is None:
        log_skip(stats, "No free detail row in week block", rec.source)
        return

    weeks = find_week_sections(ws)
    week = find_week_for_date(weeks, rec.work_date)
    if not week:
        log_skip(stats, "Week lost after detail row lookup", rec.source)
        return
    employee_row = resolve_employee_row(ws, week, registry, profile)
    if employee_row is None:
        log_skip(stats, "Could not resolve employee row", f"{excel_name} | {rec.source}")
        return

    if detail_row > week.end_row:
        week.end_row = detail_row

    write_detail_entry(
        ws,
        detail_row,
        profile.short_name,
        rec.work_date,
        rec.time_in,
        rec.time_out,
        profile.empty_break_hours,
        wb,
        week,
        profile.hourly_rate,
        employee_row,
    )

    if not validate_detail_row(ws, detail_row, week):
        for col in range(DETAIL_COLS["date"], DETAIL_LOG_LAST_COL + 1):
            ws.cell(detail_row, col).value = None
        log_skip(stats, "Invalid detail row after write", rec.source)
        return

    link_employee_day_to_detail(
        ws, wb, employee_row, day_col, detail_row, week, rec.time_in, rec.time_out
    )

    flags = day_break_flags.setdefault(ws.title, {})
    if rec.no_break:
        flags[rec.work_date] = True
    elif rec.work_date not in flags:
        flags[rec.work_date] = False

    recalc_flags: dict[date, bool] = {}
    for col, d in week.dates.items():
        recalc_flags[d] = flags.get(d, False)

    recalculate_employee_week(
        ws, week, employee_row, rec.worker, recalc_flags, profile.empty_break_hours
    )
    stats.added += 1
    stats.updated_sheets.add(ws.title)


def write_skipped(stats: Stats) -> None:
    by_month: dict[tuple[int, int], list[str]] = defaultdict(list)
    other: list[str] = []
    for line in stats.skip_log:
        month_key = skip_month_key(line)
        if month_key:
            by_month[month_key].append(line)
        else:
            other.append(line)

    with SKIPPED_FILE.open("w", encoding="utf-8") as fh:
        for year, month in sorted(by_month):
            fh.write(f"=== {sheet_name_for_date(date(year, month, 1))} ===\n")
            for line in by_month[(year, month)]:
                fh.write(line + "\n")
            fh.write("\n")
        if other:
            fh.write("=== Other ===\n")
            for line in other:
                fh.write(line + "\n")


def write_new_workers(stats: Stats) -> None:
    with NEW_WORKERS_FILE.open("w", encoding="utf-8") as fh:
        if stats.new_workers:
            for line in stats.new_workers:
                fh.write(line + "\n")
        else:
            fh.write("No new workers added.\n")


def merge_duplicate_bank_workers(ws: Worksheet) -> None:
    guard_not_template(ws)
    weeks = find_week_sections(ws)
    for week in weeks:
        by_bank: dict[str, list[tuple[str, int]]] = defaultdict(list)
        for ename, row in week.employee_rows.items():
            bank = normalize_bank(ws.cell(row, 9).value)
            if bank:
                by_bank[bank].append((ename, row))

        for entries in by_bank.values():
            if len(entries) < 2:
                continue
            alias_groups: list[list[tuple[str, int]]] = []
            for ename, row in entries:
                matched = False
                for group in alias_groups:
                    if any(worker_names_match(ename, other[0]) for other in group):
                        group.append((ename, row))
                        matched = True
                        break
                if not matched:
                    alias_groups.append([(ename, row)])

            for group in alias_groups:
                if len(group) < 2:
                    continue
                group.sort(key=lambda item: item[1])
                keep_name, keep_row = group[0]
                for ename, row in sorted(group[1:], key=lambda item: item[1], reverse=True):
                    if row == keep_row:
                        continue
                    for col in DAY_COLS:
                        val = ws.cell(row, col).value
                        if cell_is_filled(ws, row, col) and not cell_is_filled(ws, keep_row, col):
                            ws.cell(keep_row, col).value = val
                    ws.delete_rows(row, 1)
                    if week.total_row and row < week.total_row:
                        week.total_row -= 1
                    week.end_row -= 1
                    for e, r in list(week.employee_rows.items()):
                        if r > row:
                            week.employee_rows[e] = r - 1
                        elif r == row:
                            del week.employee_rows[e]
                    if ename in week.employee_rows:
                        del week.employee_rows[ename]
                fix_employee_row_formulas(ws, keep_row)
        recalculate_week_totals(ws, week)


def cleanup_invalid_detail_entries(ws: Worksheet) -> None:
    guard_not_template(ws)
    for row in range(1, ws.max_row + 1):
        name = ws.cell(row, DETAIL_COLS["name"]).value
        if name and str(name).strip().lower() == "you":
            for col in range(DETAIL_COLS["date"], DETAIL_LOG_LAST_COL + 1):
                ws.cell(row, col).value = None


def print_summary(stats: Stats) -> None:
    print("\n" + "=" * 50)
    print("WAGES AUTOMATION SUMMARY")
    print("=" * 50)
    if stats.month_stats:
        print("By month:")
        total_added = 0
        total_skipped = 0
        for year, month in sorted(stats.month_stats):
            ms = stats.month_stats[(year, month)]
            label = sheet_name_for_date(date(year, month, 1))
            print(f"  {label:12} {ms.added:3} added | {ms.skipped:2} skipped")
            total_added += ms.added
            total_skipped += ms.skipped
        print(f"  {'Total':12} {total_added:3} added | {total_skipped:2} skipped")
        print()
    print(f"Entries added:   {stats.added}")
    print(f"Entries skipped: {stats.skipped}")
    print(f"New workers:     {len(stats.new_workers)}")
    print(f"Sheets updated:  {', '.join(sorted(stats.updated_sheets)) or 'None'}")
    print(f"Sheets created:  {', '.join(sorted(stats.created_sheets)) or 'None'}")
    print(f"Skipped log:     {SKIPPED_FILE}")
    print(f"New workers log: {NEW_WORKERS_FILE}")
    print("=" * 50)


def main() -> None:
    """Chat -> Attendance_Log upsert -> incremental month sheet sync (no rebuild)."""
    from sync_pipeline import run_sync

    run_sync()


if __name__ == "__main__":
    main()
