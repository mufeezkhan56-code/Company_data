"""
May-compatible break hours rules (reusable for every month sheet).

Rules (from wages_automation / May template):
- Franklin: col L blank, detail break = '-', never break salary
- All other workers (including Kennedy): 5 minutes break credit per hour
  ONLY on days where chat says not break taken / no break / without break
- Normal day (break taken): no extra break hours that day
- Break Hours Salary (col M) = col L * col J * 24 (formula on sheet)
"""

from __future__ import annotations

from datetime import date, time
from typing import Optional

from openpyxl.worksheet.worksheet import Worksheet

import wages_automation as wa

# 5 minutes per worked hour — same as recalculate_employee_week
BREAK_HOURS_PER_WORKED_HOUR = 5 / 60

DAY_HOURS_FMT = "[h]:mm:ss"
MONEY_FMT = "#,##0.00"


def _worker_short(rec: wa.AttendanceRecord, registry: wa.WorkerRegistry) -> str:
    short = wa.canonical_worker_short(rec.worker, registry) or rec.worker
    if short.lower().startswith("frank"):
        return "Franklin"
    return short


def _day_break_flags_and_hours(
    worker_short: str,
    records: list[wa.AttendanceRecord],
    week_start: date,
    week_end: date,
    registry: wa.WorkerRegistry,
) -> tuple[dict[date, bool], dict[date, float]]:
    """Per-day no-break flags + worked hours — mirrors May day_break_flags + day cell hours."""
    day_flags: dict[date, bool] = {}
    day_hours: dict[date, float] = {}
    for rec in records:
        if not (week_start <= rec.work_date <= week_end):
            continue
        if not wa.worker_names_match(_worker_short(rec, registry), worker_short):
            continue
        d = rec.work_date
        if rec.no_break:
            day_flags[d] = True
        elif d not in day_flags:
            day_flags[d] = False
        if rec.time_in and rec.time_out:
            h = wa.duration_to_hours(wa.time_to_excel_duration(rec.time_in, rec.time_out))
            day_hours[d] = day_hours.get(d, 0.0) + h
    return day_flags, day_hours


def compute_break_hours(
    worker_short: str,
    records: list[wa.AttendanceRecord],
    week_start: date,
    week_end: date,
    registry: wa.WorkerRegistry,
) -> Optional[time]:
    """
    Total break hours for one employee in one week (col L value).
    Returns None for Franklin (blank cell), else time (0:00 if no no-break days).
    """
    if wa.is_franklin_employee(worker_short):
        return None

    day_flags, day_hours = _day_break_flags_and_hours(
        worker_short, records, week_start, week_end, registry
    )
    total_hours = 0.0
    for d, flagged in day_flags.items():
        if flagged and day_hours.get(d, 0.0) > 0:
            total_hours += day_hours[d] * BREAK_HOURS_PER_WORKED_HOUR

    return wa.hours_to_time(total_hours)


def detail_break_label(worker_short: str, no_break: bool) -> str:
    """
    Detail log Break column.
    - Franklin: always '-' (no break salary)
    - Others: 'No' only when break was NOT taken that entry (extra break pay),
      otherwise '-' (normal break taken).
    """
    if wa.is_franklin_employee(worker_short):
        return "-"
    return "No" if no_break else "-"


def detail_bonus_formula(detail_row: int, worker_short: str, no_break: bool) -> object:
    """
    Detail col Y (bonus / break salary for that entry).
    May: extra pay only when break not taken that day.
    """
    if wa.is_franklin_employee(worker_short) or not no_break:
        return 0
    # 5 min per hour worked × hourly rate × 24
    return f"=U{detail_row}*W{detail_row}*24*(5/60)"


def apply_break_hours_to_month(
    ws: Worksheet,
    layouts: list,
    records: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
) -> int:
    """
    Set col L (Break Hours) on every employee row across all week layouts.
    Returns count of rows updated.
    """
    updated = 0
    for layout in layouts:
        week_recs = [
            r
            for r in records
            if layout.start <= r.work_date <= layout.end and r.time_in and r.time_out
        ]
        for short, row in layout.employee_rows.items():
            if not short:
                continue
            break_time = compute_break_hours(short, week_recs, layout.start, layout.end, registry)
            if break_time is None:
                ws.cell(row, 12).value = None
            else:
                ws.cell(row, 12).value = break_time
                ws.cell(row, 12).number_format = DAY_HOURS_FMT
            updated += 1
    return updated
