"""
Professional month sheet — May-LOOKING overlap layout (built from scratch, not a May copy).

- Left A–O: employees (hours via =U{detail_row}, rates, break, salary)
- Right P–AB: detail in SAME week band (visible, no + / outline)
- Week colors left + right; month weeks clipped (June ends 30-Jun)
- Band height = max(employee block, detail rows) → new employees safe
"""

from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from typing import Optional

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

import break_hours_logic as bh
import wages_automation as wa

DAY_HOURS_FMT = "[h]:mm:ss"
TIME_FMT = "h:mm AM/PM"
MONEY_FMT = "0.00"
MONEY_SUM_FMT = "#,##0.00"

WEEK_COLORS = [
    PatternFill("solid", fgColor="FFFF00"),
    PatternFill("solid", fgColor="92D050"),
    PatternFill("solid", fgColor="F8CBAD"),
    PatternFill("solid", fgColor="BDD7EE"),
    PatternFill("solid", fgColor="FCE4D6"),
]
WEEK_LEFT_TINTS = [
    PatternFill("solid", fgColor="FFFF99"),
    PatternFill("solid", fgColor="C6EFCE"),
    PatternFill("solid", fgColor="FCE4D6"),
    PatternFill("solid", fgColor="DDEBF7"),
    PatternFill("solid", fgColor="FDF2E9"),
]

HDR_GREY = PatternFill("solid", fgColor="808080")
TOTAL_GREY = PatternFill("solid", fgColor="D9D9D9")
DATE_GREY = PatternFill("solid", fgColor="F2F2F2")
FRANKLIN_FILL = PatternFill("solid", fgColor="FFFF00")
WEEK_HDR = PatternFill("solid", fgColor="548235")
WHITE = PatternFill("solid", fgColor="FFFFFF")
SUMMARY_HDR_FILL = PatternFill("solid", fgColor="D0CECE")
TOTAL_SUMMARY_FILL = PatternFill("solid", fgColor="FFF2CC")

_thin = Side(style="thin", color="000000")
BORDER = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT_ALIGN = Alignment(horizontal="left", vertical="center")

MAX_EMP_PER_WEEK = 40
LEFT_LAST_COL = 16  # P — left grid A–P now includes the Addition column
DETAIL_COL_START = 17  # Q
DETAIL_COL_END = 28  # AB

EMPLOYEE_MASTER = "Employee_Master"
STANDARD_LOG = "Attendance_Log"
LOG_HEADERS = ["Date", "WorkerShort", "In", "Out", "NoBreak", "Hours", "Rate", "TotalSalary", "Source"]

DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
WEEK_SUMMARY_LABELS = ["1st Week", "2nd Week", "3rd Week", "4th Week", "5th Week"]
WEEK_SUMMARY_ROWS = [2, 3, 4, 6, 7]
WEEK_SUMMARY_AE_COL = 31
WEEK_SUMMARY_AF_COL = 32

DETAIL_HEADERS = [
    "Date",
    "Day",
    "Name",
    "Time In",
    "Time Out",
    "Total Hours",
    "Break",
    "Per Hour Rate",
    "Working Hours\nProvided Salary",
    "Bonus",
    "Deduction",
    "Total Salary",
]

BOLD = Font(bold=True)
BOLD_WHITE = Font(color="FFFFFF", bold=True)


@dataclass
class WeekLayout:
    week_idx: int
    start: date
    end: date
    week_row: int
    date_row: int
    emp_hdr_row: int
    first_emp_row: int
    total_row: int
    detail_first_row: int
    detail_last_row: int
    employee_rows: dict[str, int] = field(default_factory=dict)
    detail_row_map: dict[tuple[date, str], int] = field(default_factory=dict)


def _paint(ws: Worksheet, r: int, c1: int, c2: int, fill, font=None, align=CENTER) -> None:
    for c in range(c1, c2 + 1):
        cell = ws.cell(r, c)
        cell.fill = fill
        cell.border = BORDER
        cell.alignment = align
        if font:
            cell.font = font


def _style_range(
    ws: Worksheet,
    r1: int,
    c1: int,
    r2: int,
    c2: int,
    fill=None,
    font=None,
    align=None,
    border: bool = True,
) -> None:
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            cell = ws.cell(r, c)
            if fill:
                cell.fill = fill
            if font:
                cell.font = font
            if align:
                cell.alignment = align
            if border:
                cell.border = BORDER


def _dt(d: date) -> datetime:
    return datetime.combine(d, time.min)


def _short_name(worker: str, registry: wa.WorkerRegistry) -> str:
    short = wa.canonical_worker_short(worker, registry) or worker
    if short.lower().startswith("frank"):
        return "Franklin"
    return short


def ensure_employee_master(wb: openpyxl.Workbook) -> Worksheet:
    if EMPLOYEE_MASTER in wb.sheetnames:
        return wb[EMPLOYEE_MASTER]

    registry = wa.build_worker_registry(wb)
    wa.register_template_aliases(registry)

    ws = wb.create_sheet(EMPLOYEE_MASTER)
    headers = ["ShortName", "Aliases", "Bank", "HourlyRate", "BreakRule", "Active"]
    ws.append(headers)
    seen: set[str] = set()
    for short in sorted(registry.short_names()):
        if short in seen:
            continue
        profile = registry.profile_for(short)
        if not profile:
            continue
        seen.add(short)
        rule = "Franklin" if wa.is_franklin_employee(profile.excel_name) else "Normal"
        ws.append(
            [
                short,
                "",
                profile.bank_name or "",
                profile.hourly_rate or 0,
                rule,
                "Yes",
            ]
        )
    _style_range(ws, 1, 1, 1, len(headers), WEEK_HDR, BOLD_WHITE, CENTER)
    ws.freeze_panes = "A2"
    return ws


def upsert_new_employees(
    wb: openpyxl.Workbook,
    records: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
) -> list[str]:
    """Append unknown workers to Employee_Master so layout/VLOOKUP stay safe."""
    ws = ensure_employee_master(wb)
    existing: set[str] = set()
    for r in range(2, ws.max_row + 1):
        v = ws.cell(r, 1).value
        if v:
            existing.add(str(v).strip())

    added: list[str] = []
    for rec in records:
        if not (rec.time_in and rec.time_out):
            continue
        short = _short_name(rec.worker, registry)
        if not wa.is_valid_worker_short(short) or short in existing:
            continue
        profile = registry.profile_for(short)
        bank = profile.bank_name if profile else ""
        rate = profile.hourly_rate if profile else 0
        rule = "Franklin" if wa.is_franklin_employee(short) else "Normal"
        ws.append([short, "", bank or "", rate or 0, rule, "Yes"])
        existing.add(short)
        added.append(short)
        if not profile:
            registry.register(
                wa.WorkerProfile(
                    excel_name=short,
                    short_name=short,
                    bank_name=bank or "",
                    hourly_rate=float(rate or 0),
                    empty_break_hours=wa.is_franklin_employee(short),
                )
            )
    return added


def ensure_standard_attendance_log(wb: openpyxl.Workbook) -> Worksheet:
    if STANDARD_LOG in wb.sheetnames:
        ws = wb[STANDARD_LOG]
        if ws.cell(1, 1).value == "Date":
            return ws
        old_max = ws.max_row
        if old_max > 1:
            ws.delete_rows(1, old_max)

    ws = wb.create_sheet(STANDARD_LOG) if STANDARD_LOG not in wb.sheetnames else wb[STANDARD_LOG]
    for col, h in enumerate(LOG_HEADERS, 1):
        ws.cell(1, col).value = h
    _style_range(ws, 1, 1, 1, len(LOG_HEADERS), WEEK_HDR, BOLD_WHITE, CENTER)
    ws.freeze_panes = "A2"
    for c in range(1, len(LOG_HEADERS) + 1):
        ws.column_dimensions[get_column_letter(c)].width = 16
    return ws


def write_standard_attendance_log(
    wb: openpyxl.Workbook,
    records: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
) -> dict[tuple[date, str], int]:
    ws = ensure_standard_attendance_log(wb)
    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row - 1)

    row_map: dict[tuple[date, str], int] = {}
    row = 2
    for rec in sorted(records, key=lambda r: (r.work_date, r.worker, r.time_in or time(0))):
        if not (rec.time_in and rec.time_out):
            continue
        if rec.work_date < wa.CUTOFF_DATE:
            continue
        short = _short_name(rec.worker, registry)
        ws.cell(row, 1).value = _dt(rec.work_date)
        ws.cell(row, 2).value = short
        ws.cell(row, 3).value = rec.time_in
        ws.cell(row, 4).value = rec.time_out
        ws.cell(row, 5).value = 1 if rec.no_break else 0
        ws.cell(row, 6).value = (
            f'=IF(OR(C{row}="",D{row}=""),0,'
            f'IF(D{row}>=C{row},D{row}-C{row},D{row}-C{row}+1))'
        )
        ws.cell(row, 7).value = f"=IFERROR(VLOOKUP(B{row},{EMPLOYEE_MASTER}!A:D,4,FALSE),0)"
        ws.cell(row, 8).value = f"=F{row}*G{row}*24"
        ws.cell(row, 9).value = (rec.source or "")[:300]
        ws.cell(row, 3).number_format = TIME_FMT
        ws.cell(row, 4).number_format = TIME_FMT
        ws.cell(row, 6).number_format = DAY_HOURS_FMT
        ws.cell(row, 7).number_format = "0.00"
        ws.cell(row, 8).number_format = MONEY_SUM_FMT
        row_map[(rec.work_date, short)] = row
        row += 1
    return row_map


def week_workers(
    records: list[wa.AttendanceRecord],
    start: date,
    end: date,
    registry: wa.WorkerRegistry,
) -> list[str]:
    shorts: set[str] = set()
    for rec in records:
        if not (start <= rec.work_date <= end and rec.time_in and rec.time_out):
            continue
        short = _short_name(rec.worker, registry)
        if short and wa.is_valid_worker_short(short):
            shorts.add(short)
    return sorted(shorts)


def write_week_salary_summary(ws: Worksheet, layouts: list[WeekLayout]) -> None:
    ae, af = WEEK_SUMMARY_AE_COL, WEEK_SUMMARY_AF_COL
    ws.cell(1, ae).value = "Week Colors"
    ws.cell(1, af).value = "Salary Sent"
    _paint(ws, 1, ae, af, SUMMARY_HDR_FILL, BOLD)

    for r in range(2, 9):
        for c in (ae, af):
            ws.cell(r, c).value = None
            ws.cell(r, c).fill = PatternFill()
            ws.cell(r, c).border = BORDER

    for idx, layout in enumerate(layouts[:5]):
        r = WEEK_SUMMARY_ROWS[idx]
        fill = WEEK_COLORS[idx]
        ws.cell(r, ae).value = WEEK_SUMMARY_LABELS[idx]
        ws.cell(r, af).value = f"=O{layout.total_row}"
        _paint(ws, r, ae, af, fill, BOLD)
        ws.cell(r, af).number_format = MONEY_SUM_FMT

    for idx in range(len(layouts), 5):
        r = WEEK_SUMMARY_ROWS[idx]
        fill = WEEK_COLORS[idx]
        ws.cell(r, ae).value = WEEK_SUMMARY_LABELS[idx]
        ws.cell(r, af).value = 0
        _paint(ws, r, ae, af, fill, BOLD)
        ws.cell(r, af).number_format = MONEY_SUM_FMT

    ws.cell(5, ae).value = None
    ws.cell(5, af).value = 0
    ws.cell(5, af).number_format = MONEY_SUM_FMT
    _paint(ws, 5, af, af, WEEK_COLORS[2])

    ws.cell(8, ae).value = "Total Salary Send"
    ws.cell(8, af).value = "=SUM(AF2:AF7)"
    _paint(ws, 8, ae, af, TOTAL_SUMMARY_FILL, BOLD)
    ws.cell(8, af).number_format = MONEY_SUM_FMT
    ws.column_dimensions["AE"].width = 18
    ws.column_dimensions["AF"].width = 14


def build_month_sheet(
    wb: openpyxl.Workbook,
    year: int,
    month: int,
    records: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
    log_row_map: dict[tuple[date, str], int],
) -> tuple[Worksheet, list[WeekLayout], int]:
    """Build May-style overlap month. Returns (ws, layouts, detail_count)."""
    ensure_employee_master(wb)
    sheet_name = wa.sheet_name_for_date(date(year, month, 1))
    if sheet_name in wb.sheetnames:
        del wb[sheet_name]

    ws = wb.create_sheet(sheet_name)
    ws["A1"] = f"{calendar.month_name[month]} Attendance {year}"
    ws["A1"].font = Font(bold=True, size=14)

    for i, h in enumerate(DETAIL_HEADERS, start=DETAIL_COL_START):
        ws.cell(1, i).value = h
    _paint(ws, 1, DETAIL_COL_START, DETAIL_COL_END, HDR_GREY, BOLD_WHITE)

    month_recs = [
        r
        for r in records
        if r.work_date.year == year
        and r.work_date.month == month
        and r.time_in
        and r.time_out
    ]
    ranges = wa.month_week_ranges(year, month)
    layouts: list[WeekLayout] = []
    cur = 2
    detail_written = 0

    for wi, (start, end) in enumerate(ranges):
        week_fill = WEEK_COLORS[wi % len(WEEK_COLORS)]
        left_fill = WEEK_LEFT_TINTS[wi % len(WEEK_LEFT_TINTS)]
        label = WEEK_SUMMARY_LABELS[wi] if wi < len(WEEK_SUMMARY_LABELS) else f"{wi + 1}th Week"

        week_dates: list[date] = []
        d = start
        while d <= end:
            week_dates.append(d)
            d += timedelta(days=1)

        emps = week_workers(month_recs, start, end, registry)
        emps = emps[:MAX_EMP_PER_WEEK]
        n_emp = max(len(emps), 1)

        week_recs = [
            r for r in month_recs if start <= r.work_date <= end
        ]
        week_recs.sort(key=lambda r: (r.work_date, _short_name(r.worker, registry)))

        left_rows = 3 + n_emp + 1  # title + dates + hdr + emps + total
        detail_rows = max(len(week_recs), 1)
        band_rows = max(left_rows, detail_rows)

        r_week = cur
        r_date = r_week + 1
        r_emp_hdr = r_date + 1
        r_first_emp = r_emp_hdr + 1
        r_total = r_first_emp + n_emp
        r_detail_first = r_week
        r_band_end = r_week + band_rows - 1
        r_detail_last = r_detail_first + len(week_recs) - 1 if week_recs else r_detail_first

        layout = WeekLayout(
            week_idx=wi + 1,
            start=start,
            end=end,
            week_row=r_week,
            date_row=r_date,
            emp_hdr_row=r_emp_hdr,
            first_emp_row=r_first_emp,
            total_row=r_total,
            detail_first_row=r_detail_first,
            detail_last_row=max(r_detail_last, r_detail_first),
            employee_rows={},
            detail_row_map={},
        )

        # Week title
        ws.cell(r_week, 1).value = wa.format_week_title(start, end)
        _paint(ws, r_week, 1, LEFT_LAST_COL, week_fill, BOLD)
        try:
            ws.merge_cells(
                start_row=r_week, start_column=1, end_row=r_week, end_column=LEFT_LAST_COL
            )
        except ValueError:
            pass

        # Date row — month-clipped only
        for i in range(7):
            col = 2 + i
            if i < len(week_dates):
                wd = week_dates[i]
                ws.cell(r_date, col).value = _dt(wd)
                ws.cell(r_date, col).number_format = "d-mmm"
                ws.cell(r_date, col).font = BOLD
            else:
                ws.cell(r_date, col).value = None
            ws.cell(r_date, col).fill = DATE_GREY
            ws.cell(r_date, col).border = BORDER
            ws.cell(r_date, col).alignment = CENTER

        day_hdrs = [DAY_NAMES[wd.weekday()] for wd in week_dates]
        while len(day_hdrs) < 7:
            day_hdrs.append("")
        left_hdr = [
            "Employee Name",
            *day_hdrs,
            "BANK NAMES",
            "Per Hour",
            "Salary",
            "Break Hours",
            "Break Hours Salary",
            "Addition",
            "Total Salary Send",
            "Total Hours",
        ]
        for i, h in enumerate(left_hdr, start=1):
            ws.cell(r_emp_hdr, i).value = h or None
        _paint(ws, r_emp_hdr, 1, LEFT_LAST_COL, HDR_GREY, BOLD_WHITE)

        # Detail P–AB (overlap from week title row)
        for i, rec in enumerate(week_recs):
            r = r_detail_first + i
            short = _short_name(rec.worker, registry)
            log_row = log_row_map.get((rec.work_date, short)) or log_row_map.get(
                (rec.work_date, rec.worker)
            )
            layout.detail_row_map[(rec.work_date, short)] = r

            # Detail Q–AB (official layout): Q Date … AB Total Salary
            ws.cell(r, 17).value = _dt(rec.work_date)
            ws.cell(r, 17).number_format = "d-mmm-yy"
            ws.cell(r, 18).value = DAY_NAMES[rec.work_date.weekday()]
            ws.cell(r, 19).value = short
            if log_row:
                ws.cell(r, 20).value = f"={STANDARD_LOG}!C{log_row}"
                ws.cell(r, 21).value = f"={STANDARD_LOG}!D{log_row}"
                ws.cell(r, 22).value = f"={STANDARD_LOG}!F{log_row}"
                ws.cell(r, 24).value = f"={STANDARD_LOG}!G{log_row}"
            else:
                ws.cell(r, 20).value = rec.time_in
                ws.cell(r, 21).value = rec.time_out
                ws.cell(r, 22).value = f"=U{r}-T{r}"
                ws.cell(r, 24).value = f"=IFERROR(VLOOKUP(S{r},{EMPLOYEE_MASTER}!A:D,4,FALSE),0)"
            ws.cell(r, 20).number_format = TIME_FMT
            ws.cell(r, 21).number_format = TIME_FMT
            ws.cell(r, 22).number_format = "h:mm"
            ws.cell(r, 23).value = bh.detail_break_label(short, rec.no_break)
            ws.cell(r, 25).value = f"=V{r}*X{r}*24"
            ws.cell(r, 25).number_format = MONEY_FMT
            ws.cell(r, 26).value = 0
            ws.cell(r, 27).value = 0
            ws.cell(r, 26).number_format = MONEY_FMT
            ws.cell(r, 27).number_format = MONEY_FMT
            # May display: Total Salary column often 0.00
            ws.cell(r, 28).value = 0
            ws.cell(r, 28).number_format = MONEY_FMT
            _paint(ws, r, DETAIL_COL_START, DETAIL_COL_END, week_fill)
            detail_written += 1

        for r in range(r_detail_first + len(week_recs), r_band_end + 1):
            _paint(ws, r, DETAIL_COL_START, DETAIL_COL_END, week_fill)

        # Employee rows (grows with new workers — band already sized)
        display_emps = emps if emps else [""]
        for ei in range(n_emp):
            short = display_emps[ei] if ei < len(display_emps) else ""
            r = r_first_emp + ei
            if not short:
                _paint(ws, r, 1, LEFT_LAST_COL, left_fill)
                continue
            layout.employee_rows[short] = r
            ws.cell(r, 1).value = short
            ws.cell(r, 9).value = f'=IFERROR(VLOOKUP(A{r},{EMPLOYEE_MASTER}!A:C,3,FALSE),"")'
            ws.cell(r, 10).value = f"=IFERROR(VLOOKUP(A{r},{EMPLOYEE_MASTER}!A:D,4,FALSE),0)"
            ws.cell(r, 11).value = f"=P{r}*J{r}*24"  # Salary = Total Hours × rate × 24
            ws.cell(r, 13).value = f"=L{r}*J{r}*24"  # Break Hours Salary
            ws.cell(r, 14).value = 0  # Addition (manual bonus, default 0)
            ws.cell(r, 15).value = f"=K{r}+M{r}+N{r}"  # Total Salary Send = Salary + Break + Addition
            ws.cell(r, 16).value = f"=SUM(B{r}:H{r})"  # Total Hours

            for ci in range(7):
                col = 2 + ci
                if ci >= len(week_dates):
                    ws.cell(r, col).value = None
                    continue
                wd = week_dates[ci]
                drow = layout.detail_row_map.get((wd, short))
                if drow:
                    ws.cell(r, col).value = f"=V{drow}"
                else:
                    ws.cell(r, col).value = time(0, 0)
                ws.cell(r, col).number_format = DAY_HOURS_FMT

            if short == "Franklin" or wa.is_franklin_employee(short):
                ws.cell(r, 12).value = None
            else:
                ws.cell(r, 12).value = time(0, 0)
                ws.cell(r, 12).number_format = DAY_HOURS_FMT

            fill = FRANKLIN_FILL if short == "Franklin" or wa.is_franklin_employee(short) else left_fill
            _paint(ws, r, 1, LEFT_LAST_COL, fill)
            ws.cell(r, 1).alignment = LEFT_ALIGN
            for c in (11, 13, 14, 15):
                ws.cell(r, c).number_format = MONEY_FMT
            ws.cell(r, 16).number_format = DAY_HOURS_FMT

        # Total
        ws.cell(r_total, 1).value = "Total"
        emp_last = r_total - 1
        emp_first = r_first_emp
        for c in range(2, LEFT_LAST_COL + 1):
            col = get_column_letter(c)
            if emp_last >= emp_first:
                ws.cell(r_total, c).value = f"=SUM({col}{emp_first}:{col}{emp_last})"
            else:
                ws.cell(r_total, c).value = 0
            if c <= 8 or c in (12, 16):
                ws.cell(r_total, c).number_format = DAY_HOURS_FMT
            elif c in (11, 13, 14, 15):
                ws.cell(r_total, c).number_format = MONEY_FMT
        _paint(ws, r_total, 1, LEFT_LAST_COL, TOTAL_GREY, BOLD)

        for r in range(r_total + 1, r_band_end + 1):
            if ws.cell(r, 1).value is None:
                _paint(ws, r, 1, LEFT_LAST_COL, left_fill)

        layouts.append(layout)
        cur = r_band_end + 2

    ws.column_dimensions["A"].width = 16
    for c in range(2, 9):
        ws.column_dimensions[get_column_letter(c)].width = 10
    for c in range(9, LEFT_LAST_COL + 1):
        ws.column_dimensions[get_column_letter(c)].width = 12
    for c in range(DETAIL_COL_START, DETAIL_COL_END + 1):
        ws.column_dimensions[get_column_letter(c)].width = 11

    write_week_salary_summary(ws, layouts)
    # No freeze panes — avoids zoom scroll issue
    ws.sheet_view.showOutlineSymbols = False

    return ws, layouts, detail_written


def rebuild_month_view(
    wb: openpyxl.Workbook,
    year: int,
    month: int,
    records: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
) -> tuple[Worksheet, int]:
    """Master + log + May-style overlap month + break hours."""
    ensure_employee_master(wb)
    records = wa.dedupe_records(records, registry)
    new_emps = upsert_new_employees(wb, records, registry)
    if new_emps:
        print(f"  New employees added to Employee_Master: {', '.join(new_emps)}")

    log_map = write_standard_attendance_log(wb, records, registry)
    ws, layouts, n = build_month_sheet(wb, year, month, records, registry, log_map)
    bh.apply_break_hours_to_month(ws, layouts, records, registry)
    wb.calculation.fullCalcOnLoad = True
    return ws, n
