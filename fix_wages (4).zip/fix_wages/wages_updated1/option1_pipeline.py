#!/usr/bin/env python3
"""
Option 1 - efficient attendance pipeline.

1) WhatsApp chat -> attendance CSV (source of truth)
2) For each month (June 2026+): delete month sheet -> copy 05-May-26 ->
   presize workers + detail slots -> write all entries once

No incremental relocate / repair loops that break March/May layout.
August / September: same path - new month -> May copy -> fill.
"""

from __future__ import annotations

import csv
import shutil
from datetime import date, time
from pathlib import Path

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

import wages_automation as wa

ATTENDANCE_CSV = wa.BASE_DIR / "attendance_from_chat.csv"
PIPELINE_README = wa.BASE_DIR / "OPTION1_README.txt"


def write_attendance_csv(
    records: list[wa.AttendanceRecord], path: Path = ATTENDANCE_CSV
) -> None:
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(
            ["worker", "work_date", "time_in", "time_out", "no_break", "sender", "source"]
        )
        for rec in sorted(
            records, key=lambda r: (r.work_date, r.worker, r.time_in or time(0))
        ):
            writer.writerow(
                [
                    rec.worker,
                    rec.work_date.isoformat(),
                    rec.time_in.strftime("%H:%M:%S") if rec.time_in else "",
                    rec.time_out.strftime("%H:%M:%S") if rec.time_out else "",
                    "1" if rec.no_break else "0",
                    rec.sender,
                    rec.source.replace("\n", " ")[:300],
                ]
            )


def load_attendance_csv(path: Path = ATTENDANCE_CSV) -> list[wa.AttendanceRecord]:
    if not path.exists():
        return []
    records: list[wa.AttendanceRecord] = []
    with path.open(encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            ti = row.get("time_in") or ""
            to = row.get("time_out") or ""
            if not ti or not to:
                continue
            hin, min_, sin = map(int, ti.split(":"))
            hout, mout, so = map(int, to.split(":"))
            records.append(
                wa.AttendanceRecord(
                    worker=row["worker"],
                    work_date=date.fromisoformat(row["work_date"]),
                    time_in=time(hin, min_, sin),
                    time_out=time(hout, mout, so),
                    no_break=row.get("no_break", "0") == "1",
                    source=row.get("source", "csv"),
                    sender=row.get("sender", ""),
                )
            )
    return records


def delete_month_sheet_if_exists(wb: openpyxl.Workbook, year: int, month: int) -> None:
    name = wa.sheet_name_for_date(date(year, month, 1))
    if name == wa.TEMPLATE_SHEET:
        raise RuntimeError(f"Cannot delete template {wa.TEMPLATE_SHEET}")
    if date(year, month, 1) < date(wa.CUTOFF_DATE.year, wa.CUTOFF_DATE.month, 1):
        raise RuntimeError(f"Refusing to delete pre-cutoff sheet {name}")
    if name in wb.sheetnames:
        del wb[name]


def create_fresh_month_sheet(
    wb: openpyxl.Workbook,
    year: int,
    month: int,
    load: wa.MonthLoad,
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
) -> Worksheet:
    delete_month_sheet_if_exists(wb, year, month)
    return wa.ensure_month_sheet(wb, year, month, stats, registry, load)


def write_record_once(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    week: wa.WeekSection,
    rec: wa.AttendanceRecord,
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
    day_break_flags: dict[date, bool],
) -> None:
    profile = wa.lookup_worker_profile(wb, registry, rec.worker, rec.sender or rec.worker)
    if not wa.is_valid_worker_short(profile.short_name):
        wa.log_skip(stats, "Invalid worker name", rec.source)
        return

    employee_row = wa.resolve_employee_row(ws, week, registry, profile)
    if employee_row is None:
        wa.log_skip(
            stats,
            "Worker missing after presize",
            f"{profile.excel_name} | {rec.source}",
        )
        return

    day_col = wa.find_day_col(week, rec.work_date)
    if not day_col:
        wa.log_skip(stats, "Date not in week columns", rec.source)
        return

    if wa.is_duplicate_detail_entry(
        ws, rec.worker, rec.work_date, rec.time_in, rec.time_out
    ):
        wa.log_skip(stats, "Duplicate entry", rec.source)
        return

    if wa.cell_is_filled(ws, employee_row, day_col):
        wa.log_skip(stats, "Cell already has data", rec.source)
        return

    detail_row = wa.find_free_detail_row(ws, week, employee_row=employee_row)
    if detail_row is None:
        wa.log_skip(stats, "No free detail row (presize short)", rec.source)
        return

    wa.write_detail_entry(
        ws,
        detail_row,
        profile.short_name,
        rec.work_date,
        rec.time_in,
        rec.time_out,
        profile.empty_break_hours,
        wb,
        week,
        profile.hourly_rate,
        employee_row,
    )

    if not wa.validate_detail_row(ws, detail_row, week):
        for col in range(wa.DETAIL_COLS["date"], wa.DETAIL_LOG_LAST_COL + 1):
            ws.cell(detail_row, col).value = None
        wa.log_skip(stats, "Invalid detail row after write", rec.source)
        return

    wa.link_employee_day_to_detail(
        ws, wb, employee_row, day_col, detail_row, week, rec.time_in, rec.time_out
    )

    if rec.no_break:
        day_break_flags[rec.work_date] = True
    elif rec.work_date not in day_break_flags:
        day_break_flags[rec.work_date] = False

    recalc = {d: day_break_flags.get(d, False) for d in week.dates.values()}
    wa.recalculate_employee_week(
        ws, week, employee_row, rec.worker, recalc, profile.empty_break_hours
    )
    stats.added += 1
    stats.updated_sheets.add(ws.title)


def fill_month_from_records(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    records: list[wa.AttendanceRecord],
    year: int,
    month: int,
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
) -> None:
    day_break_flags: dict[date, bool] = {}
    month_recs = [
        r
        for r in records
        if r.work_date.year == year
        and r.work_date.month == month
        and r.time_in
        and r.time_out
    ]
    month_recs.sort(key=lambda r: (r.work_date, r.worker, r.time_in or time(0)))

    for rec in month_recs:
        weeks = wa.find_week_sections(ws)
        week = wa.find_week_for_date(weeks, rec.work_date)
        if not week:
            wa.log_skip(stats, "No week section for date", rec.source)
            continue
        write_record_once(wb, ws, week, rec, registry, stats, day_break_flags)


def merge_attendance_records(
    existing: list[wa.AttendanceRecord],
    fresh: list[wa.AttendanceRecord],
) -> list[wa.AttendanceRecord]:
    """Merge chat parse into CSV history — same worker+date: newer chat wins."""
    by_key: dict[tuple[str, date], wa.AttendanceRecord] = {}
    for rec in existing:
        by_key[(rec.worker, rec.work_date)] = rec
    for rec in fresh:
        by_key[(rec.worker, rec.work_date)] = rec
    return sorted(by_key.values(), key=lambda r: (r.work_date, r.worker, r.time_in or time(0)))


def finalize_month_sheet(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
) -> None:
    # Never trim after writes — row deletes break =U links. Trim runs at presize only.
    fixed = wa.sanitize_orphan_day_links(ws)
    if fixed:
        print(f"  Cleared {fixed} orphan day links")

    wa.fix_detail_log_formulas(ws)
    wa.reset_month_employee_formulas(ws)
    wa.apply_employee_grid_styles(ws, wb[wa.TEMPLATE_SHEET])
    wa.sync_employee_hourly_rates(ws, wb, registry)
    wa.normalize_employee_day_cells(ws)
    wa.normalize_detail_hours_formats(ws)
    wa.restore_week_salary_summary(ws, wb)
    wa.restore_week_ab_merges(ws, wb[wa.TEMPLATE_SHEET])
    # Full week yellow/green/pink colors like May — whole detail band
    wa.apply_week_detail_log_fills(ws, wb)
    for issue in wa.validate_month_sheet(ws):
        stats.skip_log.append(f"VALIDATION | {issue}")


def write_pipeline_readme() -> None:
    PIPELINE_README.write_text(
        "\n".join(
            [
                "OPTION 1 PIPELINE",
                "=================",
                "1. Chat -> attendance_from_chat.csv (source of truth)",
                "2. Each month sheet (06-Jun-26+) is deleted and rebuilt from 05-May-26",
                "3. Workers for that week are added left of Total; detail goes on the right",
                "4. August / September: same - just run again when chat has those dates",
                "5. Never edit 05-May-26",
                "6. New workers: added on left (before Total) then detail on right",
                "7. Aug/Sep: same command whenever chat has those dates",
                "",
                "Run:  python option1_pipeline.py",
                "Or:   python wages_automation.py",
                "",
            ]
        ),
        encoding="utf-8",
    )


def run_option1() -> None:
    stats = wa.Stats()

    if not wa.EXCEL_FILE.exists():
        raise FileNotFoundError(f"Excel file not found: {wa.EXCEL_FILE}")
    if not wa.CHAT_FILE.exists():
        raise FileNotFoundError(f"Chat file not found: {wa.CHAT_FILE}")

    print(f"Creating backup: {wa.BACKUP_FILE}")
    shutil.copy2(wa.EXCEL_FILE, wa.BACKUP_FILE)
    write_pipeline_readme()

    wb = openpyxl.load_workbook(wa.EXCEL_FILE)
    registry = wa.build_worker_registry(wb)
    wa.register_template_aliases(registry)

    messages = wa.read_chat_messages(wa.CHAT_FILE)
    fresh_records = wa.parse_records(messages, stats, registry)
    existing_records = load_attendance_csv()
    records = merge_attendance_records(existing_records, fresh_records)
    print(
        f"Parsed {len(fresh_records)} from chat; "
        f"{len(existing_records)} in CSV; "
        f"{len(records)} total after merge"
    )

    write_attendance_csv(records)
    print(f"Wrote source of truth: {ATTENDANCE_CSV}")

    months = sorted({(r.work_date.year, r.work_date.month) for r in records})
    for year, month in months:
        load = wa.analyze_month_load(records, year, month)
        for idx, week_load in enumerate(load.weeks, 1):
            print(
                f"  {year}-{month:02d} week {idx}: "
                f"{week_load.entry_count} entries, "
                f"{len(week_load.worker_shorts)} workers"
            )
        sheet_name = wa.sheet_name_for_date(date(year, month, 1))
        print(f"Rebuilding {sheet_name} from {wa.TEMPLATE_SHEET} ...")
        ws = create_fresh_month_sheet(wb, year, month, load, registry, stats)
        fill_month_from_records(wb, ws, records, year, month, registry, stats)
        finalize_month_sheet(wb, ws, registry, stats)

    wb.calculation.fullCalcOnLoad = True
    wb.save(wa.EXCEL_FILE)
    wa.write_skipped(stats)
    wa.write_new_workers(stats)
    wa.print_summary(stats)
    print("Option 1 complete: CSV + full May-copy rebuild (no patch loops).")


if __name__ == "__main__":
    run_option1()
