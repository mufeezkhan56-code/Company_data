@echo off
cd /d "%~dp0"

echo ========================================
echo  UK Wages - Update from WhatsApp chat
echo ========================================
echo.
echo IMPORTANT: Close the Excel file first.
echo.
pause

echo.
echo Running update...
echo.

python sync_pipeline.py
set EXITCODE=%ERRORLEVEL%

echo.
if %EXITCODE% EQU 0 (
    echo Done. Open the Excel file to check.
) else (
    echo Failed. If Permission denied, close Excel and try again.
)
echo.
pause
