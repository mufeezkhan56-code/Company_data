#!/usr/bin/env python3
"""
Sync pipeline — stable delivery model.

1) All chats  →  Attendance_Log sheet (upsert by worker+date, never wipe month)
2) Month sheet (06-Jun-26, 08-Aug-26…) created ONCE from 05-May-26 — never deleted
3) Each run: sync only weeks that have attendance rows → left workers + right detail
"""

from __future__ import annotations

import calendar
import shutil
from datetime import date, datetime, time, timedelta
from typing import Optional

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

import wages_automation as wa
from month_view_builder import (
    ensure_employee_master,
    ensure_standard_attendance_log,
    rebuild_month_view,
)

ATTENDANCE_LOG_SHEET = "Attendance_Log"
LOG_HEADERS = [
    "year",
    "month",
    "week",
    "work_date",
    "day",
    "worker",
    "time_in",
    "time_out",
    "no_break",
    "source",
]


def week_index_for_date(year: int, month: int, d: date) -> int:
    for idx, (start, end) in enumerate(wa.month_week_ranges(year, month), 1):
        if start <= d <= end:
            return idx
    return 0


def ensure_attendance_log_sheet(wb: openpyxl.Workbook) -> Worksheet:
    if ATTENDANCE_LOG_SHEET in wb.sheetnames:
        return wb[ATTENDANCE_LOG_SHEET]
    ws = wb.create_sheet(ATTENDANCE_LOG_SHEET)
    ws.cell(1, 1).value = "Attendance Log (source of truth — do not delete)"
    for col, header in enumerate(LOG_HEADERS, 1):
        ws.cell(2, col).value = header
    return ws


def _parse_time_cell(val) -> Optional[time]:
    if isinstance(val, time):
        return val
    if isinstance(val, datetime):
        return val.time()
    if isinstance(val, str) and val:
        if val.startswith("="):
            return None
        parts = val.split(":")
        if len(parts) >= 2:
            try:
                return time(int(parts[0]), int(parts[1]), int(parts[2]) if len(parts) > 2 else 0)
            except ValueError:
                return None
    return None


def _parse_work_date(val) -> Optional[date]:
    if isinstance(val, datetime):
        return val.date()
    if isinstance(val, date):
        return val
    if val is None:
        return None
    text = str(val).strip()
    if not text:
        return None
    if "T" in text:
        text = text.split("T", 1)[0]
    if len(text) >= 10 and text[4] == "-" and text[7] == "-":
        try:
            return date.fromisoformat(text[:10])
        except ValueError:
            return None
    return None


def _log_format(ws: Worksheet) -> str:
    """Return 'standard' (Date col A row 1) or 'legacy' (year/month/week headers row 2)."""
    h1 = str(ws.cell(1, 1).value or "").strip().lower()
    if h1 == "date":
        return "standard"
    h2 = str(ws.cell(2, 1).value or "").strip().lower()
    if h2 == "year":
        return "legacy"
    if h1.startswith("attendance log"):
        return "legacy"
    if _parse_work_date(ws.cell(2, 1).value) and ws.cell(2, 2).value:
        return "standard"
    return "legacy"


def read_attendance_log(wb: openpyxl.Workbook) -> list[wa.AttendanceRecord]:
    if ATTENDANCE_LOG_SHEET not in wb.sheetnames:
        return []
    ws = wb[ATTENDANCE_LOG_SHEET]
    fmt = _log_format(ws)
    records: list[wa.AttendanceRecord] = []
    start_row = 2 if fmt == "standard" else 3

    for row in range(start_row, ws.max_row + 1):
        if fmt == "standard":
            dt = ws.cell(row, 1).value
            worker = ws.cell(row, 2).value
            t_in = _parse_time_cell(ws.cell(row, 3).value)
            t_out = _parse_time_cell(ws.cell(row, 4).value)
            no_break_val = ws.cell(row, 5).value
            source = ws.cell(row, 9).value
            # Skip formula-only rows (Hours/Rate/Salary columns)
            if isinstance(t_in, str) and t_in.startswith("="):
                t_in = None
            if isinstance(t_out, str) and t_out.startswith("="):
                t_out = None
        else:
            worker = ws.cell(row, 6).value
            dt = ws.cell(row, 4).value
            t_in = _parse_time_cell(ws.cell(row, 7).value)
            t_out = _parse_time_cell(ws.cell(row, 8).value)
            no_break_val = ws.cell(row, 9).value
            source = ws.cell(row, 10).value

        work_date = _parse_work_date(dt)
        if not worker or not work_date:
            continue
        if not (t_in and t_out):
            continue
        records.append(
            wa.AttendanceRecord(
                worker=str(worker).strip(),
                work_date=work_date,
                time_in=t_in,
                time_out=t_out,
                no_break=str(no_break_val or "0").strip() in ("1", "True", "true", "Yes", "yes"),
                source=str(source or "log"),
                sender="",
            )
        )
    return records


def write_attendance_log(wb: openpyxl.Workbook, records: list[wa.AttendanceRecord]) -> None:
    ws = ensure_attendance_log_sheet(wb)
    # Clear old data rows only (not structure)
    if ws.max_row >= 3:
        ws.delete_rows(3, ws.max_row - 2)
    row = 3
    for rec in sorted(records, key=lambda r: (r.work_date, r.worker, r.time_in or time(0))):
        if rec.work_date < wa.CUTOFF_DATE:
            continue
        if not (rec.time_in and rec.time_out):
            continue
        ws.cell(row, 1).value = rec.work_date.year
        ws.cell(row, 2).value = rec.work_date.month
        ws.cell(row, 3).value = week_index_for_date(
            rec.work_date.year, rec.work_date.month, rec.work_date
        )
        ws.cell(row, 4).value = datetime.combine(rec.work_date, time.min)
        ws.cell(row, 5).value = calendar.day_name[rec.work_date.weekday()]
        ws.cell(row, 6).value = rec.worker
        ws.cell(row, 7).value = rec.time_in
        ws.cell(row, 8).value = rec.time_out
        ws.cell(row, 9).value = 1 if rec.no_break else 0
        ws.cell(row, 10).value = rec.source.replace("\n", " ")[:300]
        row += 1


def merge_records(
    existing: list[wa.AttendanceRecord],
    fresh: list[wa.AttendanceRecord],
) -> list[wa.AttendanceRecord]:
    """Full chat re-parse is source of truth — skipped days drop off the log."""
    del existing  # kept for call-site compatibility; log is rebuilt from chat only
    return sorted(fresh, key=lambda r: (r.work_date, r.worker, r.time_in or time(0)))


def upsert_attendance_from_chat(
    wb: openpyxl.Workbook,
    stats: wa.Stats,
    registry: wa.WorkerRegistry,
) -> list[wa.AttendanceRecord]:
    existing = read_attendance_log(wb)
    if not existing:
        from option1_pipeline import load_attendance_csv

        existing = load_attendance_csv()
    messages = wa.read_chat_messages(wa.CHAT_FILE)
    fresh = wa.parse_records(messages, stats, registry)
    merged = merge_records(existing, fresh)
    from option1_pipeline import write_attendance_csv

    write_attendance_csv(merged)
    # Attendance_Log sheet is written by rebuild_month_view (standard format + formulas)
    print(
        f"Attendance_Log: {len(fresh)} from chat, "
        f"{len(existing)} was in log, {len(merged)} total after merge"
    )
    return merged


def month_dates_aligned(ws: Worksheet, year: int, month: int) -> bool:
    """Detect rebuild-broken sheets (e.g. week header says 08-14 but dates are 15-21)."""
    weeks = wa.find_week_sections(ws)
    ranges = wa.month_week_ranges(year, month)
    if len(weeks) < len(ranges):
        return False
    for week, (start, end) in zip(weeks, ranges):
        if not week.dates:
            return False
        for d in week.dates.values():
            if d < start or d > end:
                return False
    return True


def month_block_reasonable(ws: Worksheet, wb: openpyxl.Workbook) -> bool:
    """Only flag absurd runaway tails (old bug), not normal high-entry weeks."""
    for ww in wa.find_week_sections(ws):
        if not ww.total_row:
            continue
        tail = ww.end_row - ww.total_row
        if tail > 50:
            return False
    return True


def week_worker_shorts(
    records: list[wa.AttendanceRecord], registry: wa.WorkerRegistry
) -> set[str]:
    shorts: set[str] = set()
    for rec in records:
        short = wa.canonical_worker_short(rec.worker, registry)
        if short and short.lower().startswith("frank"):
            short = "Franklin"
        if short and wa.is_valid_worker_short(short):
            shorts.add(short)
    return shorts


def presize_week_from_attendance(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    week_idx: int,
    week_recs: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
    grow_detail_buffer: bool = False,
) -> None:
    """Add missing employee rows; optional one-time detail buffer at sheet creation."""
    weeks = wa.find_week_sections(ws)
    if week_idx >= len(weeks):
        return
    week = weeks[week_idx]

    for short in sorted(week_worker_shorts(week_recs, registry)):
        profile = wa.lookup_worker_profile(wb, registry, short, short)
        if wa.resolve_existing_worker_row(ws, week, registry, profile) is None:
            wa.ensure_worker_in_week(wb, ws, week, short, short, registry, stats)
            weeks = wa.find_week_sections(ws)
            week = weeks[week_idx]

    if not grow_detail_buffer:
        return

    weeks = wa.find_week_sections(ws)
    week = weeks[week_idx]
    stop = wa.next_week_header_row(weeks, week)
    free = wa.free_detail_slot_count(ws, week, stop)
    needed = len(week_recs) + wa.DETAIL_SLOT_BUFFER
    if free < needed:
        wa.grow_week_detail_slots(ws, wb, week, needed - free)


def presize_month_from_attendance(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    year: int,
    month: int,
    month_recs: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
    grow_detail_buffer: bool = False,
) -> None:
    weeks = wa.find_week_sections(ws)
    for week_idx in range(len(weeks) - 1, -1, -1):
        week = weeks[week_idx]
        if not week.dates:
            continue
        week_dates = set(week.dates.values())
        week_recs = [r for r in month_recs if r.work_date in week_dates]
        if not week_recs:
            continue
        print(
            f"  Presize {week.title[:35]}: "
            f"{len(week_worker_shorts(week_recs, registry))} workers, {len(week_recs)} entries"
        )
        presize_week_from_attendance(
            wb, ws, week_idx, week_recs, registry, stats, grow_detail_buffer=grow_detail_buffer
        )

    month_load = wa.analyze_month_load(month_recs, year, month)
    wa.restore_all_week_header_merges(ws, month_load)
    for week in wa.find_week_sections(ws):
        wa.reset_week_employee_formulas(ws, week)


def month_sheet_healthy(ws: Worksheet, wb: openpyxl.Workbook, year: int, month: int) -> bool:
    if not month_dates_aligned(ws, year, month):
        return False
    if not month_block_reasonable(ws, wb):
        return False
    expected_weeks = len(wa.month_week_ranges(year, month))
    if len(wa.find_week_sections(ws)) < expected_weeks:
        return False
    return True


def create_month_sheet_once(
    wb: openpyxl.Workbook,
    year: int,
    month: int,
    stats: wa.Stats,
) -> Worksheet:
    """Copy May ONCE. Never delete a healthy month sheet."""
    name = wa.sheet_name_for_date(date(year, month, 1))
    if name in wb.sheetnames:
        ws = wb[name]
        if month_sheet_healthy(ws, wb, year, month):
            return ws
        print(f"{name} layout broken or bloated — recreating once from {wa.TEMPLATE_SHEET}")
        del wb[name]

    template = wb[wa.TEMPLATE_SHEET]
    ws = wb.copy_worksheet(template)
    ws.title = name
    wa.initialize_month_sheet(ws, year, month)

    month_load = wa.MonthLoad(
        year=year,
        month=month,
        weeks=[
            wa.WeekLoad(start=s, end=e, entry_count=0, worker_shorts=set())
            for s, e in wa.month_week_ranges(year, month)
        ],
    )
    wa.restore_all_week_header_merges(ws, month_load)
    wa.reset_month_employee_formulas(ws)
    wa.apply_month_sheet_formatting(wb, name, include_merges=False)
    wa.restore_all_week_header_merges(ws, month_load)
    wa.apply_employee_grid_styles(ws, template)
    wa.fix_detail_log_formulas(ws)
    wa.normalize_employee_day_cells(ws)
    wa.normalize_detail_hours_formats(ws)
    wa.restore_week_salary_summary(ws, wb)
    wa.restore_week_ab_merges(ws, template)
    wa.apply_week_detail_log_fills(ws, wb)
    stats.created_sheets.add(name)
    print(f"Created {name} once from {wa.TEMPLATE_SHEET} (will not delete on future runs)")
    return ws


def find_detail_row_for_record(
    ws: Worksheet,
    week: wa.WeekSection,
    worker: str,
    work_date: date,
) -> Optional[int]:
    weeks = wa.find_week_sections(ws)
    stop = wa.next_week_header_row(weeks, week)
    for row in range(week.header_row, stop):
        name = ws.cell(row, wa.DETAIL_COLS["name"]).value
        dt = ws.cell(row, wa.DETAIL_COLS["date"]).value
        if not name or not isinstance(dt, datetime):
            continue
        if dt.date() != work_date:
            continue
        if not wa.worker_names_match(worker, str(name)):
            continue
        return row
    return None


def sync_record_to_week(
    wb: openpyxl.Workbook,
    ws: Worksheet,
    week: wa.WeekSection,
    rec: wa.AttendanceRecord,
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
    day_break_flags: dict[date, bool],
) -> None:
    profile = wa.lookup_worker_profile(wb, registry, rec.worker, rec.worker)
    short = wa.canonical_worker_short(rec.worker, registry) or rec.worker
    if short.lower().startswith("frank"):
        profile = wa.lookup_worker_profile(wb, registry, "Franklin", rec.worker)

    if not wa.is_valid_worker_short(profile.short_name):
        wa.log_skip(stats, "Invalid worker name", rec.source)
        return

    employee_row = wa.resolve_employee_row(ws, week, registry, profile)
    if employee_row is None:
        wa.log_skip(stats, "No employee row", f"{profile.excel_name} | {rec.source}")
        return

    day_col = wa.find_day_col(week, rec.work_date)
    if not day_col:
        wa.log_skip(stats, "Date not in week", rec.source)
        return

    detail_row = find_detail_row_for_record(ws, week, profile.short_name, rec.work_date)
    if detail_row is None:
        detail_row = wa.find_free_detail_row(ws, week, employee_row=employee_row)
        if detail_row is None:
            wa.log_skip(stats, "No free detail row", rec.source)
            return
        wa.write_detail_entry(
            ws,
            detail_row,
            profile.short_name,
            rec.work_date,
            rec.time_in,
            rec.time_out,
            profile.empty_break_hours,
            wb,
            week,
            profile.hourly_rate,
            employee_row,
        )
        stats.added += 1
    else:
        # Update existing detail if times changed
        old_in = ws.cell(detail_row, wa.DETAIL_COLS["time_in"]).value
        old_out = ws.cell(detail_row, wa.DETAIL_COLS["time_out"]).value
        if old_in == rec.time_in and old_out == rec.time_out:
            stats.skipped += 1
            return
        ws.cell(detail_row, wa.DETAIL_COLS["time_in"]).value = rec.time_in
        ws.cell(detail_row, wa.DETAIL_COLS["time_out"]).value = rec.time_out
        stats.added += 1

    wa.link_employee_day_to_detail(
        ws, wb, employee_row, day_col, detail_row, week, rec.time_in, rec.time_out
    )

    if rec.no_break:
        day_break_flags[rec.work_date] = True
    elif rec.work_date not in day_break_flags:
        day_break_flags[rec.work_date] = False

    recalc = {d: day_break_flags.get(d, False) for d in week.dates.values()}
    wa.recalculate_employee_week(
        ws, week, employee_row, profile.short_name, recalc, profile.empty_break_hours
    )
    stats.updated_sheets.add(ws.title)


def sync_month_professional(
    wb: openpyxl.Workbook,
    year: int,
    month: int,
    records: list[wa.AttendanceRecord],
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
) -> None:
    """Rebuild fixed-layout month view + sync detail from Attendance_Log."""
    month_recs = [
        r
        for r in records
        if r.work_date.year == year
        and r.work_date.month == month
        and r.time_in
        and r.time_out
    ]
    ws, detail_count = rebuild_month_view(wb, year, month, records, registry)
    stats.updated_sheets.add(ws.title)
    stats.added += detail_count
    ms = wa.month_stats_for(stats, year, month)
    ms.added = len(month_recs)
    print(
        f"  Built {ws.title}: {len(month_recs)} entries | "
        f"{ms.skipped} skipped this month"
    )


def finalize_sync(
    ws: Worksheet,
    wb: openpyxl.Workbook,
    registry: wa.WorkerRegistry,
    stats: wa.Stats,
) -> None:
    fixed = wa.sanitize_orphan_day_links(ws)
    if fixed:
        print(f"  Cleared {fixed} orphan day links")
    wa.fix_detail_log_formulas(ws)
    wa.reset_month_employee_formulas(ws)
    wa.apply_week_detail_log_fills(ws, wb)
    wa.sync_employee_hourly_rates(ws, wb, registry)
    wa.restore_week_salary_summary(ws, wb)
    for issue in wa.validate_month_sheet(ws):
        stats.skip_log.append(f"VALIDATION | {issue}")


def run_sync() -> None:
    stats = wa.Stats()

    if not wa.EXCEL_FILE.exists():
        raise FileNotFoundError(f"Excel not found: {wa.EXCEL_FILE}")
    if not wa.CHAT_FILE.exists():
        raise FileNotFoundError(f"Chat not found: {wa.CHAT_FILE}")

    print(f"Creating backup: {wa.BACKUP_FILE}")
    shutil.copy2(wa.EXCEL_FILE, wa.BACKUP_FILE)

    wb = openpyxl.load_workbook(wa.EXCEL_FILE)
    registry = wa.build_worker_registry(wb)
    wa.register_template_aliases(registry)

    ensure_employee_master(wb)
    ensure_standard_attendance_log(wb)
    records = upsert_attendance_from_chat(wb, stats, registry)

    months = sorted({(r.work_date.year, r.work_date.month) for r in records})
    for year, month in months:
        if date(year, month, 1) < wa.CUTOFF_DATE:
            continue
        sheet_name = wa.sheet_name_for_date(date(year, month, 1))
        print(f"Building {sheet_name} (professional layout) …")
        sync_month_professional(wb, year, month, records, registry, stats)

    circ_fixed = wa.repair_self_referencing_sums(wb)
    if circ_fixed:
        print(f"Fixed {len(circ_fixed)} circular Total-row formula(s): {', '.join(circ_fixed)}")

    wb.calculation.fullCalcOnLoad = True
    wb.save(wa.EXCEL_FILE)
    wa.write_skipped(stats)
    wa.write_new_workers(stats)
    wa.print_summary(stats)
    print("Professional month view build complete.")


if __name__ == "__main__":
    run_sync()
