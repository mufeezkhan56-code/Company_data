---
description: May template layout — kabhi mat badlo
alwaysApply: true
---

# May Sheet Layout (05-May-26)

`05-May-26` is the read-only layout source for every month sheet.

## Allowed

- Write detail log cols P–AA (date, Time In, Time Out, formulas)
- Write day cols B–H as `=U{detail_row}` only when `detail_row != employee_row`
- Add new worker row immediately before Total (one row insert only)
- Copy number format and styling from `05-May-26` for any written cell

## Forbidden

- `insert_rows` for detail overflow — skip entry and log instead
- Insert rows before the next week header
- `delete_rows` on employee rows
- Call `realign_sheet_layout`, `fix_month_sheet_structure`, or `repair_month_sheet_structure` on live month sheets
- Write anything to `05-May-26`

## Structure rules

- Exactly 5 week blocks per month sheet
- Week headers keep merge `A{header}:O{header+1}`
- Detail uses May overlap model: detail on a non-employee row inside the week block; employee day cell links to that row
- Franklin: empty break (col L blank, detail V = `-`)
- Kennedy: normal worker

## Overflow

When no free detail row exists inside the week block, skip the entry and log — never shift layout to make room.
